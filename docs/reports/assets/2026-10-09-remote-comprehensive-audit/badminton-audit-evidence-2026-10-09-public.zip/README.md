# 公开入库证据包 · 2026-10-09

本包对应仓库 `docs/reports/2026-10-09-remote-comprehensive-audit.md` 的完整报告。HTML 保留已交付版的原始字节。检查、复现和文档交付不表示当前云实况或原 12 项计划已全部验收。

## 与初次交付包的差异

为避免重复分发上游 SDK 自带测试密钥与不参与复现的测试内容，本包不附带 3 个原始 npm 压缩包。它们的精确版本、原始 SHA-256 和 `npm pack --ignore-scripts` 取回命令见 `PUBLICATION.json`；在独立目录执行命令，下载后先校验 SHA-256，再检查所需源码。该步骤不是升级、安装或调用生产的指令。SDK 请求探针需要的真实运行依赖、选定源码及其许可证已经保留，可离线执行。

原始报告和历史构建脚本中的“SDK 发布包随包提供”描述的是初次交付包；公开版本以本说明及 `PUBLICATION.json` 为准。除删去的压缩包、更新后的阅读说明和重新计算的 `SHA256SUMS` 外，其余原始文件字节不变。完整性清单用于对账，不代表无缺陷或线上验收通过。

# 阅读顺序

先打开本目录的 `badminton-audit-2026-10-08.html`；文件沿用首轮名称，内容已更新为10月9日补查版，包含主报告、历史12项对账和八份附录。`evidence/root/combined-findings.json` 为18个主审计条目及单独1项P3输入防护观察的结构化清单。`SHA256SUMS` 给出本包文件的完整性校验值。当前云实况仍未验证，报告交付不表示全项检查已完成。

# 固定源码

仓库为 LXZ56156/repo-20260224-031312，提交必须为 `a3fe96f25015892ac30ee7148f97a5b441b0cb24`。本包没有复制业务仓库；请使用你有权访问的固定检出，不要把复现改为调用生产云函数。

# 复现主要问题

本次运行使用 Node 24.19.0。先在终端进入本证据包解压目录，再设置实际仓库路径：

```bash
export AUDIT_REPO=/absolute/path/to/pinned/repository
node evidence/business/verify-business.cjs
node evidence/fairness/reproduce-findings.cjs
node evidence/telemetry/resource-probes.cjs
node evidence/telemetry/telemetry-probes.cjs
node evidence/telemetry/frontend-resource-probes.cjs
node evidence/root/profile-query-repro.cjs
python3 evidence/root/verify-fairness-witnesses.py
```

这些脚本使用合成数据，加载实际业务代码并替换云 SDK、平台出口或远端返回。返回 0 表示报告所述行为被成功复现，不表示缺陷已修复。脚本会更新各自的结果文件，因此复跑后与原 `SHA256SUMS` 的差异需按新运行记录解释；请保留原始解压副本用于对账。

事务探针使用本包 `evidence/business/sdk-inspection/runtime/` 的小型精确数据库 SDK 依赖集，不使用账户凭据；所有请求由本地捕获器接收。三个原始 npm 发布包在公开版本中不再内嵌；精确版本、原包哈希、取回命令及排除说明见 PUBLICATION.json，所需源码与许可证仍保留。可选通过 `AUDIT_DATABASE_SDK` 指向另一个已安装的 @cloudbase/database@1.4.1 路径。

两项参数可达性可另外运行 `node evidence/fairness/reachability-audit.cjs`，约数秒，涵盖真实创建/导入/设置/开赛代码，仍使用内存数据库。较完整搜索样例为 `runtime-audit.cjs`，时间预算与名单在文件内明确。

# 原始基线

`evidence/baseline/full-tests.log` 保存 1,777 项测试的原始 TAP；结果为 1,768 通过、7 失败、2 跳过。`baseline-analysis.json` 记录失败归因和针对性复核；check 与 lint 回执单独保存。完整全量复跑需要安装仓库依赖，Bash/tmp 前提和 WSL/Windows 专用环境应按报告区分。

本包没有保存业务仓库的 node_modules。只有 SDK 请求探针所需的小型依赖集被保留，便于无网络复核。当前 SDK runtime 的完整 package.json/package-lock.json 和许可证随包提供。

# 证据结构

| 目录 | 内容 |
|---|---|
| evidence/baseline | 固定清单、完整测试、运行环境、检查和主控复跑回执 |
| evidence/business | 五项业务问题、真实 SDK 请求序列、详细报告及复现 |
| evidence/fairness | 模板/参数/比分/排名验证、完整见证排程、质量反例及可达性 |
| evidence/telemetry | 两套留痕、指标矩阵、资源动作计数、UI/config 静态清单 |
| evidence/root | 主控独立重算、依赖公告数据、原12项对账、报告构建与最终完整性 |
| evidence/remote-followup-20261009 | 当前GitHub读取、云访问缺口、历史云证据20条、日志/资源矩阵、公共云依赖新锁、留存输入观察与独立范围审校 |

# 验证边界

本轮没有读取真实生产业务数据、部署、发布、迁移或操作用户设备。没有新的云部署/账单/事件实收回执。当前云检查因缺少已认证只读连接或原件而保留受阻；手机/原生门槛仅作为历史开发状态，不扩张本次远端范围。确认问题不以修复为检查完成前提；历史12项产品计划也不因报告完成而自动通过。

TEL-02是P3输入防护观察：真实CLI可接受合成旧快照与后移人工水位的矛盾组合，但未证明真实微信未成熟快照出现该key7=0格式。缺key7时仍unknown，整体window.status仍missing。主控缺key对照保留在followup/root/retention-independent-check.json，不将该观察当确定线上统计故障。

公共云依赖目录只保存依赖清单与锁、解析日志和扫描JSON。17项扫描影响不乘26，不与根工具链97项相加，也不代表已部署版本。首次锁未完成时的ENOLOCK回执原样保留；最终统计取有效锁后的扫描。
