'use strict';
// One offline command for all confirmed business audit reproductions.
// Scripts use synthetic data only. The SDK probe replaces network transport.
const path = require('node:path');
const fs = require('node:fs');
const { spawnSync } = require('node:child_process');
const repo = path.resolve(process.env.AUDIT_REPO || path.join(__dirname, '../../repo'));
const expectedCommit = 'a3fe96f25015892ac30ee7148f97a5b441b0cb24';
const head = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' });
if (head.status !== 0 || head.stdout.trim() !== expectedCommit) {
  console.error(`Expected pinned audit checkout ${expectedCommit}; actual ${head.stdout.trim() || head.stderr.trim()}`);
  process.exit(1);
}
const scripts = ['reproduce-business.cjs', 'reproduce-client-score.cjs', 'sdk-inspection/probe-transaction.cjs'];
const results = [];
for (const script of scripts) {
  const run = spawnSync(process.execPath, [path.join(__dirname, script)], {
    env: { ...process.env, AUDIT_REPO: repo }, encoding: 'utf8', timeout: 30000
  });
  results.push({ script, exitCode: run.status, verified: run.status === 0 });
  if (run.status !== 0) {
    console.error(run.stdout, run.stderr, run.error || '');
    process.exitCode = 1;
  }
}
const report = { commit: expectedCommit, offline: true, verified: results.every(r => r.verified), results };
fs.writeFileSync(path.join(__dirname, 'verification.results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
