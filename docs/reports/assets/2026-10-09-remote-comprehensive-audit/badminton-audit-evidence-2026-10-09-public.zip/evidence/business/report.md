# 赛事业务、身份权限与独立打水账本专项审计

## 结论与审计边界

审计对象为远端仓库 `LXZ56156/repo-20260224-031312` 的 `master` 固定提交 `a3fe96f25015892ac30ee7148f97a5b441b0cb24`。本专项确认 **5 项问题：2 项 P1、3 项 P2**。P1 指应优先修复、涉及数据保留或事务一致性的缺陷；P2 指有明确错误行为，但本次证据的影响限于身份合同、观测质量或客户端显示。

全部工作以远端源码的隔离副本、规格、现有测试及精确版本 SDK 发布包为依据。业务源码没有修改，没有调用生产云函数、查询真实数据库、执行迁移、登录或部署。离线脚本使用合成数据。报告中的“已复现”描述可执行代码在指定条件下的结果，**不等于已在生产发生，也不等于真实云引擎并发或回滚验收通过**。

| ID | 优先级 | 已确认问题 | 影响边界 |
| --- | --- | --- | --- |
| BIZ-04 | P1 | 指定 SDK 的事务内 `where().update()` 请求未携带 `transactionId` | 影响 5 个赛事写入口的事务边界；未调用真实云引擎 |
| BIZ-01 | P1 | 两次旧版 V1 创建交错时，较慢请求可覆盖已成功录入的账本 | 仅仍允许 V1 `create` 的未迁移兼容路径 |
| BIZ-02 | P2 | 普通加入按唯一同名 guest 自动绑定，违背当前“不自动绑定”规格 | 草稿赛事参赛身份归属；未发现因此直接取得主办或协管 |
| BIZ-03 | P2 | 已录场次同比分重试返回赛事 `finished:true`，导致完赛留痕误报 | 当前复现赛事仍运行；未导致云赛事提前结束或直接页面跳转 |
| BIZ-05 | P2 | 录分成功后的补偿投影覆盖较新的权威更正结果 | 当前客户端显示旧比分和记分者；不覆盖云端数据 |

这 5 项问题分别对应不同根因，不把留痕专项引用的 BIZ-03 另行重复计数。已撤回的新轮次、结束账本 UI 不属于修复建议；当前产品仍以“每次创建独立账本”为准。

## 最短离线复核

在当前证据目录可使用一个命令复核全部 5 项。脚本首先检查固定提交，然后串行运行 3 个独立脚本；无需账号和网络：

```bash
AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/business/verify-business.cjs
```

本次执行结果：3 个脚本均退出 `0`，`verification.results.json` 中 `verified:true`。BIZ-01/02/03 由同一脚本加载真实云函数入口；BIZ-03 额外经过真实客户端结果归一化和真实 `activityTracker`，上报出口只捕获到进程内存。BIZ-05 使用真实录分 service 和真实 view model。BIZ-04 使用真实发布的数据库 SDK，仅替换网络传输出口以捕获请求参数。

| 文件 | 内容 |
| --- | --- |
| `reproduce-business.cjs` / `reproduce-business.results.json` | BIZ-01、BIZ-02、BIZ-03 的合成数据、调度和结果 |
| `reproduce-client-score.cjs` / `reproduce-client-score.results.json` | BIZ-05 的两个记分者交错刷新复现 |
| `sdk-inspection/probe-transaction.cjs` / `sdk-inspection/probe-transaction.results.json` | BIZ-04 的真实 SDK 请求捕获 |
| `sdk-inspection/packages.json` | 3 个精确 SDK 发布包的版本、依赖和 SHA-256 |
| `verification.results.json` | 一次命令复核的逐脚本退出结果 |
| `findings.json` | 可供主报告合并的问题和覆盖数据 |

两个业务复现脚本均支持 `AUDIT_REPO`。SDK probe 默认从证据内 `sdk-inspection/runtime/node_modules/@cloudbase/database` 加载精确版本；移交时也可通过 `AUDIT_DATABASE_SDK` 指向独立安装的 `@cloudbase/database@1.4.1`。不要把探针替换传输出口的行为与真实云环境执行混淆。

## BIZ-04：指定版本的条件更新缺少事务标识

**优先级：P1。证据置信度：请求生成行为高；生产发生率与云引擎后果未验证。**

### 位置和依赖链

以下入口在 `runTransaction` 回调内使用条件更新，且各自 `package.json:6` 固定 `wx-server-sdk: 2.6.3`：

| 入口 | 精确位置 |
| --- | --- |
| 开赛 | `cloudfunctions/startTournament/index.js:293–306` |
| 导入人员 | `cloudfunctions/addPlayers/index.js:258` |
| 移除人员 | `cloudfunctions/removePlayer/index.js:100` |
| 修改设置 | `cloudfunctions/updateSettings/index.js:144` |
| 设置裁判 | `cloudfunctions/setReferee/index.js:63` |

实际发布包的固定依赖为 `wx-server-sdk@2.6.3 → @cloudbase/node-sdk@2.9.1 → @cloudbase/database@1.4.1`。虽然 wx 包还声明了 `tcb-admin-node:latest`，其实际数据库实现导入的是 `@cloudbase/node-sdk`，不能用另一条未调用依赖链替代核验。

SDK 证据位于 `sdk-inspection/`：

- `wx-server-sdk-2.6.3/package/index.js:1500–1527`：wx `Query.update` 直接委托底层 `query.update(options.data)`。
- `cloudbase-database-1.4.1/package/src/transaction/index.ts:51–57`：事务 collection 会取得事务 ID。
- `cloudbase-database-1.4.1/package/src/query.ts:292–316`：`where` 构建 query 时保留内部事务 ID。
- **同文件 `392–444`：普通 `update` 构造的 `database.modifyDocument` 参数没有 `transactionId`。**
- `cloudbase-database-1.4.1/package/src/document.ts:244–259`：`doc.update` 的请求则明确包含 `transactionId`。

这不是“事务内没有 where 方法”的问题。方法存在，但普通 query update 的请求构造丢掉了事务标识。包内另有 `updateAndReturn` 实现，不能把它携带标识的代码当作普通 `update` 的证据。

### 复现与实际结果

运行：

```bash
node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/business/sdk-inspection/probe-transaction.cjs
```

探针加载精确发布的数据库包，仅将 `Db.reqClass` 替换为本地请求捕获器。第一组事务中，`where().update()`、`doc().update()`、`doc().set()` 连续执行；后两者含 `offline_tx_1`，第一条没有事务标识。第二组先 `where().update()`，随后主动抛出合成错误；捕获到的 `abortTransaction` 指向 `offline_tx_2`，此前条件更新请求没有该标识。

**预期：**事务中的赛事更新、请求日志写入和最终提交或回滚应属于同一个事务。

**已确认实际：**普通条件更新生成的请求没有加入事务标识；文档更新和文档写入有标识。源码中的 `where({_id, version})` 仍保留版本条件，这个问题不能表述为“完全没有并发控制”。

**影响：**这 5 个入口的赛事变更不能以现有离线 mock 的事务模型作为原子性证明。尤其开赛和移除人员还依赖同事务请求日志：若业务变更先发生、日志或后续提交失败，存在业务变更与错误返回/请求日志不同步的风险。此次没有调用云引擎，因此不宣称某次真实 rollback 已留下数据，亦不宣称生产所有开赛必定失败。实际部署所携带 SDK 包尚未取证。

### 修复方向和验收条件

优先改为读取权威事务文档后，通过带事务 ID 的文档更新完成变更；权限、版本语义和请求日志仍保持在同一原子边界。参考当前录分、提前收赛所采用的文档事务写法。不要仅因 mock 支持 `where.update` 就视作完成。

验收至少需要两层证据：精确 SDK 请求捕获能证明赛事写入和日志携带同一事务 ID；在独立云环境中制造日志写失败、提交冲突和重复请求，验证业务/日志同时提交或回滚。后者本次没有执行。

## BIZ-01：旧版 V1 创建竞态可清空已成功写入的数据

**优先级：P1。证据置信度：高；限定旧版兼容入口。**

位置：`cloudfunctions/waterSession/index.js:184–214`。账本 ID 由 owner 的 OPENID 确定；`187–193` 先在事务外读取，`200–210` 构建版本 1 空账本，`213` 无条件 `doc.set`。从第一次读取到 `set` 之间没有事务重读或条件写入。

复现命令：

```bash
AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/business/reproduce-business.cjs
```

合成调度按真实 handler 的异步边界执行：慢创建先读取“不存在”，停在 `set` 前；同一用户的快创建成功；随后添加第 2 位球友、记入 1 条比赛记录，账本达到版本 3；最后恢复慢创建，让版本 1 的空账本 `set` 落下。

| 检查项 | 慢创建恢复前 | 慢创建恢复后 |
| --- | --- | --- |
| 人数 | 2 | 1 |
| 记录数 | 1 | 0 |
| 版本 | 3 | 1 |
| 请求结果 | 创建、添加、记账均成功 | 慢创建也返回成功 |

**预期：**重复或并发创建不能覆盖已经成功创建和记账的同一个账本。

**实际：**迟到的初始 `set` 覆盖了此后已确认成功的记录和球友；当前脚本是确定性合成调度，没有声称测出了云端真实发生率。

当前 `createLedger` 的独立 V2 账本使用不同的创建合同及事务重读，不能把此结果推广为“所有新独立账本会被清空”。但旧链接和 V1 兼容入口仍有代码路径，不能仅因新 UI 不再使用旧模式就忽略数据保留风险。

建议将旧版创建的存在性判断与首次写入放入同一原子边界，遇到已创建的有效账本则返回该账本，不重新初始化。加入上述真实异步交错的回归。修复保持当前“新建独立账本”的产品方向，不恢复已撤回的结束/新轮次按钮。

## BIZ-02：同名普通加入会自动认领 guest

**优先级：P2。证据置信度：行为高；属于现行规格与实现冲突。**

位置：`cloudfunctions/joinTournament/index.js:256–260` 以昵称匹配唯一 guest；`366–395` 直接把该 guest 改写为当前 server OPENID 的 user，并返回 `claimed:true`。改写字段包含 players、playerIds、pairTeams、rounds、rankings。

当前 `docs/specs/singles-round-robin-requirements.md:41` 明确要求“同名不自动绑定”。`docs/specs/cloud-tournament-recovery-proposal.md:9、19` 也将同名与真实绑定分开，要求 guest 明确认领后才具有实际归属。另一方面，现有 `tests/joinTournament.claim.test.js` 刻意覆盖了自动认领行为，因此这是需要对齐的合同冲突，不能把已有测试通过当作需求已满足。

使用上述 `reproduce-business.cjs`，创建单打草稿赛事，已有 owner 和名为 `Same Name` 的 `guest_audit`。另一个合成真实身份 `audit_unrelated` 只执行普通加入，填相同昵称以及最小资料；请求中没有显式认领字段。

**预期：**按当前规格，单纯同名不能把 guest 自动绑定成此用户。

**实际：**返回 `JOINED`、`claimed:true`，`[audit_admin, guest_audit]` 变成 `[audit_admin, audit_unrelated]`。普通加入因此改变了既有名单中的身份，而非只添加一个独立人员。

影响限于可达的草稿加入/认领和随后基于真实 ID 的参赛归属。没有证据表明这个路径直接授予主办或协管，也没有把同名等同于可冒用任意微信 OPENID。

建议按现行“不自动绑定”规格改为明确的认领流程与冲突提示，并同步修改与该规格冲突的测试。不要通过仅改变规格文字来掩盖未取得确认的身份替换。

## BIZ-03：同比分幂等响应把单场完成当成整场赛事完成

**优先级：P2。证据置信度：高；影响为完赛留痕正确性。**

位置：`cloudfunctions/submitScore/logic.js:106–119` 的 `buildIdempotentRetryResult` 只检查目标场次已 finished 且比分相同，却固定返回 `finished:true`。`cloudfunctions/submitScore/index.js:46–57、108–121` 包装并返回此结果。正常首次提交的 `index.js:198–205` 则用 `computed.finished` 表示整场赛事是否完成；两个响应路径对同一字段采用了不同粒度。

上述复现脚本使用真实 handler 构造赛事：赛事状态 `running`，目标场次已经 `21:18` 结束，另 1 场仍 `pending`。同比分再次提交得到 `SCORE_SUBMIT_DEDUPED`、`finished:true`，数据库写入次数为 0，赛事仍运行。

脚本随后把真实响应交给真实 `normalizeCloudResult` 和 `activityTracker.finish`，只把 `wx.reportEvent` 替换为内存捕获。捕获结果为 `action:tournament_complete`、`resultCode:FINISHED_CONFIRMED`。

**预期：**未结束的赛事不得上报为已确认完赛。

**实际：**`miniprogram/core/activityTracker.js:168–171` 根据 `finished:true` 发出完赛确认，即使比赛仍有待录场次。此问题与“重复观察已完赛状态不能代表首次完赛”不同：这里连“已完赛状态”本身也不成立。

### 客户端消费者范围

`miniprogram/core/cloud.js:72–81` 的状态归一化也读取 `source.finished`，但显式 `state` 以及 `deduped` 分支先执行。当前生产去重响应保留 `state:deduped`，复现也断言了这一点。录分 service 的下一场选择、返回和赛事状态读取刷新后的赛程，不直接以该响应 flag 判定。

因此本次已确认影响限于错误的完赛事件；不报告为云赛事提前收赛、排名提前结算或该字段造成的直接导航错误。留痕专项应引用此 ID，避免重复列出同一根因。

建议使去重响应与首次成功响应保持相同的赛事级 `finished` 语义，并用“目标已完成、其他场待录”的真实 handler 到 tracker 回归覆盖。只在 tracker 中忽略去重事件会掩盖后端字段不一致，也会丢掉真实已完赛状态的合法观察。

## BIZ-05：提交后的本地补偿覆盖较新的权威比分

**优先级：P2。证据置信度：高；仅客户端投影错误。**

位置：`miniprogram/pages/match/matchSubmitService.js:142–154`。提交成功后刷新，如果刷新结果不等于本次尝试的比分，就调用 `buildLocalSubmittedTournament`。该函数在 `78–108` 克隆当前最新赛事，将本次旧比分及记分者覆盖上去，再用 `Math.max(currentVersion, resultVersion)` 保留较新版本号。`111–125` 将投影作为最新视图，并设置 `syncUsingCache:false`、`showStaleSyncHint:false`。

复现命令：

```bash
AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/business/reproduce-client-score.cjs
```

脚本加载真实 service 和真实 `buildTournamentViewState`，只以确定性响应替换远端及原生 UI：

1. 用户 A 提交 `21:18`，服务端成功响应版本 2。
2. 刷新发生前，合法用户 B 已更正为 `18:21`，版本 3。
3. `fetchTournament` 实际返回并应用了权威版本 3。
4. 提交成功收尾因为“分数不同”而补偿，再把旧 `21:18` 和 A 的记分者身份放回本地版本 3。

| 数据 | 版本 | 比分 | 记分者 |
| --- | --- | --- | --- |
| A 的成功响应 | 2 | 21:18 | A |
| 权威刷新 | 3 | 18:21 | B |
| 收尾后的本地视图 | 3 | 21:18 | A |

**预期：**已读取到比提交响应更新的权威版本，应尊重其中的合法更正。

**实际：**客户端显示旧比分和旧记分者，显示“已提交”，并清除过期数据提示。脚本没有产生第二次云写入，云端仍是 B 的正确更正。未验证真机显示持续时长，也没有证据宣称错误投影被写入永久缓存；新的刷新可能恢复正确结果。

建议比较刷新文档与成功响应的版本：只有远端缺失或能证明比已提交版本旧，才使用本地提交投影；当读到更新权威文档时直接保留。该回归需要覆盖“提交成功后他人更正、然后本客户端刷新”，只测网络失败的本地兜底不足以覆盖这个条件。

## 完成的检查面与保留的验证边界

下表描述本专项实际阅读和跟踪的范围；“存在约束”表示在代码中找到了相应校验，不等于真实云环境验收通过。

| 检查面 | 已检查内容与结论 | 对应入口或证据 |
| --- | --- | --- |
| 赛事创建/复制/重置/删除 | 请求去重、主办权限、复制与重置清理手动完赛元数据；未新确认问题 | `createTournament`、`cloneTournament`、`resetTournament`、`deleteTournament` |
| 草稿人员和设置 | 加入/导入/移除、guest 认领、固定队伍、分队、裁判、版本更新；确认 BIZ-02、BIZ-04 | `joinTournament`、`addPlayers`、`removePlayer`、`managePairTeams`、`setPlayerSquad`、`setReferee`、`updateSettings` |
| 开赛 | 事务入口、请求日志、草稿与权限检查、提交后结果；确认 BIZ-04，排阵质量由公平性专项覆盖 | `startTournament` |
| 录分与锁 | 服务端身份、比分边界、session/owner/expiry、锁消耗、事务冲突、旧分数字段与旧 session 兼容；确认 BIZ-03、BIZ-05 | `submitScore`、`scoreLock`、match submit/view model |
| 提前收赛 | 主办且 running、至少 1 个有效结果、活跃锁拒绝、仅取消待录场次、手动终止不复活、复制/重置清元数据 | `finishTournament`、`submitScore/logic.js`、相关合同测试 |
| 协管 | 仅主办授予/撤销、绑定 roster 交集、guest 排除、管理能力不等于主办；撤销/移除与版本冲突检查 | `manageCoManagers`、共享 permission、管理入口 |
| 云端找回 | server OPENID、主办和参赛两路、权威 roster 二次过滤、身份绑定 cursor、分页与错误不能伪装为空成功 | `getMyTournaments`、找回规格及测试 |
| V1 账本兼容 | owner 写权限、版本、有限旧 request ID 去重、活动投影上限、迁移门槛与旧链接；确认 BIZ-01 | `waterSession/index.js` V1 路由 |
| V2 独立账本 | 每次独立 `createLedger`、请求 ID/载荷冲突、事务重读、owner/member 历史列表、当前与历史访问范围 | `waterSession/index.js` V2 创建、列表和查询 |
| V2 多人账本 | 成员身份文档、最大 24 人、姓名冲突、明确认领、功能开关、只读降级、公开字段白名单 | V2 roster、member、capability 入口 |
| 更正和撤销 | root/room/round 一致性、当前记录链、owner/原操作者权限、不可变事件、差额聚合、回放先于状态拒绝 | V2 record/correct/reverse/getEntry；`waterLogic.js` |
| 旧数据迁移 | 重点复核计划与源 hash、确定性目标、人数/记录/每人账务核对、staging/checkpoint、激活前源版本与 hash 重验；未执行任何真实迁移 | `waterMigration.js` 核心计划、写入与激活路径；相关测试 |
| SDK 与 mock 边界 | 精确依赖包读取、query/doc 写请求对比、合成 abort 参数捕获；确认 BIZ-04 | `sdk-inspection` 完整证据 |

`waterLogic.js` 的赢水/请水变化使用整数校验、净额等于赢水减请水、总赢水等于总请水及净额总和为零的约束；更正应用新旧 effect 差额，撤销应用相反 effect。代码层面未在此次检查中发现新增的账务守恒缺陷。

已检视的现有回归入口包括 `coManagers.contract.test.js`、`finishTournament.contract.test.js`、`submitScore.index.test.js`、`submitScore.idempotent-retry.test.js`、`scoreLock.*.test.js`、`waterSession.v2-cloud.test.js`、`waterSession.v2-migration*.test.js` 等。全量基线由主控执行并在总报告汇总，本专项没有重复全量测试。包含“20 并发写入”等字样的现有用例采用进程内事务替身，不能据其名称宣称真实云事务并发通过。

真实部署版本、云端数据库规则/索引实际生效状态、真实 OPENID 与多设备行为、云引擎冲突/回滚、生产使用频次和真机 UI 仍属未验证。本专项没有用模拟测试替代这些证据，也没有因没有发现更多问题而将其标为通过。SDK 依赖包和所有复现文件均保存在证据目录；源码工作区在复核后保持干净。
