'use strict';
// Uses the real published @cloudbase/database@1.4.1 package, replacing only its
// documented request class boundary. Captured requests never leave this process.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const databaseSdkPath = process.env.AUDIT_DATABASE_SDK || path.join(__dirname, 'runtime/node_modules/@cloudbase/database');
const { Db } = require(databaseSdkPath);
const calls = [];
let nextTx = 0;
class LocalCaptureRequest {
  async send(method, params) {
    calls.push({method,params:params === undefined ? null : structuredClone(params)});
    if(method === 'database.startTransaction')return {transactionId:`offline_tx_${++nextTx}`,requestId:'offline'};
    if(method === 'database.commitTransaction' || method === 'database.abortTransaction')return {requestId:'offline'};
    if(method === 'database.modifyDocument')return {data:{updated:1,upsert_id:'offline_doc'},requestId:'offline'};
    if(method === 'database.removeDocument')return {data:{deleted:1},requestId:'offline'};
    throw new Error(`Unexpected method: ${method}`);
  }
}
Db.reqClass = LocalCaptureRequest;
const db = new Db({env:'offline-audit-no-network'});
(async()=>{
  await db.runTransaction(async tx=>{
    await tx.collection('tournaments').where({_id:'offline_tournament',version:3}).update({status:'running',version:db.command.inc(1)});
    await tx.collection('tournaments').doc('offline_tournament').update({scoreLockRevision:db.command.inc(1)});
    await tx.collection('client_request_logs').doc('offline_request').set({status:'succeeded'});
  });
  let rolledBack=false;
  try {
    await db.runTransaction(async tx=>{
      await tx.collection('tournaments').where({_id:'offline_tournament',version:4}).update({status:'draft'});
      throw new Error('synthetic failure after where.update');
    });
  } catch(e) { assert.equal(e.message,'synthetic failure after where.update');rolledBack=true; }
  assert.equal(rolledBack,true);
  const modifies=calls.filter(c=>c.method==='database.modifyDocument');
  assert.equal(modifies.length,4);
  assert.equal(Object.hasOwn(modifies[0].params,'transactionId'),false);
  assert.equal(modifies[1].params.transactionId,'offline_tx_1');
  assert.equal(modifies[2].params.transactionId,'offline_tx_1');
  assert.equal(Object.hasOwn(modifies[3].params,'transactionId'),false);
  assert.equal(calls.at(-1).method,'database.abortTransaction');
  assert.equal(calls.at(-1).params.transactionId,'offline_tx_2');
  const report={id:'BIZ-04',dependencyChain:['wx-server-sdk@2.6.3','@cloudbase/node-sdk@2.9.1','@cloudbase/database@1.4.1'],
    actualRuntime:'@cloudbase/database@1.4.1, exact package; network transport replaced only',
    finding:'where.update omits transactionId; doc.update and doc.set retain it; rollback targets a transaction not identified in the earlier where.update request',calls};
  fs.writeFileSync(path.join(__dirname,'probe-transaction.results.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
