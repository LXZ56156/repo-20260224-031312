'use strict';
// Offline audit only. Loads the unchanged production handlers with a local in-memory
// SDK substitute. No credentials, sockets, cloud SDK calls, or live data are used.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const repo = path.resolve(process.env.AUDIT_REPO || path.join(__dirname, '../../repo'));
const clone = (v) => structuredClone(v);
const missing = () => new Error('document.get:fail document does not exist');
function deferred() { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; }
const flags = { emergencyReadOnly:false, v2Read:true, rosterWrite:true, ownerWrite:true, memberWrite:true,
  correctWrite:true, reverseWrite:true, createRoundWrite:true, canaryRoomIds:[], canaryOpenids:[], revision:1 };
function makeDb(seed = {}, hooks = {}) {
  const state = new Map(Object.entries(seed).map(([name, docs]) => [name, new Map(Object.entries(docs).map(([id,v]) => [id,clone(v)]))]));
  const writes=[];
  const docs = name => { if (!state.has(name)) state.set(name,new Map()); return state.get(name); };
  const matches = (row, filter) => Object.entries(filter||{}).every(([key,v]) => row[key] === v);
  const db = {
    command: { inc: v => ({ $inc:v }), gt:v=>({$gt:v}) },
    serverDate: () => new Date('2026-10-09T00:00:00Z'),
    createCollection: async name => { docs(name); },
    collection(name) {
      return {
        doc(id) {
          return {
            async get() { const v=docs(name).get(id); if(!v)throw missing(); return {data:{_id:id,...clone(v)}}; },
            async set({data}) { if(hooks.beforeSet)await hooks.beforeSet(name,id,data); docs(name).set(id,clone(data)); writes.push({name,id,op:'set'}); return {_id:id}; },
            async update({data}) { if(!docs(name).has(id))return {stats:{updated:0}};
              const next={...docs(name).get(id)}; for(const [k,v]of Object.entries(data))next[k]=v&&typeof v==='object'&&'$inc'in v?(Number(next[k])||0)+v.$inc:clone(v);
              docs(name).set(id,next); writes.push({name,id,op:'update'}); return {stats:{updated:1}}; },
            async remove(){const removed=docs(name).delete(id); writes.push({name,id,op:'remove'});return {stats:{removed:Number(removed)}};}
          };
        },
        where(filter) { let limit=Infinity;const query={ limit(n){limit=n;return query;},orderBy(){return query;},field(){return query;},
          async get(){return {data:[...docs(name)].map(([id,v])=>({_id:id,...clone(v)})).filter(v=>matches(v,filter)).slice(0,limit)};} };return query; }
      };
    },
    // These repros invoke mutations serially and do not claim transactional fidelity.
    async runTransaction(fn) { return fn({collection:db.collection.bind(db)}); }
  };
  return {db,writes,read:(name,id)=>clone(docs(name).get(id)),all:name=>[...docs(name)].map(([id,v])=>({_id:id,...clone(v)}))};
}
function loadMain(functionName, db, openid) {
  const filename=path.join(repo,'cloudfunctions',functionName,'index.js');
  const old=Module._load;
  const sdk={init(){},database:()=>db,getWXContext:()=>({OPENID:openid}),DYNAMIC_CURRENT_ENV:'offline-audit'};
  delete require.cache[require.resolve(filename)];
  Module._load=function(request,parent,isMain){if(request==='wx-server-sdk')return sdk;return old.call(this,request,parent,isMain);};
  try{return require(filename).main;}finally{Module._load=old;}
}
async function legacyCreateRace() {
  const stopped=deferred(), release=deferred();
  const s=makeDb({water_feature_flags:{collaborative_v2:flags}}, {
    async beforeSet(name,id,data) { if(name==='waterSessions' && data.participants[0].name==='Slow owner'){ stopped.resolve();await release.promise; } }
  });
  const main=loadMain('waterSession',s.db,'audit_owner');
  const slowPromise=main({action:'create',ownerName:'Slow owner',clientRequestId:'audit_slow_create'});
  await stopped.promise;
  const fast=await main({action:'create',ownerName:'Fast owner',clientRequestId:'audit_fast_create'});
  assert.equal(fast.code,'WATER_SESSION_CREATED');
  const id=fast.session.id;
  const roster=await main({action:'addParticipants',sessionId:id,names:'Other player',expectedVersion:1,clientRequestId:'audit_add'});
  assert.equal(roster.ok,true);
  const [a,b]=roster.session.participants;
  const record=await main({action:'recordGame',sessionId:id,winnerIds:[a.id],loserIds:[b.id],unitsPerPlayer:1,expectedVersion:2,clientRequestId:'audit_record'});
  assert.equal(record.ok,true);
  const before=s.read('waterSessions',id);
  assert.equal(before.entries.length,1);assert.equal(before.participants.length,2);assert.equal(before.version,3);
  release.resolve();const slow=await slowPromise;
  const after=s.read('waterSessions',id);
  assert.equal(slow.code,'WATER_SESSION_CREATED');
  assert.equal(after.entries.length,0);assert.equal(after.participants.length,1);assert.equal(after.version,1);
  return {id:'BIZ-01',title:'Concurrent legacy create overwrites completed writes',confirmed:true,
    before:{records:before.entries.length,participants:before.participants.length,version:before.version},
    after:{records:after.entries.length,participants:after.participants.length,version:after.version},
    responseCodes:[fast.code,roster.code,record.code,slow.code],
    scope:'unmigrated V1 create; deterministic delayed set after the initial absence check; no live cloud concurrency claim'};
}
async function guestAutoClaim() {
  const t={_id:'audit_t',creatorId:'audit_admin',status:'draft',mode:'singles_round_robin',version:3,
    players:[{id:'audit_admin',type:'user',name:'Owner',avatar:'cloud://audit/owner',gender:'male'},
      {id:'guest_audit',type:'guest',name:'Same Name',gender:'male'}],playerIds:['audit_admin','guest_audit'],rounds:[],rankings:[]};
  const s=makeDb({tournaments:{audit_t:t}});
  const main=loadMain('joinTournament',s.db,'audit_unrelated');
  const event={tournamentId:'audit_t',nickname:'Same Name',avatar:'cloud://audit/stranger',gender:'male',clientRequestId:'audit_join'};
  const out=await main(event);
  assert.equal(out.ok,true);assert.equal(out.claimed,true);assert.equal(out.claimedGuestId,'guest_audit');
  const after=s.read('tournaments','audit_t');
  assert.equal(after.players.some(p=>p.id==='guest_audit'),false);
  assert.equal(after.players.some(p=>p.id==='audit_unrelated'),true);
  return {id:'BIZ-02',title:'Ordinary join silently claims a uniquely matching guest name',confirmed:true,
    explicitClaimFieldPresent:Object.hasOwn(event,'claimParticipantId'),responseCode:out.code,claimed:out.claimed,
    beforeIds:t.playerIds,afterIds:after.playerIds,
    scope:'ordinary draft join; identity policy conflict with current singles no-auto-binding requirement, no co-manager escalation claimed'};
}
async function sameScoreRetryFinishedFlag() {
  const t={_id:'audit_score',creatorId:'audit_owner',mode:'singles_round_robin',status:'running',version:5,
    rules:{pointsPerGame:21},players:[{id:'audit_owner',name:'Owner'},{id:'audit_other',name:'Other'}],
    rounds:[{roundIndex:0,matches:[
      {matchIndex:0,status:'finished',teamA:[{id:'audit_owner'}],teamB:[{id:'audit_other'}],score:{teamA:21,teamB:18},scorerId:'audit_owner',scorerName:'Owner'},
      {matchIndex:1,status:'pending',teamA:[{id:'audit_other'}],teamB:[{id:'audit_owner'}],scoreA:null,scoreB:null}
    ]}]};
  const s=makeDb({tournaments:{audit_score:t}});
  const main=loadMain('submitScore',s.db,'audit_owner');
  const response=await main({tournamentId:'audit_score',roundIndex:0,matchIndex:0,scoreA:21,scoreB:18,clientRequestId:'audit_score_retry'});
  assert.equal(response.code,'SCORE_SUBMIT_DEDUPED');assert.equal(response.finished,true);
  assert.equal(s.read('tournaments','audit_score').status,'running');assert.equal(s.writes.length,0);
  const emitted=[];
  const previousWx=global.wx;
  global.wx={reportEvent:(eventName,payload)=>emitted.push({eventName,payload}),getAccountInfoSync:()=>({miniProgram:{envVersion:'develop',version:'0.0.0'}})};
  const {normalizeCloudResult}=require(path.join(repo,'miniprogram/core/cloud'));
  const tracker=require(path.join(repo,'miniprogram/core/activityTracker'));
  const normalized=normalizeCloudResult(response,'submitScore');
  const operation=tracker.begin('submitScore');
  tracker.finish(operation,normalized);
  global.wx=previousWx;
  assert.equal(normalized.state,'deduped');
  const completion=emitted.find(e=>e.payload.action==='tournament_complete');
  assert.equal(completion.payload.resultCode,'FINISHED_CONFIRMED');
  return {id:'BIZ-03',title:'Same-score retry reports overall finished for an unfinished tournament',confirmed:true,
    storedTournamentStatus:'running',remainingPendingMatches:1,responseCode:response.code,responseFinished:response.finished,
    normalizedState:normalized.state,writes:s.writes.length,emittedAction:completion.payload.action,emittedResultCode:completion.payload.resultCode,
    scope:'real score handler + real result normalization + real activityTracker; event capture stays in memory; no live cloud or analytics calls'};
}
(async()=>{
  const results=[];
  results.push(await legacyCreateRace());
  results.push(await guestAutoClaim());
  results.push(await sameScoreRetryFinishedFlag());
  const report={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',method:'production handlers with in-memory SDK substitute',results};
  fs.writeFileSync(path.join(__dirname,'reproduce-business.results.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
