'use strict';
// Exercise the unchanged score submission service and its real view model using
// deterministic remote responses. No native UI or cloud services are contacted.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const repo=path.resolve(process.env.AUDIT_REPO || path.join(__dirname,'../../repo'));
const {createMatchSubmitService}=require(path.join(repo,'miniprogram/pages/match/matchSubmitService'));
const {buildTournamentViewState}=require(path.join(repo,'miniprogram/pages/match/matchViewModel'));
const clone=v=>structuredClone(v);
const initial={_id:'offline_scoring',mode:'multi_rotate',name:'Offline audit',status:'running',version:1,
  players:['owner','b','c','d'].map(id=>({id,name:id})),
  rounds:[{roundIndex:0,matches:[{matchIndex:0,status:'pending',teamA:[{id:'owner'},{id:'b'}],teamB:[{id:'c'},{id:'d'}]}]}]};
const corrected=clone(initial);corrected.version=3;corrected.status='finished';corrected.updatedAt=new Date('2026-10-09T00:00:02Z');
Object.assign(corrected.rounds[0].matches[0],{status:'finished',score:{teamA:18,teamB:21},scorerId:'b',scorerName:'Second scorer'});
const toasts=[];global.wx={showLoading(){},hideLoading(){},showToast(v){toasts.push(v.title);},getStorageSync(){},setStorageSync(){}};
const ctx={data:{tournamentId:initial._id,roundIndex:0,matchIndex:0,scoreA:21,scoreB:18,canEdit:true,userCanScore:true,batchMode:false,
  tournament:clone(initial),match:clone(initial.rounds[0].matches[0]),lockState:'locked_by_me',lockOwnerId:'owner',lockOwnerName:'First scorer',lockExpireAt:Date.now()+45000},
  _latestTournament:clone(initial),_lastAppliedDocTs:0,_pageLifecycleSeq:1,_draft:{scoreA:21,scoreB:18},
  setData(v){this.data={...this.data,...v};},
  applyTournament(t){
    const state=buildTournamentViewState(t,{tournamentId:this.data.tournamentId,roundIndex:0,matchIndex:0,openid:'owner',
      lockState:this.data.lockState,currentScoreA:this.data.scoreA,currentScoreB:this.data.scoreB,draft:this._draft,undoSize:0});
    this._latestTournament=state.tournament;this.data={...this.data,...state.data};
  },
  async fetchTournament(){this.applyTournament(clone(corrected));return clone(corrected);},
  clearLastFailedAction(){},setLastFailedAction(){},handleWriteError(e){throw e;},
  matchDraft:{getScoreDraft(){return ctx._draft;},clearScoreDraft(){ctx._draft=null;},clearUndo(){}},
  lockController:{buildScoreLockPayload(){return {lockSessionId:'offline_session'};},
    setLockState(state){ctx.data.lockState=state;},applyScoreLockResult(v){ctx.data.lockState=v.state;}},
  isPageActive(){return true;}
};
const service=createMatchSubmitService(ctx,{
  cloud:{async call(){return {ok:true,code:'SCORE_SUBMITTED',version:2,finished:true,scorerName:'First scorer'};}},
  storage:{get(key,fallback){return key==='score_auto_next'||key==='score_auto_return'?false:fallback;}},
  nav:{markRefreshFlag(){}}
});
(async()=>{
  await service.submit({clientRequestId:'offline_submit'});
  const observed=ctx._latestTournament.rounds[0].matches[0];
  assert.equal(ctx._latestTournament.version,3);
  assert.deepEqual(observed.score,{teamA:21,teamB:18});
  assert.equal(observed.scorerId,'owner');
  assert.equal(toasts.includes('已提交'),true);
  assert.equal(ctx.data.syncUsingCache,false);
  assert.equal(ctx.data.showStaleSyncHint,false);
  const report={id:'BIZ-05',title:'Successful submit fallback overwrites a newer authoritative correction locally',confirmed:true,
    submitResponse:{version:2,score:{teamA:21,teamB:18}},
    authoritativeRefresh:{version:3,score:corrected.rounds[0].matches[0].score,scorerId:'b'},
    finalLocal:{version:ctx._latestTournament.version,score:observed.score,scorerId:observed.scorerId,syncUsingCache:ctx.data.syncUsingCache,showStaleSyncHint:ctx.data.showStaleSyncHint},
    scope:'client projection is wrong and marked current; no claim that it overwrites the server correction',toasts};
  fs.writeFileSync(path.join(__dirname,'reproduce-client-score.results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
