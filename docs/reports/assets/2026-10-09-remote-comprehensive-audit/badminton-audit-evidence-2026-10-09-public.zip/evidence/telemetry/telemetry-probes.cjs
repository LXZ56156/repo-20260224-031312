'use strict';
// New counterexamples / metric identifiability probes against unchanged production modules.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = process.env.AUDIT_REPO ? path.resolve(process.env.AUDIT_REPO) : path.resolve(__dirname, '../../repo');
const output = {};

async function eventShape() {
  const cloud = require(path.join(root, 'miniprogram/core/cloud'));
  const growth = require(path.join(root, 'miniprogram/core/growthTracker'));
  const previous = { wx: global.wx, info: console.info };
  const sent = [];
  const answers = [];
  let sdkCalls = 0;
  try {
    console.info = () => {};
    global.wx = {
      getAccountInfoSync: () => ({ miniProgram: { version: '6.1.2', envVersion: 'release' } }),
      reportEvent: (name, payload) => sent.push({ name, payload }),
      cloud: { callFunction: async () => { sdkCalls += 1; return { result: answers.shift() }; } }
    };
    const input = { tournamentId: 'synthetic_tournament', mode: 'singles_round_robin', playerCount: 6, courtCount: 2, cycleCount: 1, clientRequestId: 'synthetic_create' };
    answers.push({ ok: true, code: 'TOURNAMENT_CREATED' });
    await cloud.call('createTournament', input, { retry: false });
    const create = sent.slice();
    assert.equal(create.length, 2);
    assert.equal(Object.keys(create[1].payload).length, 17);
    assert.equal(['mode', 'playerCount', 'courtCount', 'cycleCount', 'tournamentId'].some(key => key in create[1].payload), false);
    growth.track('ranking_view', { tournamentId: input.tournamentId, mode: input.mode, status: 'finished', src: 'ranking', playerCount: 6, courtCount: 2, cycleCount: 1 });
    const old = sent[sent.length - 1];
    assert.equal(old.payload.m, 'singles_round_robin');
    assert.equal('operationId' in old.payload, false);

    const codes = [];
    for (const code of ['CLIENT_REQUEST_ID_REUSED', 'WATER_JOIN_REQUIRED', 'WATER_ROOM_FORBIDDEN', 'WATER_WRITES_DISABLED']) {
      answers.push({ ok: false, code, state: 'forbidden' });
      await cloud.call('waterSession', { apiVersion: 2, action: 'recordGame', clientRequestId: `synthetic_${code}` }, { retry: false });
      codes.push({ backendCode: code, reportedCode: sent[sent.length - 1].payload.resultCode });
    }
    const beforeComplete = sent.length;
    answers.push({ ok: true, finished: true, code: 'SCORE_SUBMITTED' });
    answers.push({ ok: true, finished: true, deduped: true, code: 'SCORE_SUBMIT_DEDUPED' });
    for (let index = 0; index < 2; index += 1) await cloud.call('submitScore', { clientRequestId: 'synthetic_same_finished_intent' }, { retry: false });
    const complete = sent.slice(beforeComplete).filter(event => event.payload.action === 'tournament_complete');
    assert.equal(complete.length, 2);
    assert.equal(new Set(complete.map(event => event.payload.intentId)).size, 1);
    output.shapes = { activityFields: Object.keys(create[1].payload), growthFields: Object.keys(old.payload), growthMode: old.payload.m, sdkCalls, generatedEvents: sent.length };
    output.collapsedKnownBusinessCodes = codes;
    output.finishedObservation = { callsSameIntent: 2, finishedObservationEvents: complete.length, distinctEventIds: new Set(complete.map(event => event.payload.eventId)).size, identicalIntent: new Set(complete.map(event => event.payload.intentId)).size === 1, results: complete.map(event => event.payload.result) };
  } finally { global.wx = previous.wx; console.info = previous.info; }
}

function reportCounterexamples() {
  const { buildReport } = require(path.join(root, 'scripts/cloud-ops-daily-report'));
  const window = { start: '2026-10-08 00:00:00', end: '2026-10-08 23:59:59', timeZone: 'Asia/Shanghai' };
  const row = (id, duration) => ({ timestamp: '2026-10-08 20:00:00.000', content: { function_name: 'waterSession', request_id: id, src: 'system', retry_num: 0, status_code: 200, duration } });
  const report = values => buildReport(window, [{ name: 'synthetic-null-duration', kind: 'raw', pages: [{ inputContext: '', response: { meta: { startTime: window.start, endTime: window.end, envId: 'synthetic-env', queryString: 'function_name:*', listOver: true, context: '', returnCount: values.length }, data: { results: values.map((value, index) => row(`synthetic-${index}`, value)) } } }] }]);
  const allNull = report([null, null, null]);
  assert.equal(allNull.functions.waterSession.requestP95Ms, 0);
  assert.equal(allNull.functions.waterSession.durationCoverage, 3);
  const whitespace = report([' ', false]);
  assert.equal(whitespace.functions.waterSession.durationCoverage, 2);
  const absent = report([undefined]);
  assert.equal(absent.functions.waterSession.durationCoverage, 0);
  output.nullDurationCounterexample = {
    suppliedDurations: [null, null, null], actual: allNull.functions.waterSession,
    expected: { requestP95Ms: null, durationCoverage: 0 }, reportComplete: allNull.complete,
    blankOrBooleanAccepted: whitespace.functions.waterSession.durationCoverage,
    missingPropertyControl: absent.functions.waterSession.durationCoverage
  };
}

async function main() {
  await eventShape();
  reportCounterexamples();
  output.scope = 'Synthetic wx SDK capture and offline CLS-shaped input only. Event send calls do not prove platform acceptance. Finish counts are an intentionally limited observation, not a newly discovered completion algorithm defect.';
  fs.writeFileSync(path.join(__dirname, 'telemetry-results.json'), JSON.stringify(output, null, 2) + '\n');
  console.log(JSON.stringify(output, null, 2));
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
