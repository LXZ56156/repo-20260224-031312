'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const root = process.env.AUDIT_REPO ? path.resolve(process.env.AUDIT_REPO) : path.resolve(__dirname, '../../repo');
const output = {};

function loadPage(relative, mockedModules = {}) {
  const originalLoad = Module._load;
  const originalPage = global.Page;
  let definition;
  Module._load = function(request, ...args) {
    if (Object.prototype.hasOwnProperty.call(mockedModules, request)) return mockedModules[request];
    return originalLoad.call(this, request, ...args);
  };
  global.Page = options => { definition = options; };
  const file = path.join(root, relative);
  delete require.cache[file];
  try { require(file); } finally { Module._load = originalLoad; global.Page = originalPage; }
  return { ...definition, data: structuredClone(definition.data), setData(patch, callback) { Object.assign(this.data, patch); if (callback) callback(); } };
}

async function filteredWater() {
  const bundle = {
    room: { id: 'synthetic_water', roomVersion: 1, syncVersion: 1, participants: [{ id: 'a', name: 'synthetic_a', claimed: true }, { id: 'b', name: 'synthetic_b', claimed: true }] },
    round: { id: 'synthetic_round', number: 1, title: 'synthetic', status: 'active', recordCount: 0, activeRecordCount: 0, eventCount: 0, revision: 1, ledger: [] },
    viewer: { role: 'owner', participantId: 'a' },
    capabilities: { v2Read: true, canOwnerWrite: true, canManageRoster: true, emergencyReadOnly: false },
    entries: [], page: { latestSeq: 0, hasMore: false, nextBeforeSeq: null }
  };
  const calls = [];
  let recentWrites = 0;
  const page = loadPage('miniprogram/pages/water/index.js', {
    '../../core/waterSession': {
      getV2: async () => { calls.push('get'); return { ok: true, data: structuredClone(bundle) }; },
      listEntries: async () => { calls.push('listEntries'); return { ok: true, data: { entries: [], page: { latestSeq: 0, hasMore: false } } }; }
    },
    '../../core/waterRecent': { rememberLedger() { recentWrites += 1; } }
  });
  page.applyRoomData(bundle);
  const counts = [];
  for (const filter of ['all', 'game', 'direct']) {
    page.data.feedFilter = filter;
    calls.length = 0;
    recentWrites = 0;
    for (let index = 0; index < 3; index += 1) await page.loadRoom({ silent: true });
    counts.push({ filter, unchangedRefreshes: 3, getCalls: calls.filter(action => action === 'get').length, listEntriesCalls: calls.filter(action => action === 'listEntries').length, recentLedgerWrites: recentWrites });
  }
  assert.deepEqual(counts.map(row => row.listEntriesCalls), [0, 3, 3]);
  page.onUnload();
  output.waterUnchangedRefresh = counts;
}

async function cacheAndHome() {
  const storage = require(path.join(root, 'miniprogram/core/storage'));
  const saved = new Map();
  const previous = { wx: global.wx, getApp: global.getApp };
  let remoteGets = 0;
  try {
    global.getApp = () => ({ globalData: {} });
    global.wx = {
      getStorageSync: key => saved.get(key),
      setStorageSync: (key, value) => saved.set(key, structuredClone(value)),
      removeStorageSync: key => saved.delete(key),
      cloud: { database: () => ({ command: { in: ids => ids }, collection: () => ({ where: () => ({ get: async () => { remoteGets += 1; return { data: [] }; } }) }) }) }
    };
    for (let index = 0; index < 125; index += 1) {
      const id = `synthetic_cache_${index}`;
      storage.addRecentTournamentId(id);
      storage.setLocalTournamentCache(id, { _id: id, status: 'draft', version: 1, rounds: [] });
    }
    const fullCacheKeys = [...saved.keys()].filter(key => key.startsWith('local_tournament_cache_') && !key.startsWith('local_tournament_cache_at_'));
    output.cacheRetention = { tournamentsVisited: 125, recentIds: storage.getRecentTournamentIds().length, retainedFullDocumentCaches: fullCacheKeys.length };
    assert.equal(output.cacheRetention.recentIds, 20); assert.equal(fullCacheKeys.length, 125);
    const page = loadPage('miniprogram/pages/home/index.js');
    page.data.sortMode = 'updated';
    for (const mode of ['players', 'status', 'updated']) {
      page.onChangeSortMode({ currentTarget: { dataset: { mode } } });
      for (let index = 0; index < 5; index += 1) await Promise.resolve();
    }
    output.homeSort = { sortChanges: 3, remoteTournamentQueries: remoteGets };
    assert.equal(remoteGets, 3);
  } finally { global.wx = previous.wx; global.getApp = previous.getApp; }
}

async function avatarOverlap() {
  const avatar = require(path.join(root, 'miniprogram/core/avatarDisplay'));
  const previous = { wx: global.wx, setTimeout: global.setTimeout, clearTimeout: global.clearTimeout, info: console.info, warn: console.warn };
  const pending = [];
  const fileId = 'cloud://synthetic.bucket/avatar.png';
  const cache = {};
  try {
    global.setTimeout = () => ({ syntheticTimer: true });
    global.clearTimeout = () => {};
    console.info = () => {}; console.warn = () => {};
    global.wx = {
      cloud: { getTempFileURL({ fileList }) { return new Promise(resolve => pending.push({ fileList, resolve })); } }
    };
    const first = avatar.resolveCloudAvatarFileIds([fileId, fileId], cache);
    const second = avatar.resolveCloudAvatarFileIds([fileId], cache);
    const third = avatar.resolveCloudAvatarFileIds([fileId], cache);
    assert.equal(pending.length, 3);
    for (const request of pending) request.resolve({ fileList: [{ fileID: fileId, status: 0, tempFileURL: 'https://synthetic.invalid/avatar.png' }] });
    await Promise.all([first, second, third]);
    const later = await avatar.resolveCloudAvatarFileIds([fileId], cache);
    assert.equal(later.requested.length, 0);
    output.avatarParallelResolution = { identicalColdRequests: 3, actualSdkCallsBeforeAnyResponse: pending.length, idsPerBatch: pending.map(row => row.fileList.length), cachedSubsequentRequest: later.requested.length };
  } finally { global.wx = previous.wx; global.setTimeout = previous.setTimeout; global.clearTimeout = previous.clearTimeout; console.info = previous.info; console.warn = previous.warn; }
}

async function main() {
  await filteredWater();
  await cacheAndHome();
  await avatarOverlap();
  output.scope = 'Real page/core functions with synthetic wx and API stubs, no native rendering or real network. Latency, billing and actual usage frequency remain unmeasured.';
  fs.writeFileSync(path.join(__dirname, 'frontend-resource-results.json'), JSON.stringify(output, null, 2) + '\n');
  console.log(JSON.stringify(output, null, 2));
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
