# 注册页面、导航与配置静态收口

基线：`a3fe96f25015892ac30ee7148f97a5b441b0cb24`。本检查只读取隔离的远端源码；没有连接 GUI、开发者工具、用户设备或真实云服务，没有调用预览、上传、部署命令。检查产物位于业务仓库外，源码树保持 clean。

## 结论

16 个注册页面的 `.js/.json/.wxml/.wxss` 文件全部齐全；可解析的 208 个入口、组件、模块、模板、样式及本地资源文件依赖未发现缺失；解析到的页面路径字面量全部已注册。打包忽略规则没有命中本次可达依赖闭包。这里的“通过”只指静态完整性，不代表页面已通过真机显示、交互或像素验收。

另有一个低优先级的外部参数边界：资料页对 `returnUrl` 无保护解码，畸形百分号转义会提前中断 `onLoad`。开发、体验、正式三种环境共用源码中的同一云环境，且云函数运行时没有在已检查配置中显式固定；这些属于配置边界，不能据此推定真实生产权限或部署状态。

## 1. 页面覆盖

依据 `miniprogram/app.json`。三项 tabBar 与公共导航 `core/nav.js:5–9` 保持一致。

| 注册路由 | 原生 tabBar | 页面文件 |
|---|---|---|
| `/pages/home/index` | 是 | 4/4 |
| `/pages/launch/index` | 是 | 4/4 |
| `/pages/mine/index` | 是 | 4/4 |
| `/pages/tournament-list/index` | 否 | 4/4 |
| `/pages/profile/index` | 否 | 4/4 |
| `/pages/feedback/index` | 否 | 4/4 |
| `/pages/share-entry/index` | 否 | 4/4 |
| `/pages/water/index` | 否 | 4/4 |
| `/pages/create/index` | 否 | 4/4 |
| `/pages/lobby/index` | 否 | 4/4 |
| `/pages/schedule/index` | 否 | 4/4 |
| `/pages/match/index` | 否 | 4/4 |
| `/pages/ranking/index` | 否 | 4/4 |
| `/pages/analytics/index` | 否 | 4/4 |
| `/pages/settings/index` | 否 | 4/4 |
| `/pages/preferences/index` | 否 | 4/4 |

应用入口 `app.js/app.json/app.wxss`、`sitemap.json`、6 个 tab 图标均存在。没有注册分包。本次并未因为源码文件完整就推定每个空态、长列表或弹窗都能正确显示。

## 2. 本地组件与资源

唯一业务页面组件声明为 `pages/water/index.json` 的 `van-popup`；递归可达依赖为 Vant 的 popup、icon、overlay、transition、info，共 5 个组件，四类组件文件与进一步 WXML include/import、WXS、WXSS import 和本地 JS require/import 均能解析到文件。仓库实际跟踪 466 个 Vant 构建文件；组件依赖完整不代表这 466 个文件全部进入最终发布包。

扫描以 16 页、应用入口与 tab 图标为起点，取得 208 个可达文件，缺失为 0；在模板/样式依赖处理中遇到 12 个动态引用和 2 个外部引用，不把它们计为已经验证可用的本地文件。JS 中的数据驱动头像、云存储资源等仍需运行时证据。

`project.config.json` 的排除项为 node_modules、三张本地分享底图模式及 Vant uploader。依赖闭包与排除项交集为 0。`core/shareCard.js` 的底图来源实际为云存储，排除本地同名图片不构成已证实的缺文件错误；本次没有请求这些云对象。Vant icon 使用的外部字体同样没有做联网可用性验收。

## 3. 导航覆盖与一个输入边界

扫描自身 JS/JSON/WXML 中可解析的 `pages/...` 路径，全部对应注册页面。人工核对了公共 `core/nav.js`、`core/matchPrimaryNav.js`、`core/profile.js`、`pages/share-entry/flow.js`，以及 launch/create/profile/share-entry/water/schedule 的关键跳转调用。

公共 `nav.js:196–247` 会将三个 tab 目标转给 `switchTab`，并在切换 tab 时去掉 query/hash；普通赛事页通过 `buildTournamentUrl` 对 query 编码。主要路径包括发起→资料完善→创建→大厅，分享入口→大厅/对阵/复盘，赛事内比赛/排名/对阵互转，以及打水新建/历史/最近账本；这些静态目标都有注册。没有将 `matchPrimaryNav` 的“比赛”指向大厅当成漏注册页错误，因为这是现有主导航映射。

### UI-01：畸形 returnUrl 解码可能中断资料页初始化（P3）

`miniprogram/pages/profile/index.js:32–36` 在读取本地资料和同步云资料之前直接执行 `decodeURIComponent(options.returnUrl)`，没有 try/catch。非空裸百分号或非法 UTF-8 转义会触发 `URIError`，导致这个 onLoad 提前退出。正常内部 URL 构造会编码参数，因此影响条件是外部传入的畸形 query。该结论来自明确代码路径和 JS 解码语义，没有进行真机复现，也不应扩大为任意外部跳转或账号安全漏洞。

建议保护解码异常并回退到空或已注册的内部目标。对所有数据依赖跳转、页面栈极限、快速连点和异常恢复没有在本轮追加逐页测试。

## 4. 敏感配置与权限边界

只记录文件位置和类别，不包含密钥、环境标识或应用标识值。

| 文件/位置 | 类别 | 静态事实及实际边界 |
|---|---|---|
| `miniprogram/config/env.js:1–18,21–40`；`app.js:25–31` | 运行环境标识 | develop/trial/release 共用同一默认云环境；DEV/TRIAL/PROD 标签不隔离数据。环境版本取值未知时回退 release。实际发布包与服务端运行环境未验证。 |
| `project.config.json`；`.cloudbaserc.json`；`cloudbaserc.json` | 应用、云环境配置标识 | 均有配置；两份 CloudBase 配置的环境标识相同。标识属于连接配置，不把它们当作密钥值输出。 |
| `.env.local.example:2–14`；`.gitignore:31–41`；`scripts/mp-ci.js:182–201` | CI 密钥、私钥路径、云凭据 | 例子中的密钥字段为占位值；按受控文件名扫描未发现已跟踪的真实 env/private/pem/key 文件。此结论不是完整历史密钥扫描，也没有读取本机实际凭据。 |
| `miniprogram/app.json`；profile/lobby 头像按钮；`core/sharePoster.js:504–520` | 个人资料、相册功能 | app 配置没有 permission、requiredPrivateInfos、plugin 或后台定位声明；业务代码存在用户选择头像、保存相册入口，未见一方定位/手机号/支付调用。微信后台隐私声明和实际同意状态未取证。 |
| `sync/watch.js:98,180,359`；`core/tournamentSync.js:79`；`pages/home/index.js:416` | 客户端直读数据库 | 客户端直接读取/监听 tournaments，是否允许及范围必须由实际云规则控制；不能用界面按钮权限替代云规则。当前线上规则未知。 |
| `cloudfunctions/*/config.json` | 云 OpenAPI 权限 | 10 个声明文件：8 个更新动态消息、1 个创建消息活动 ID、1 个生成小程序码权限。仅证明代码声明，未证明平台实际授权。 |
| `miniprogram/sitemap.json` | 搜索可见性 | 9 个 allow 规则，5 个具体 disallow 和末尾 wildcard disallow；用户资料等私有页明确排除，部分赛事页允许索引。搜索索引设置不是数据库授权。 |

## 5. 打包与运行配置

应用根为 `miniprogram/`，云函数根为 `cloudfunctions/`。项目配置基础库 `3.14.2`，启用 URL 检查、ES6、代码与 WXML/WXSS 压缩；手工 NPM 构建关系指向 `miniprogram/package.json`，前端 Vant 固定 `1.11.7`，构建产物已存在。项目设置 `uploadWithSourceMap:true`，并不能单凭这一项断定源码对用户公开；本轮没有读取实际上传包或源码映射访问控制。

`cloudbaserc.json` 声明的 26 个函数与 26 个含 package.json 的目录名称完全一致，均要求安装依赖，SDK 固定为 `2.6.3`。startTournament 显式 timeout=10；其余运行时、内存、并发、网络和超时实值没有由当前清单完整固定。26 个函数配置没有 runtime 声明，package 也未用 engines 固定 Node；不能从本地运行成功推出实际云端 Node 一致。

`mp-ci.js:195–210` 使用环境变量中的应用标识和私钥路径创建 CI Project，显式忽略 node_modules 并启用压缩。最终 CI 打包是否完整遵循项目忽略项、包体大小、正式版本是否为当前 SHA，需要实际预览/上传清单；本检查没有运行这些写入步骤。

## 6. 本轮未做

真机像素、不同屏幕/字体大小、触控和无障碍、长数据排版；真实云对象/CDN 下载；实际数据库和存储权限、隐私后台配置；云函数运行时/内存/超时；最终发布包内容/大小；所有动态或畸形 URL 的逐页验证。以上项目不标为已通过。

机器证据见同目录 `ui-config-coverage.json`，逐页文件状态、每条本地依赖和静态路由均已保留。扫描仅证明可解析引用集合，未使用它推断真实活跃用户、云成本或线上可用性。
