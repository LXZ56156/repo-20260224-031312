'use strict';

// Offline audit instrumentation. Production modules are required unchanged.
// Synthetic identities/data only; no SDK, network, real database or app session.
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const root = process.env.AUDIT_REPO ? path.resolve(process.env.AUDIT_REPO) : path.resolve(__dirname, '../../repo');
const output = {};
const copy = value => structuredClone(value);
const stable = (prefix, value) => `${prefix}_${crypto.createHash('sha1').update(value).digest('hex').slice(0, 20)}`;
const owner = 'synthetic_audit_owner';
const flags = {
  emergencyReadOnly: false, v2Read: true, rosterWrite: true, ownerWrite: true,
  memberWrite: true, correctWrite: true, reverseWrite: true, createRoundWrite: true,
  canaryRoomIds: [], canaryOpenids: [], revision: 1
};

function database(seed = {}) {
  let store = new Map(Object.entries(seed).map(([name, docs]) => [name, new Map(Object.entries(docs).map(([id, value]) => [id, copy(value)]))]));
  const operations = [];
  const record = (type, name, rows = []) => operations.push({ type, name, rows: rows.length, bytes: Buffer.byteLength(JSON.stringify(rows)) });
  const matches = (doc, filter) => Object.entries(filter || {}).every(([key, expected]) => {
    if (expected && typeof expected === 'object') {
      if ('$gt' in expected) return doc[key] > expected.$gt;
      if ('$lt' in expected) return doc[key] < expected.$lt;
      if ('$in' in expected) return expected.$in.includes(doc[key]);
    }
    return doc[key] === expected;
  });
  const collection = (map, name) => {
    if (!map.has(name)) map.set(name, new Map());
    const docs = map.get(name);
    return {
      doc(id) {
        return {
          async get() {
            const rows = docs.has(id) ? [{ _id: id, ...copy(docs.get(id)) }] : [];
            record('docGet', name, rows);
            if (!rows.length) throw new Error('document.get:fail document does not exist');
            return { data: rows[0] };
          },
          async set({ data }) { record('set', name, [data]); docs.set(id, copy(data)); return { _id: id }; },
          async update({ data }) {
            record('update', name, [data]);
            if (!docs.has(id)) return { stats: { updated: 0 } };
            docs.set(id, { ...docs.get(id), ...copy(data) }); return { stats: { updated: 1 } };
          },
          async remove() { record('remove', name); docs.delete(id); return { stats: { removed: 1 } }; }
        };
      },
      where(filter) {
        let limit = Infinity;
        const order = [];
        const query = {
          orderBy(field, direction) { order.push([field, direction === 'desc' ? -1 : 1]); return query; },
          limit(value) { limit = Number(value); return query; },
          async get() {
            let rows = Array.from(docs, ([id, value]) => ({ _id: id, ...copy(value) })).filter(row => matches(row, filter));
            rows.sort((a, b) => {
              for (const [field, direction] of order) {
                if (a[field] !== b[field]) return (a[field] < b[field] ? -1 : 1) * direction;
              }
              return 0;
            });
            rows = rows.slice(0, limit); record('queryGet', name, rows); return { data: rows };
          }
        };
        return query;
      }
    };
  };
  const db = {
    command: { gt: value => ({ $gt: value }), lt: value => ({ $lt: value }), in: value => ({ $in: value }) },
    serverDate: () => new Date('2026-10-08T20:00:00Z'),
    collection: name => collection(store, name),
    async createCollection(name) { record('createCollection', name); if (!store.has(name)) store.set(name, new Map()); },
    async runTransaction(callback) {
      const draft = copy(store);
      const result = await callback({ collection: name => collection(draft, name) });
      store = draft; return result;
    }
  };
  return {
    db, reset: () => { operations.length = 0; },
    read: (name, id) => copy(store.get(name)?.get(id)),
    summary() {
      const totals = {};
      const byCollection = {};
      for (const op of operations) {
        totals[op.type] = (totals[op.type] || 0) + 1;
        const item = byCollection[op.name] ||= { operations: 0, returnedDocuments: 0, readBytes: 0 };
        item.operations += 1;
        if (['docGet', 'queryGet'].includes(op.type)) { item.returnedDocuments += op.rows; item.readBytes += op.bytes; }
      }
      return { totals, databaseReadOperations: (totals.docGet || 0) + (totals.queryGet || 0), byCollection };
    }
  };
}

function loadWater(db) {
  const filename = path.join(root, 'cloudfunctions/waterSession/index.js');
  const original = Module._load;
  Module._load = function(request, ...args) {
    if (request === 'wx-server-sdk') return { init() {}, database: () => db, getWXContext: () => ({ OPENID: owner }), DYNAMIC_CURRENT_ENV: 'synthetic' };
    return original.call(this, request, ...args);
  };
  delete require.cache[filename];
  try { return require(filename).main; } finally { Module._load = original; }
}

function historySeed(count) {
  const seed = { water_feature_flags: { collaborative_v2: flags }, waterRooms: {}, waterRounds: {}, waterRoomMembers: {} };
  for (let index = 0; index < count; index += 1) {
    const room = stable('water', `synthetic_history_${index}`);
    const round = stable('wr', `${room}\n1`);
    const participant = stable('wp', `${room}\nowner`);
    seed.waterRooms[room] = { schemaVersion: 2, migrationStatus: 'active', ownerParticipantId: participant, activeRoundId: round, participants: [{ id: participant, name: 'synthetic', claimed: true }], updatedAtMs: 1000000 + index };
    seed.waterRounds[round] = { roomId: room, participantIds: [participant], recordCount: 0, title: 'synthetic', updatedAtMs: 1000000 + index };
    seed.waterRoomMembers[stable('wm', `${room}\n${owner}`)] = { roomId: room, openid: owner, participantId: participant, role: 'owner', status: 'active' };
  }
  return seed;
}

async function waterCosts() {
  const history = [];
  for (const count of [0, 1, 20, 100, 500, 1000]) {
    const state = database(historySeed(count));
    const main = loadWater(state.db);
    const first = await main({ apiVersion: 2, action: 'listLedgers', limit: 20 });
    assert.equal(first.ok, true, first.message);
    const result = { ledgerCount: count, page1Returned: first.data.ledgers.length, page1: state.summary() };
    assert.equal(result.page1.databaseReadOperations, 2 * count + Math.floor(count / 100) + 4);
    if (first.data.page.hasMore) {
      state.reset();
      const second = await main({ apiVersion: 2, action: 'listLedgers', limit: 20, cursor: first.data.page.nextCursor });
      assert.equal(second.ok, true); result.page2 = state.summary();
      assert.equal(result.page2.databaseReadOperations, result.page1.databaseReadOperations);
    }
    history.push(result);
  }
  output.waterHistory = history;
  const state = database({ water_feature_flags: { collaborative_v2: flags } });
  const main = loadWater(state.db);
  const actions = [];
  const call = async (action, extra = {}) => {
    state.reset();
    const result = await main({ apiVersion: 2, action, ...extra });
    assert.equal(result.ok, true, `${action}: ${result.code} ${result.message}`);
    actions.push({ action, code: result.code, ...state.summary() }); return result;
  };
  const created = await call('createLedger', { ownerName: 'synthetic', clientRequestId: 'audit_create_1' });
  const roomId = created.data.room.id;
  const roundId = created.data.round.id;
  await call('get', { roomId });
  const added = await call('addParticipants', { roomId, names: 'player_b\nplayer_c\nplayer_d', expectedRoomVersion: 1, clientRequestId: 'audit_roster_1' });
  const participants = added.data.room.participants.map(item => item.id);
  const write = { roomId, roundId, winnerIds: participants.slice(0, 2), loserIds: participants.slice(2), unitsPerPlayer: 1, clientRequestId: 'audit_record_1' };
  await call('recordGame', write);
  await call('recordGame', write);
  await call('get', { roomId });
  await call('listEntries', { roomId, roundId, category: 'game', afterSeq: 1, limit: 20 });
  output.waterActions = actions;
}

async function pollingCosts() {
  const watch = require(path.join(root, 'miniprogram/sync/watch.js'));
  let fetches = 0;
  let emissions = 0;
  const delays = [];
  const controller = watch.createPollingController({
    autoStart: false, fetchDoc: async () => { fetches += 1; return { _id: 'synthetic', version: 1 }; },
    onData: () => { emissions += 1; }, jitterFn: value => value,
    setTimeoutFn: (_fn, delay) => { delays.push(delay); return { delay }; }, clearTimeoutFn() {}
  });
  for (let index = 0; index < 10; index += 1) await controller.runOnce();
  controller.close();
  assert.equal(fetches, 10); assert.equal(emissions, 1); assert.equal(new Set(delays).size, 1);
  output.unchangedTournamentPolling = { fetches, emissions, delays, nominalReadsPerViewerHour: 3600000 / 1500 };

  const previous = { wx: global.wx, setTimeout: global.setTimeout, clearTimeout: global.clearTimeout, warn: console.warn };
  const timers = [];
  let gets = 0;
  try {
    global.setTimeout = (fn, delay) => { const timer = { fn, delay }; timers.push(timer); return timer; };
    global.clearTimeout = timer => { if (timer) timer.closed = true; };
    console.warn = () => {};
    global.wx = { getDeviceInfo: () => ({ platform: 'devtools' }), cloud: { database: () => ({ collection: () => ({ doc: () => ({ get: async () => { gets += 1; return { data: { _id: 'synthetic_watch', version: 1 } }; } }) }) }) } };
    const handle = watch.watchTournament('synthetic_watch', () => {}, () => {});
    await Promise.resolve(); await Promise.resolve();
    const afterInit = gets;
    const zero = timers.find(timer => timer.delay === 0 && !timer.closed);
    await zero.fn();
    output.pollingInitialization = { afterInitFetch: afterInit, afterImmediatePolling: gets };
    assert.equal(gets, 2);
    handle.close(); watch.closeWatch('synthetic_watch');
  } finally { global.wx = previous.wx; global.setTimeout = previous.setTimeout; global.clearTimeout = previous.clearTimeout; console.warn = previous.warn; }
}

async function lockOverlap() {
  const { createMatchLockController, LOCK_AUTOPOLL_MS, LOCK_HEARTBEAT_MS } = require(path.join(root, 'miniprogram/pages/match/matchLockController.js'));
  const intervals = new Map();
  const calls = [];
  const ctx = { data: { tournamentId: 'synthetic', roundIndex: 0, matchIndex: 0, userCanScore: true, lockBusy: false, lockState: 'locked_by_other', match: { status: 'pending' } }, setData(patch) { Object.assign(this.data, patch); }, isPageActive: () => true };
  const controller = createMatchLockController(ctx, {
    cloud: { call(_name, payload) { calls.push(payload.action); return new Promise(() => {}); } },
    setIntervalFn(fn, delay) { const timer = { fn, delay }; intervals.set(timer, timer); return timer; }, clearIntervalFn(timer) { intervals.delete(timer); }
  });
  controller.setLockState('locked_by_other', { expireAt: Date.now() + 45000 });
  const statusTimer = [...intervals.values()].find(item => item.delay === LOCK_AUTOPOLL_MS);
  for (let index = 0; index < 4; index += 1) statusTimer.fn();
  assert.equal(calls.filter(action => action === 'status').length, 4);
  controller.setLockState('locked_by_me', { lockSessionId: 'synthetic_lock', expireAt: Date.now() + 45000 });
  const heartbeatTimer = [...intervals.values()].find(item => item.delay === LOCK_HEARTBEAT_MS);
  for (let index = 0; index < 3; index += 1) heartbeatTimer.fn();
  assert.equal(calls.filter(action => action === 'heartbeat').length, 3);
  controller.teardown();
  output.lockOutstandingCalls = { unresolvedStatusAfter4Ticks: 4, unresolvedHeartbeatAfter3Ticks: 3, statusIntervalMs: LOCK_AUTOPOLL_MS, heartbeatIntervalMs: LOCK_HEARTBEAT_MS, activeTimersAfterTeardown: intervals.size };
  assert.equal(intervals.size, 0);
}

async function main() {
  await waterCosts();
  await pollingCosts();
  await lockOverlap();
  output.scope = 'Source-level operation counts with an in-memory instrumented database and controlled timers. No real latency, billing, load, platform receipt or cloud transaction semantics are claimed.';
  fs.writeFileSync(path.join(__dirname, 'resource-results.json'), JSON.stringify(output, null, 2) + '\n');
  console.log(JSON.stringify({ history: output.waterHistory.map(item => ({ ledgers: item.ledgerCount, readCalls: item.page1.databaseReadOperations, page2ReadCalls: item.page2?.databaseReadOperations })), waterActions: output.waterActions.map(item => ({ action: item.action, code: item.code, ...item.totals })), polling: output.unchangedTournamentPolling, initialization: output.pollingInitialization, lock: output.lockOutstandingCalls }, null, 2));
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
