# 使用留痕与资源效率专项审计

## 基准、范围和结论

- 仓库：`LXZ56156/repo-20260224-031312`。
- 固定版本：`a3fe96f25015892ac30ee7148f97a5b441b0cb24`（`master`）。
- 审计日期：2026-10-09，北京时间。
- 方法：读取固定远端源码与合同，在隔离环境直接加载未修改的生产模块，用内存数据库、合成微信接口和受控计时器进行定向复现；未读取或写入真实业务数据库，未运行原生微信客户端、部署、上传或发布。
- 用户给定背景：用户提供的日均约 90 人，人数口径未核实；自然增长，实际用途和使用路径未知。该人数没有作为同时在线人数或账单依据。

**当前已有客户端事件采集代码，但缺少平台配置、实收、逐条查询/导出和可用业务报表的闭环证据。资源方面，已证实历史账本每页全扫描、筛选状态下不变账本重复查询、慢锁请求重叠、赛事完整缓存不随最近列表淘汰；还有首页排序、轮询初始化和头像冷缓存并发等较低优先级的重复请求。**

本报告将已复现问题、现行设计的成本、尚未实现的分析能力和缺少线上证据的风险分别记录。没有把所有轮询都认定为浪费，也没有将源代码中的数据库方法调用次数换算成计费文档数或费用。

## 证据与复跑

| 脚本 | 输出 | 直接验证的内容 |
|---|---|---|
| `resource-probes.cjs` | `resource-results.json` | 实际 waterSession handler 的数据库读写数量；历史第一页/第二页成本；赛事轮询不变数据与初始化双读；锁请求未决重叠与计时器清理 |
| `telemetry-probes.cjs` | `telemetry-results.json` | 实际 activity/growth 字段；固定业务码折叠；finished 观察的重复语义；CLS 缺失耗时被记为零的反例 |
| `frontend-resource-probes.cjs` | `frontend-resource-results.json` | 实际 water 页面不变刷新调用；完整缓存滞留；首页排序远端查询；头像冷态请求缺少跨调用合并 |

三个脚本均无需安装真实微信 SDK，不访问网络，结果中的身份与数据均为合成数据。复跑目录可以任意，脚本按自身位置寻找 `../../repo`：

```bash
node evidence/telemetry/resource-probes.cjs
node evidence/telemetry/telemetry-probes.cjs
node evidence/telemetry/frontend-resource-probes.cjs
```

上述是独立问题复现，不替代根任务的全量测试。它们证明对应源码路径的行为，不能证明云端执行时间、SDK 事务行为、原生生命周期调度或后台接收成功。

## 一、两套事件与两个报表入口

### 1. 新 activity 通道

代码链路为：页面或业务封装 → `core/cloud.call` → `activityTracker.begin` → `wx.reportEvent('activity_attempt', data)`；云调用返回或最终 SDK 异常 → `activityTracker.finish` → `activity_result`。独立打水入口另外发送 `activity_view`；分享入口与赛事分享回调直接调用 tracker。

实际 17 个字段为：`schemaVersion`、`eventId`、`operationId`、`intentId`、`attemptIndex`、`eventTime`、`phase`、`action`、`anonymousSessionId`、`traceId`、`appVersion`、`envVersion`、`result`、`resultCode`、`durationMs`、`retryCount`、`firstEntry`。

采样验证：向真实 `cloud.call` 传入 `mode/playerCount/courtCount/cycleCount/tournamentId` 后，这些字段均不进入 activity 事件。该剔除符合当前隐私合同，说明这些业务维度尚未纳入本通道，不是字段意外丢失。

实现中的合理边界已经确认：

- 单次 `cloud.call` 只有一对 attempt/result；内部网络自动重试仍是同一 operation，最多两次自动重试。
- 手动重试只在同进程、同函数及原始 action、同合法 clientRequestId 的条件下关联 intent；最多 100 组、从首次调用起 30 分钟过期。
- `anonymousSessionId` 是进程内随机值，不能表示跨重启的同一用户。
- 不采读取、锁心跳和锁释放，避免高频后台刷新直接放大新埋点量。
- reportEvent 缺失或抛错不阻塞业务，当前没有持久化队列、独立云接收调用或埋点重发。
- firstEntry 仅在原始记账返回权威 `seq=1` 时为 yes；重放为 replayed，未知不伪造 yes。
- 分享回调结果为 `DELIVERY_UNKNOWN`，没有将按钮调用当成送达。

来源：`miniprogram/core/activityTracker.js:1–210`；`miniprogram/core/cloud.js:471–558`；`miniprogram/core/waterSession.js:18–45`；`miniprogram/pages/water/index.js:541–560`。

### 2. 旧 growth 通道

页面/分享/录分成功等特定路径 → `growthTracker.track` → 控制台诊断与 `wx.reportEvent(原事件名, data)`。字段只有 `t/s/m/src/a/r/ts`。

其中 `m` 支持现有四种赛制，`s` 支持 draft/running/finished，`t` 为 32 位赛事 hash。**因此不能说完全没有赛制数据**；在平台确有实收的前提下，可以观察现有事件覆盖页面的赛制分布。但它没有 operation/session/version/env 字段，与 activity 没有共同的可靠关联键，不能把两个通道拼成逐赛事、逐意图的完整转化漏斗。32 位赛事 hash 也不应升级为长期身份或防碰撞标识。

覆盖位置包括：ranking、analytics、share-entry、match_open、score_submit_success、部分首页复制/回顾、赛事引导与分享入口；创建和开赛的统一请求结果由新 activity 通道覆盖。名单规模、场地数、循环数没有在这两套通道形成统一统计字段。

来源：`miniprogram/core/growthTracker.js:1–68`；`miniprogram/pages/match/matchSubmitService.js:390–425`；各页面 `growthTracker.track` 调用点。

### 3. 平台访问报表和 CLS 运维报表

- `scripts/fetch-we-analysis.js` 读取微信 datacube 的标准访问、页面、画像、留存等接口；`scripts/we-analysis-report.js` 对显式 manifest 的已有响应离线汇总。它们不是自定义 activity 事件接收/查询器。日 UV 累加为人日，不是周期内独立人数；页面 UV 不能直接组成跨页漏斗。
- `scripts/cloud-ops-daily-report.js` 读取显式 manifest 中的 CLS 原始/聚合 JSON，按 function/request 去重，核对查询窗口和分页，区分平台成功与业务成功，并报告耗时覆盖。它没有解析或保留 activity 的 action/eventId/operationId，也不提供 reportEvent 的逐条实收对账。
- 本轮远端源码不含合同提到的独立 `reportOpsActivityEvents` 接收包原件；既有合同明确该包与当前字段/ID/事件枚举不兼容。不能把旧包描述或 `ENABLE` 开关当成当前通道可直接启用的证据。

来源：`scripts/fetch-we-analysis.js:14–24`；`scripts/we-analysis-report.js:118–171`；`scripts/cloud-ops-daily-report.js:29–42,74–220`；`docs/specs/activity-observability.md`。

## 二、指标可用性与缺口矩阵

下表中的“可统计”均以平台实际接收、字段保留和查询能力得到验证为前提；本轮没有取得该前提的线上回执。

| 需要回答的问题 | 当前可利用的源码能力 | 当前无法证明或缺少的环节 | 最小补齐方向 |
|---|---|---|---|
| 每天多少人、多少新用户、哪些页面有访问 | 标准 datacube 访问/页面/留存入口 | 本轮无新完整日期窗口原始响应；activity session 不能替代人数 | 使用标准统计的明确口径，保留日期和完整性，不重造身份统计 |
| 哪些赛制实际常用 | growth 的部分页面与成功事件含 m | 创建/开赛结果不含 mode；现有页面选择偏差；后台实收未知 | 在获批匿名合同中对关键业务动作加入固定 mode 枚举，再核实接收 |
| 活动人数、场地、循环数通常是多少 | 两通道无统一规模字段 | 无可靠规模分布 | 使用整数或明确分桶；字段从已验证业务状态取值，禁止自由文本 |
| 创建后没有开赛的比例 | activity 有 create/start 的独立操作 | 缺少同一赛事匿名关联键、创建队列、观察期及取消定义 | 先定义赛事级匿名关联和窗口，不用同一进程的事件先后关系强行配对 |
| 开赛、录分、更正分别失败在哪里 | activity 的 attempt/result、retryCount、固定结果码；CLS 有函数级失败 | 没有平台实收；部分码折叠；调用失败之后的恢复读取没有关联结果 | 保留调用结果与最终恢复结果的区别，添加窄范围权威恢复事件；补已知固定码 |
| 真实赛事完赛率 | score_submit 可派生 finished 状态观察；手动结束有独立 action | 无创建/开赛队列关联；不能由状态观察证明首次完赛；另有后端 finished 语义缺陷需先修复 | 先修正后端字段，再定义完成状态转换/观察去重与队列关联 |
| 打水到底有没有被使用 | water_enter、create、add、recordGame/recordDirect 等事件存在 | 页面进入可能只是打开；实收未知；没有打开成功的完整统一漏斗 | 以成功原始记账作为使用证据之一，分别统计访问、创建、加入、首笔和失败 |
| 新账本 7 日首笔率 | firstEntry 能区分权威 seq=1、普通后续、重放、未知 | 缺少账本创建队列与匿名账本关联、完整 7 日窗口、导入历史排除 | 定义匿名账本键与创建时点；原始记账只计首次；更正/重试不扩大分子 |
| 分享入口打开后是否参与 | share_enter 有目标确认/缺失/失败/离开；join 有结果 | activity 无目标关联；旧 growth 不可可靠拼接到新 activity | 同一获批匿名目标关联；确认身份门控和恢复结果的具体口径 |
| 分享是否送达、取消、被谁接收 | 仅实际分享 hook 调用计数；结果明确 unknown | 无送达回执，不能从发起分享调用推导 | 保留 unknown；接收端真实入口行为独立统计，不捏造发送成功 |
| 用户是群主、球友、俱乐部还是比赛组织者 | 行为事件无法直接回答 | 没有真实画像调查 | 后续少量可跳过问题，出现频率受限；本轮不实施弹窗 |
| 每个功能耗费多少云资源 | 代码可建立单位动作模型；CLS 可给调用与耗时 | 没有真实业务动作数、查看时长、数据库读写明细及账单 | 获取同窗口调用、动作、查看端时长、数据库读写/传输再核算 |
| 测试流量是否被排除 | activity 有 envVersion；运维报告有缺参烟测候选 | growth 无版本/环境；共用云环境历史请求可能缺版本；候选不等于测试 | 明确版本/环境和受控测试旅程标识，不将缺参请求一律判测试 |

完成留痕闭环所需证据顺序：明确平台接受的事件定义和字段 → 真实受控旅程 → 平台接收/拒绝/去重计数 → 可读取查询或导出 → 同事件 ID 对账 → 窗口完整性与报表。若平台只给聚合而不给逐 ID 查询，应明确无法做精确运输去重/配对，再按真实能力设计统计，不臆造导出 schema。

## 三、已复现问题

### TEL-01 / P2：缺失耗时被当作 0，导致运维 P95 与覆盖率虚假

- 位置：`scripts/cloud-ops-daily-report.js:161–162,194,202–204`。
- 触发：合法窗口和分页元数据的原始 CLS 记录，其 duration 为 JSON `null`、空白字符串或布尔 `false`。
- 实际：代码先 `Number(duration)`，再只排除空字符串和非有限数；null/空白/false 均成为 0。三条 null 得到 `complete:true`、`durationCoverage:3`、`requestP95Ms:0`。
- 预期：三条没有数值耗时的数据应保持 `durationCoverage:0`、`requestP95Ms:null`；必要时单列非法/缺失耗时数量。不能用虚构的零值参与百分位。
- 影响：在实际导出包含上述值时，会低估耗时并高估测量覆盖；没有证据表明历史线上报告已经受影响。
- 建议：先做类型/非空白检查，再接受有限非负数值；保留缺失与真实 0 的区别。增加直接反例回归即可。
- 证据：`telemetry-results.json.nullDurationCounterexample`。

### EFF-01 / P2：历史账本“分页”每一页都重新全量读取所有账本

- 位置：`cloudfunctions/waterSession/index.js:1738–1822`，特别是 `1755–1790` 的全量成员扫描、逐个 room/round 读取以及 `1810–1819` 的内存排序后分页。
- 触发：调用者有 M 个有效 V2 账本，打开第一页或继续翻页；测试中没有额外稳定旧账本。
- 实际：每页数据库读取方法调用次数为 `2M + floor(M/100) + 4`。其中 membership 分页查询 `floor(M/100)+1` 次、每账本 room+round 各一次、功能配置一次、旧账本发现两次。返回文档数与调用次数不同，不能作为同一计费单位。

| 本人账本数 M | 第 1 页返回项 | 第 1 页 DB 读操作 | 第 2 页 DB 读操作 |
|---:|---:|---:|---:|
| 0 | 0 | 4 | 不适用 |
| 1 | 1 | 6 | 不适用 |
| 20 | 20 | 44 | 不适用 |
| 100 | 20 | 205 | 205 |
| 500 | 20 | 1,009 | 1,009 |
| 1,000 | 20 | 2,014 | 2,014 |

- 影响：单页 O(M) 读取与 O(M log M) 排序，完整翻阅约 O(M²/20) 读取；逐条顺序 await 又放大往返延迟。用户提供的日均约 90 人，人数口径未核实，不能证明 M 已很大，严重程度按增长风险处理。
- 建议：近期可批量读取 room/round 并保留逐项权限检查，减少往返但不能声称消除线性数据量；长期再评估可索引的本人历史摘要。若为每次记账同步更新所有成员摘要，会增加写放大，必须连同成员数测算。不能用只按 membership 游标分页而改变现行按更新时间排序的语义。
- 证据：`resource-results.json.waterHistory`，生产 handler 的第一页/第二页均已运行。

### EFF-02 / P2：筛选后的账本无变化也执行第二轮完整读取

- 位置：`miniprogram/pages/water/index.js:824–865,889–904`；云端 `waterSession/index.js:1825–1851`。
- 触发：V2 打水页使用 game 或 direct 筛选，room/round 版本与流水序号均未变化。
- 实际：每次 loadRoom 先 getV2，再 listEntries(afterSeq)。getV2 和 listEntries 各为 4 次单文档读取加 1 次查询；三次不变刷新分别产生 3+3 次云调用。all 筛选是 3+0。每次已成功投影还重写相同最近账本。
- 影响：稳定筛选场景每轮 2 次云调用、10 次 DB 读操作；额外流水查询在没有变化时仍重读 room、配置、member、round。
- 建议：在权威的版本/流水序号与已完成筛选同步水位均不变时，跳过第二次查询；出现缺页、未知水位、更正、切筛选或版本变化时仍按合同补齐。不能只比较 UI 项数，也不能跳过权限与功能开关更新。
- 证据：`frontend-resource-results.json.waterUnchangedRefresh`；对应云成本见 `resource-results.json.waterActions`。

### EFF-03 / P2：锁状态与心跳请求未完成时，定时器继续发新请求

- 位置：`miniprogram/pages/match/matchLockController.js:93–110,168–196`。
- 触发：占用状态查询超过 5 秒，或心跳超过 15 秒尚未返回。
- 实际：setInterval 不等待 promise，且没有对应 inflight 标志。受控计时器的 4 次状态轮询产生 4 个未决调用；3 次心跳产生 3 个未决调用。状态调用还可能在 cloud 层发生最多两次网络重试。
- 影响：慢网/服务拥堵期间出现重叠请求、重复读写和更多结果乱序机会；复现没有据此断言错误数据已经发生。
- 建议：每种动作限制一个在途请求，完成后再调度；保留 session/version 校验、离开停止以及必要的心跳续租时间边界。不要简单延长到超过锁 TTL。
- 已通过部分：teardown 后计时器全部清理，源代码还会丢弃部分过期 session/lifecycle 响应；本问题不等于计时器永不释放。
- 证据：`resource-results.json.lockOutstandingCalls`。

### EFF-04 / P2：最近列表虽只有 20 项，完整赛事缓存持续积累

- 位置：`miniprogram/core/storage/tournament.js:21–25,192–223`。
- 触发：长期访问更多不同赛事。
- 实际：recent ID 保留 20 个，completed snapshot 另限 100 个，但完整赛事 cache 与 cachedAt 各自按赛事 ID 写入，不随 recent 淘汰，也无 TTL/容量控制。访问 125 个合成赛事后 recent=20、完整缓存=125。
- 影响：本地持久存储与序列化负担随历史访问增长。当前 API 会捕获存储写入失败，可能表现为缓存/草稿等其他持久化结果不可用；本轮没有模拟平台存储额度或认定已发生事故。
- 建议：为完整赛事缓存设独立容量/大小预算和淘汰索引，保护当前赛事、必要恢复数据与已有“我的战绩”快照合同；不能直接清空用户历史记录或把快照数量限制误当完整缓存限制。
- 证据：`frontend-resource-results.json.cacheRetention`。

### EFF-05 / P3：首页纯排序变更重新查询远端列表

- 位置：`miniprogram/pages/home/index.js:308–313,373–470`。
- 实际：每次改排序都调用 loadRecents，远端重新读取最近赛事完整文档；三次排序变更产生三次查询。
- 建议：对现有 items 本地排序并刷新显示；需要数据刷新时沿用页面进入、手动刷新或网络恢复路径。若产品要求排序同时刷新，应明确该要求后再决定。
- 证据：`frontend-resource-results.json.homeSort`。

### EFF-06 / P3：轮询通道初始化重复读取相同赛事

- 位置：`miniprogram/sync/watch.js:318–353` 的 init fetch 与立即启动的 polling，`createPollingController` 的首次 0ms 调度。
- 实际：开发工具静默轮询的新通道，init_fetch 完成后，0ms 首次 poll 再读取一遍相同文档；离线计数从 1 变 2。实时不支持而立即 fallback 时也存在相同结构，但本次动态复现使用确定的开发工具分支。
- 建议：用同一初次读取 promise/结果为轮询初始化，或避免已经有权威初次读取的通道再立即 fetch；仍保留首屏失败与 watch 恢复语义。
- 证据：`resource-results.json.pollingInitialization`。

### EFF-07 / P3：头像冷缓存并发请求缺少跨调用合并

- 位置：`miniprogram/core/avatarDisplay.js:293–311`；schedule/ranking/lobby 的头像解析入口。
- 实际：单次调用会去重并分批 50 个，成功后缓存命中；但同一 fileID 在第一次解析返回前被并行调用三次，会发送三个相同 SDK 请求。
- 建议：用 fileID 对应的在途 promise 合并，完成/失败后清除；保留 50 分钟缓存、失败回退和 60 秒失败重试边界。
- 证据：`frontend-resource-results.json.avatarParallelResolution`。

## 四、跨专项完赛字段问题

业务安全专项 BIZ-03 已直接调用未改动的 `submitScore.main` 复现：存储仍为 running，第一场 finished 21:18、第二场 pending，同分重试响应 `SCORE_SUBMIT_DEDUPED + finished:true`，数据库零写入。证据为 `../business/reproduce-business.cjs` 与 `../business/reproduce-business.results.json` 的结果 3。`cloudfunctions/submitScore/logic.js` 的同分幂等响应把“此比赛场次已结束”返回为 `finished:true`，而首次提交响应的 finished 表示整场赛事完成。activityTracker 在 `168–171` 行把任何成功 `finished:true` 派生为 `tournament_complete/FINISHED_CONFIRMED`。

这与文档已声明的“不能证明首次完成”是两件事：前者连整场赛事 finished 状态都不成立。最终报告应与业务专项的生产 handler 反例合并为同一问题，不按两个缺陷重复计数。修复要统一服务端字段语义，并验证存在其他 pending 场次的同分重试不会触发整场完成观察。业务专项对消费者的扫描未发现主流程直接用该 flag 提前收赛，赛程/下一场依赖真实 rounds；不得扩大为本轮已证实提前终止赛事。

本专项另确认：即使后端语义正确，同一意图的两次 finished 响应也会生成两个独立 eventId 的状态观察；当前代码和合同已经明确该事件不是首次完赛计数，这属于统计边界，不能单独认定为新增业务缺陷。

## 五、单位动作资源模型

### 1. 已量测的源码操作数

下面的“读”是单文档 get 或 query get 方法调用次数，查询可以返回多份文档；“写”是 set/update 调用次数。不包含真实 SDK 事务冲突重试、网络传输或平台额外计费。

| 动作 | 云函数调用 | 源码 DB 读操作 | 源码写入/删除 | 说明 |
|---|---:|---:|---:|---|
| 打开/正常刷新 V2 当前账本 | 1 | 5 | 0 | room、配置、round、member 各 1，最近流水 query 1 |
| 无变化但保留 game/direct 筛选刷新 | 2 | 10 | 0 | getV2 后再 listEntries |
| 新建独立账本 | 1 | 11 | 4 | 此外每次尝试 createCollection 5 次；不是 5 份新集合 |
| 新增手工成员 | 1 | 5 | 3 | round、room、幂等日志；具体载荷/权限不同会改变分支 |
| 原始记账一次 | 1 | 5 | 4 | entry、round、room、幂等日志 |
| 同请求 ID 成功记账重试 | 1 | 5 | 0 | 返回幂等结果，不重复记账 |
| 读取某类流水的增量页 | 1 | 5 | 0 | 即使增量页为空，仍核对 room/config/member/round |
| 打水历史任意一页 | 1 | `2M + floor(M/100) + 4` | 0 | 上表模型条件成立时 |
| 新 activity 写操作埋点 | 0 个额外业务云函数 | 0 个业务库操作 | 0 | 向微信 reportEvent 发送 2 条；平台成本和实际接收另验 |
| 首页排序一次 | 0 个云函数 | 1 个客户端 query | 0 | 当前会重新读取最近最多 20 项的完整赛事数据 |

新建账本的 5 次 `createCollection` 尝试来自每次调用 ensureV2Collections，已有正式 bootstrap 声明；可以评估将预备步骤移到受控部署/初始化阶段，但不能因此删除现有缺集合错误处理而使新环境失效。当前只是明确可避免的控制面调用来源，没有假设其具体时延或费用。

### 2. 持续观看与错误恢复

| 场景 | 代码节奏 | 名义请求规模 | 限制与解释 |
|---|---|---|---|
| 真机健康实时 watch | 共享一个赛事通道；事件驱动 | 随实际变更推送 | 本轮无真实 watch 流量/推送计费证据 |
| 赛事 fallback 或开发工具静默 polling | 成功后 1.5 秒，±15% jitter；错误逐步到 8 秒 | 持续成功且忽略延迟，约 2,400 次 get/查看端小时 | 不是所有真机的默认开销；即使版本不变也维持该频率 |
| 打水普通可见页面 | 完成一轮后再等 8 秒 | 忽略耗时约 450 轮/查看端小时 | all 约 450 云调用/2,250 DB 读操作；game/direct 稳定场景约 900/4,500 |
| 打水成功写入之后 | 3 秒间隔，成功 5 次后回到普通周期 | 每次触发最多 5 轮 burst | 失败会退回 16/30 秒；连续新写可能重置 burst，不能无条件将每次 burst 当额外 5 次独立于普通周期累加 |
| 本人保持录分锁 | 15 秒心跳 | 名义约 240 次心跳/小时 | 应按实际编辑时长估算，不能按全天运行 |
| 等待他人录分锁 | 5 秒状态查询 | 名义约 720 次查询/小时 | 实际过期/结束/离页会停止；慢请求目前可能重叠 |
| 网络错误的 cloud 重试 | 最多 2 次，300/900ms 延迟 | 每次业务调用最多 3 次 SDK 发起 | 只有符合条件的只读/带请求ID写入；业务 ok:false 不自动重试 |

轮询同一版本时，生产 createPollingController 动态验证为 10 次 get、1 次 onData、10 次下一周期均 1,500ms。前端减少重复渲染，不等于减少云端读取。优化需要先确定同步体验与数据新鲜度要求，再考虑无变化时退避、页面/状态自适应或更轻的版本响应。

按总查看端小时 H、其中赛事 polling 小时 Ht、打水 all 小时 Hw、打水筛选小时 Hf，源码名义持续查询规模可写为：赛事 get 约 `2400×Ht`；打水云调用约 `450×Hw+900×Hf`。这些公式用于敏感性分析，用户提供的日均约 90 人（人数口径未核实）不能直接代入 H，也不能等同于真实账单。应单独取得每次活动的查看端数、停留时长、录分次数、重连次数。

### 3. 其他增长与保留风险

| 路径 | 源码事实 | 评估与改进边界 |
|---|---|---|
| 幂等日志 | `scripts/cloud-common.template.js:161–189` 与 waterSession `467–485` 持久化每个成功请求，无代码层 TTL/删除；bootstrap 也未声明生命周期 | 不能将缺少远端 TTL 证据写成确认永不清理。需要查实际保留/备份；删日志可能破坏跨期幂等，必须先定义重放期限和业务记录防重合同 |
| 头像对象 | `core/profile.js:89–122` 每次上传用时间戳新路径；客户端没有对象删除逻辑 | 失败保存、取消或重复上传可能遗留对象；旧头像可能被历史赛事引用，不能直接批删。先做引用清单、文件年龄/体积核算 |
| 分享码 | 客户端 shareCode 按赛事/环境缓存且合并在途请求；服务端每次调用生成后上传到确定路径 | 当前能减少单进程重复，但跨进程仍生成。若流量证据显示占比高，再做服务端复用；仍需每次授权验证 |
| 个人战绩分析函数 | `getMyPerformanceStats/index.js:9–111` 每次读取本人 finished、所有缺 playerIds 的 legacy finished，必要时回退全部 finished；每路 cap 4,000 | 是备用分析入口，当前“我的战绩”主流程用本地快照，不应列为日常最大开销。若要推广此入口，应观测/索引/迁移旧数据并把时间窗口尽量下推 |
| 历史流水详情 | `waterSession/index.js:849–878` 读取同 rootEntryId 的完整更正历史，按 100 条批次 | 与当前页面一次至多 20 条的普通流水页不同；是否需要分页由更正历史增长决定，不恢复 V1 的 200 条上限 |
| 客户端日志 | 新 activity 无 payload 日志；旧 growth 每个事件 console.info，头像警告和云调用错误有诊断日志 | 不能把 console 日志直接等同 CLS 入库。保留/权限/采样需查实际平台；不为了节省日志删除必要错误证据 |

## 六、留痕的其他待补环节

1. **操作异常后的恢复未形成同一意图的最终状态。** `lobbyLifecycleActions.js:79–91,151–158` 可能在超时后读到已开赛并正常结束；`matchSubmitService.js:411–425` 可能恢复已提交比分并另发旧 growth success。新 activity 已经结束为 exception/failure，之后没有关联 recovered 事件。可以统计“调用返回异常”，但不能把它直接解释成用户最终业务失败。下一步应保留原调用事实，再追加有证据的恢复结果。
2. **少数关键固定业务码被折叠。** `CLIENT_REQUEST_ID_REUSED`、`WATER_JOIN_REQUIRED` 动态捕获为 BUSINESS_REJECTED；WATER_ROOM_FORBIDDEN 和 WATER_WRITES_DISABLED 能原样保留。固定枚举扩充可提高首笔失败原因的可解释性，仍禁止任意错误文本。
3. **没有真实运输丢弃计数。** 当前 reportEvent 失败被忽略是业务保护，但没有 received/dropped 的可审对账。客户端不阻塞和平台完整接收是不同验收条件。
4. **字段、保留期和额度仍待平台核实。** 文档中的 14 天原始、90 天日聚合、全局每日 1,000 等是未来建议，不能当现已执行。若以后启用 1,000 条日额度，若以用户提供的日均约 90 人作为纯假设（人数口径未核实），人均约 5.6 个成对追踪调用就已耗尽额度，尚未包含 view/share/complete；这里只是预算约束示例，不是实际使用量估计。
5. **受控实收必须区分环境。** activity 有 envVersion，旧 growth 无；CLS appVersion 常无来源保证。不能从“同一云环境”自动恢复哪个请求来自发布版，也不能把缺参请求全部划成测试。

## 七、优先级与本轮完成状态

建议后续实施顺序：先修跨专项的 finished 语义与 TEL-01 报表输入错误；再为 EFF-03 锁请求合并、EFF-02 无变化筛选读取、EFF-04 缓存上限做最小修复；EFF-01 历史账本按实际账本数与 P95 决定批量读取/摘要方案；最后处理排序、初始化与头像的小型重复请求。留痕平台闭环需要单独的受控实收条件，已有本地代码不能替代。

本轮已经完成：两套事件与报表入口代码核对、关键指标缺口矩阵、数据库/轮询/缓存/重试/头像/日志保留路径审查、三个独立脚本的轻量复现、结果文件。未声称完成：平台事件实收、真实云 DB/事务/网络性能、真实月费、实际用户画像、原生手机验证、任何修复的上线交付。

调研弹窗保留为后续候选：用途身份、主要使用赛制、最大困扰三类问题足够先补画像；应在适当时点可跳过并限制频率。其实现、文案和采集不属于本轮检查动作。


补充消费者边界：`core/cloud.js:72–81` 也会读取 finished 推断结果状态，但该真实去重响应的显式 state/deduped 优先，仍保留 deduped；本复现中直接错误生成 FINISHED_CONFIRMED 的是 activityTracker。

三个离线复现脚本支持 `AUDIT_REPO=/absolute/path/to/repo` 覆盖源码根目录；未设置时使用证据目录旁的 `../../repo`。
