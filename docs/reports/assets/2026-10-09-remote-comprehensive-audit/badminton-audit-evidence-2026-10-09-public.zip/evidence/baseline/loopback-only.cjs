'use strict';
// Audit harness only: permit test-local mock services; reject external Node sockets.
const net = require('node:net');
const dgram = require('node:dgram');
const originalConnect = net.Socket.prototype.connect;
function assertLocal(options) {
  if (options.path) return;
  const host = String(options.host || options.hostname || 'localhost').replace(/^\[|\]$/g, '').toLowerCase();
  if (host === 'localhost' || host === '::1' || /^127\./.test(host)) return;
  const error = new Error(`Audit denied external network destination: ${host}`);
  error.code = 'AUDIT_NETWORK_DENIED';
  throw error;
}
net.Socket.prototype.connect = function (...args) {
  const normalized = net._normalizeArgs(args);
  assertLocal(normalized[0]);
  return originalConnect.apply(this, args);
};
dgram.Socket.prototype.send = function () {
  throw new Error('Audit denied UDP network send');
};
if (typeof globalThis.fetch === 'function') {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = function (input, init) {
    const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
    assertLocal({ host: url.hostname });
    return originalFetch(input, init);
  };
}
