#!/usr/bin/env python3
"""Run a reviewed audit command without Internet sockets and record its receipt."""
import ctypes
import ctypes.util
import datetime
import errno
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
REPO = ROOT / 'repo'

class ArgCmp(ctypes.Structure):
    _fields_ = [('arg', ctypes.c_uint), ('op', ctypes.c_uint),
                ('datum_a', ctypes.c_uint64), ('datum_b', ctypes.c_uint64)]

def deny_internet_sockets():
    lib = ctypes.CDLL(ctypes.util.find_library('seccomp'), use_errno=True)
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                          ctypes.c_int, ctypes.c_uint,
                                          ctypes.POINTER(ArgCmp)]
    lib.seccomp_load.argtypes = [ctypes.c_void_p]
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    ctx = lib.seccomp_init(0x7fff0000)
    if not ctx:
        raise RuntimeError('seccomp_init failed')
    try:
        syscall = lib.seccomp_syscall_resolve_name(b'socket')
        for family in (2, 10):
            comparison = ArgCmp(0, 4, family, 0)
            result = lib.seccomp_rule_add_array(ctx, 0x50000 | errno.EPERM,
                                               syscall, 1, ctypes.byref(comparison))
            if result:
                raise RuntimeError(f'seccomp rule failed: {result}')
        result = lib.seccomp_load(ctx)
        if result:
            raise RuntimeError(f'seccomp load failed: {result}')
    finally:
        lib.seccomp_release(ctx)

def main():
    name, *command = sys.argv[1:]
    loopback = bool(command and command[0] == '--node-loopback')
    if loopback:
        command.pop(0)
    if not command:
        raise SystemExit('usage: run_isolated.py NAME COMMAND [ARGS...]')
    directory = pathlib.Path(__file__).parent
    log_path = directory / f'{name}.log'
    receipt_path = directory / f'{name}.json'
    env = {k: v for k, v in os.environ.items()
           if k in {'PATH', 'HOME', 'LANG', 'LC_ALL', 'LC_CTYPE', 'TZ', 'TMPDIR'}}
    env.update({'TZ': 'Asia/Shanghai', 'NO_COLOR': '1', 'CI': '1'})
    if loopback:
        env['NODE_OPTIONS'] = '--require=' + str(directory / 'loopback-only.cjs')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO).decode()
    t0 = time.monotonic()
    with log_path.open('w') as log:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=log,
                                stderr=subprocess.STDOUT,
                                preexec_fn=None if loopback else deny_internet_sockets)
    receipt = {'command': command, 'cwd': str(REPO), 'startedAt': started,
               'durationSeconds': round(time.monotonic() - t0, 3),
               'exitCode': result.returncode, 'log': str(log_path),
               'network': ('Node socket/fetch guard: only loopback permitted; inherited by Node children; reviewed shell fixtures use fake CLIs'
                           if loopback else 'AF_INET and AF_INET6 socket creation denied in process tree'),
               'environment': 'minimal inherited environment, TZ Asia/Shanghai',
               'gitStatusBefore': before,
               'gitStatusAfter': subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO).decode()}
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
    print(json.dumps({'name': name, 'exitCode': result.returncode,
                      'durationSeconds': receipt['durationSeconds'],
                      'receipt': str(receipt_path),
                      'gitStatusBefore': before,
                      'gitStatusAfter': receipt['gitStatusAfter']}, ensure_ascii=False))
    return result.returncode

if __name__ == '__main__':
    raise SystemExit(main())
