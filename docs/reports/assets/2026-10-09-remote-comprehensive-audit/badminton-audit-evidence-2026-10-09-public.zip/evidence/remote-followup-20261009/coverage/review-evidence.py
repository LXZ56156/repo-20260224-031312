#!/usr/bin/env python3
"""Review saved audit evidence without running application code or contacting services."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parents[1]
REPO = Path(os.environ.get('AUDIT_REPO', str(EVIDENCE.parent / 'repo'))).resolve()
COMMIT = 'a3fe96f25015892ac30ee7148f97a5b441b0cb24'
def read(relative):
    return json.loads((EVIDENCE / relative).read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert git('rev-parse', 'HEAD') == COMMIT
assert git('status', '--porcelain') == ''
combined = read('root/combined-findings.json')
findings = combined['findings']
by_id = {item['id']: item for item in findings}
assert len(by_id) == len(findings)
counts = dict(sorted(Counter(item['priority'] for item in findings).items()))
assert combined['entryCount'] == len(findings)
assert combined['priorities'] == counts
original_ids = [f'BIZ-{i:02d}' for i in range(1, 6)] + [f'FA-{i:02d}' for i in range(1, 5)] + ['TEL-01'] + [f'EFF-{i:02d}' for i in range(1, 8)] + ['UI-01']
assert set(original_ids) <= set(by_id)
original_counts = dict(sorted(Counter(by_id[key]['priority'] for key in original_ids).items()))
assert original_counts == {'P1': 2, 'P2': 12, 'P3': 4}
source_matches = []
unmerged_source_ids = []
for relative, key in [('business/findings.json', 'findings'), ('fairness/findings.json', 'findings'), ('telemetry/findings.json', 'ownedFindings')]:
    for item in read(relative)[key]:
        if item['id'] not in by_id:
            unmerged_source_ids.append(item['id'])
            continue
        candidate = {k: v for k, v in by_id[item['id']].items() if k != 'owner'}
        assert candidate == item, f"Merged source mismatch: {item['id']}"
        source_matches.append(item['id'])
assert read('telemetry/findings.json')['crossReference']['id'] == 'BIZ-03'
assert sum(item['id'] == 'BIZ-03' for item in findings) == 1

full = read('baseline/full-tests.json')
files = sorted(item for item in full['command'] if item.startswith('tests/'))
official = sorted(str(p.relative_to(REPO)) for p in (REPO / 'tests').glob('*.test.js'))
assert files == official
assert json.loads((REPO / 'package.json').read_text())['scripts']['test'] == 'node --test tests/*.test.js'
tap = (EVIDENCE / 'baseline/full-tests.log').read_text()
tap_counts = {key: int(re.findall(rf'^# {key} (\d+)$', tap, re.M)[-1]) for key in ['tests', 'pass', 'fail', 'skipped']}
assert tap_counts == {'tests': 1777, 'pass': 1768, 'fail': 7, 'skipped': 2}
assert full['exitCode'] == 1
targeted = (EVIDENCE / 'baseline/targeted-baseline-recheck.log').read_text()
assert '# tests 10\n' in targeted and '# pass 10\n' in targeted and '# fail 0\n' in targeted
assert read('baseline/static-checks.json')['exitCode'] == 0
assert read('baseline/eslint.json')['exitCode'] == 0

fair = read('fairness/independent-results.json')
assert fair['singles']['passed'] == len(fair['singles']['cases']) == 84
assert fair['fixedPairs']['passedCoreCases'] == len(fair['fixedPairs']['cases']) == 384
assert fair['fixedPairs']['restMismatchCases'] == 320
assert fair['scores']['scorePairs'] == 4107 and fair['scores']['comparisons'] == 8214
assert fair['rankings'] == {'cases': 200, 'comparisons': 400}
templates = read('fairness/template-results.json')
assert templates['templateCases'] == 60 and templates['prefixes'] == len(templates['rows']) == 941
assert not templates['failures'] and not templates['metricsMismatches']
runtime = read('fairness/runtime-results.json')
assert len(runtime['cases']) == 31 and not runtime['failures']
lifecycle = read('fairness/singles-lifecycle-results.json')
assert lifecycle['workflowCases'] == len(lifecycle['cases']) == 60
assert lifecycle['scoreWrites'] == lifecycle['independentRankStates'] == 1014
reference = read('fairness/small-reference-results.json')
assert reference['examined'] == 46656 and reference['balanced'] == 8100
assert read('root/fairness-independent-recount.json')['result'] == 'passed'
for item in read('fairness/reachability-results.json')['cases']:
    assert item['final']['count'] == item['parameters']['totalMatches']
    assert item['persisted']['totalMatches'] == item['parameters']['totalMatches']
    assert item['roster']['checkStartReady']
assert by_id['FA-03']['status'] == 'verified_product_tradeoff'
assert by_id['FA-01']['status'] == 'confirmed_quality_discontinuity'
assert by_id['FA-02']['status'] == 'confirmed_avoidable_quality_defect'
assert all(not by_id[key]['hard_constraint_violation'] for key in ['FA-01', 'FA-02', 'FA-03', 'FA-04'])

business = {row['id']: row for row in read('business/reproduce-business.results.json')['results']}
assert business['BIZ-01']['before'] == {'records': 1, 'participants': 2, 'version': 3}
assert business['BIZ-01']['after'] == {'records': 0, 'participants': 1, 'version': 1}
assert business['BIZ-02']['claimed'] and not business['BIZ-02']['explicitClaimFieldPresent']
assert business['BIZ-03']['storedTournamentStatus'] == 'running'
assert business['BIZ-03']['emittedResultCode'] == 'FINISHED_CONFIRMED'
assert business['BIZ-03']['writes'] == 0
sdk = read('business/sdk-inspection/probe-transaction.results.json')
where_writes = [c for c in sdk['calls'] if c['method'] == 'database.modifyDocument' and c['params']['queryType'] == 'WHERE']
doc_writes = [c for c in sdk['calls'] if c['method'] == 'database.modifyDocument' and c['params']['queryType'] == 'DOC']
assert len(where_writes) == 2 and all('transactionId' not in c['params'] for c in where_writes)
assert len(doc_writes) == 2 and all(c['params']['transactionId'] for c in doc_writes)
projection = read('business/reproduce-client-score.results.json')
assert projection['finalLocal']['version'] == projection['authoritativeRefresh']['version'] == 3
assert projection['finalLocal']['score'] == projection['submitResponse']['score'] != projection['authoritativeRefresh']['score']

resource = read('telemetry/resource-results.json')
for item in resource['waterHistory']:
    expected = 2 * item['ledgerCount'] + item['ledgerCount'] // 100 + 4
    assert item['page1']['databaseReadOperations'] == expected
    if 'page2' in item:
        assert item['page2']['databaseReadOperations'] == expected
assert resource['lockOutstandingCalls']['unresolvedStatusAfter4Ticks'] == 4
assert resource['lockOutstandingCalls']['unresolvedHeartbeatAfter3Ticks'] == 3
frontend = read('telemetry/frontend-resource-results.json')
assert frontend['cacheRetention'] == {'tournamentsVisited': 125, 'recentIds': 20, 'retainedFullDocumentCaches': 125}
tel = read('telemetry/telemetry-results.json')['nullDurationCounterexample']
assert tel['actual']['durationCoverage'] == 3 and tel['actual']['requestP95Ms'] == 0
assert tel['expected'] == {'requestP95Ms': None, 'durationCoverage': 0}
assert len(read('root/profile-query-results.json')['results']) == 2
assert all(r['error'] == 'URIError' and r['setDataCount'] == 0 for r in read('root/profile-query-results.json')['results'])

npm = read('root/npm-audit.json')['vulnerabilities']
assert len(npm) == 97
assert dict(Counter(v['severity'] for v in npm.values())) == {'low': 1, 'moderate': 25, 'high': 27, 'critical': 44}
lock = json.loads((REPO / 'package-lock.json').read_text())['packages']
nodes = [node for item in npm.values() for node in item['nodes']]
assert len(nodes) == 102 and all(node in lock and lock[node].get('dev') for node in nodes)

follow_root = 'remote-followup-20261009/root/'
access = read(follow_root + 'remote-access-and-github.json')
facts = access['live_readonly_sources']
assert next(row['facts'] for row in facts if '/branches/master' in row['url'])['head'] == COMMIT
action_facts = next(row['facts'] for row in facts if '/actions/runs' in row['url'])
assert action_facts['total_count'] == len(action_facts['runs']) == 6
assert all(row['head_sha'] != COMMIT for row in action_facts['runs'])
cloud_dep = read(follow_root + 'cloud-dependency-audit/summary.json')
assert cloud_dep['counts']['vulnerabilities']['total'] == 17 and cloud_dep['resolvedPackageCount'] == 162
assert sha(EVIDENCE / (follow_root + 'cloud-dependency-audit/package-lock.json')) == cloud_dep['lockSha256']
retention_control = read(follow_root + 'retention-independent-check.json')
retention_cases = {row['case']: row for row in retention_control['cases']}
assert retention_cases['old-watermark']['d7']['rate'] is None
assert retention_cases['new-watermark-same-input']['d7']['rate'] == 0
assert retention_cases['new-watermark-key-absent']['d7']['rate'] is None
assert retention_cases['new-watermark-key-absent']['d7']['status'] == 'missing'
assert retention_cases['old-watermark']['inputSha256'] == retention_cases['new-watermark-same-input']['inputSha256']
assert read('remote-followup-20261009/telemetry/retention-freshness-cli-report.json')['window']['status'] == 'missing'

narrative = (EVIDENCE / 'root/audit-narrative.txt').read_text()
history_section = narrative.split('# 10. ')[1].split('# 11. ')[0]
roadmap_rows = [int(v) for v in re.findall(r'^\| (\d+) ', history_section, re.M)]
assert roadmap_rows == list(range(1, 13))

objectives = [
 {'id':'AUD-01','objective':'固定远端事实与工程记录','review_status':'source_and_github_review_complete_deployment_evidence_blocked','evidence':['root/remote-head-ci.json','root/final-remote-head.json','baseline/inventory.json','root/final-source-integrity.json',follow_root+'remote-access-and-github.json'], 'observed':'固定提交、1638跟踪文件、16页、26受管函数与307测试文件均有证据；10月9日HEAD仍相同，公开仓库有6条历史Actions，此HEAD为0；当前checkout仍clean。', 'unverified':'发布客户端、部署包与源码同版性属于本轮远端待核事项；未取得可用已认证云端只读入口，受阻未验证。'},
 {'id':'AUD-02','objective':'四赛制、搭档与对手均衡、比分排名','review_status':'bounded_source_and_offline_audit_complete_with_findings','evidence':['fairness/findings.json','fairness/independent-results.json','fairness/template-results.json','fairness/runtime-results.json','fairness/reachability-results.json','root/fairness-independent-recount.json'], 'observed':'核心合法性样例通过；FA-01/03为有休息代价的取舍，FA-02为已统计指标可严格改善，FA-04为显示字段缺失。', 'unverified':'不涵盖所有大规模排法或线上参数分布；不将941模板前缀说成941次外层完整运行。'},
 {'id':'AUD-03','objective':'业务与数据安全','review_status':'source_and_controlled_probe_audit_complete_with_findings','evidence':['business/report.md','business/findings.json','business/verification.results.json','business/sdk-inspection/probe-transaction.results.json'], 'observed':'5条不同根因已复现或精确SDK请求确认，2P1/3P2；BIZ-03仅错报事件，BIZ-05仅错误本地投影。', 'unverified':'真实云规则、实际SDK部署、冲突重试/回滚、真实身份及双机未验证；无事故频率结论。'},
 {'id':'AUD-04','objective':'实际使用留痕和指标闭环','review_status':'source_gap_assessment_complete_platform_review_blocked','evidence':['telemetry/report.md','telemetry/telemetry-results.json','business/reproduce-business.results.json',follow_root+'report.md'], 'observed':'已有17字段activity与7字段growth代码，growth含mode；13问题矩阵和TEL-01已查；不能说留痕代码全无。TEL-02经独立分级仅保留P3输入防护观察，不加主发现数。', 'unverified':'平台配置、实收、查询、测试排除、真实用户用途和7日队列属于本轮远端范围；无当前可读入口/原始返回，受阻未完成。'},
 {'id':'AUD-05','objective':'资源浪费与效率','review_status':'source_cost_model_complete_live_resource_review_blocked','evidence':['telemetry/resource-results.json','telemetry/frontend-resource-results.json','telemetry/report.md',follow_root+'report.md'], 'observed':'EFF-01至07有源码操作或受控请求计数；历史分页公式与数表吻合。', 'unverified':'方法调用数不是计费文档数，日均90人口径不明且不等于并发；实际账单、调用结构和存储增长属于远端待核，因访问不足受阻。'},
 {'id':'AUD-06','objective':'UI静态完整性、配置与依赖','review_status':'static_and_public_dependency_review_complete_live_config_blocked_devices_out_of_scope','evidence':['telemetry/ui-config-coverage.json','telemetry/ui-config-coverage.md','root/profile-query-results.json','root/npm-audit.json','root/dependency-analysis.json',follow_root+'cloud-dependency-audit/summary.json'], 'observed':'页面/引用/路由静态扫描与畸形query源onLoad复现；根97依赖条目102路径全部在lock标dev。另补公共云候选树162路径/17受影响条目，未取得部署包，不能相加为生产漏洞数。', 'unverified':'实际包、云runtime/规则/索引、隐私后台证据未取得，受阻。原生尺寸/大字/交互与用户手机不在本轮仅远端操作范围，但保留历史产品验收门槛。'},
 {'id':'AUD-07','objective':'历史12项开发计划逐项对账','review_status':'documentary_crosswalk_complete_report_corrections_applied','evidence':['repo:docs/tasks/current.md','repo:docs/tasks/paused-plan-status.md','repo:docs/reports/2026-10-03-online-audit-and-roadmap.md','root/audit-narrative.txt'], 'observed':'12行齐全，当前记录明确原计划未完成；本轮检查不恢复历史实施/部署/付款。第1平台失败阈值、第2历史空函数和整环境恢复缺口均已补入最终叙事。', 'unverified':'历史备份介质、恢复产物和线上回执没有本轮重新取得；历史产品验收仍未闭合。'}
]

history = [
 (1,'开赛超时','连续7天、至少100次合格真实调用，硬超时0、平台失败率<1%；可靠来源/版本，平台与业务失败分开。','源码deadline/预算、算法样例及SDK边界有新证据。','只有截至上海10-04 16:48:54的19次非缺参成功历史记载；上海10-10 02:32:05为历史观察截止，不自动延后或恢复调度。'),
 (2,'续费、备份和恢复','当前有效期/续费回执；赛事、资料、账本和文件引用能隔离恢复；补齐资产缺口。','仅核对13925文档、2735对象、38函数恢复及三集合补档的历史记载。','一历史空函数代码、在线整环境恢复、13/16集合差异原因仍缺；原计划10/12前复核续费不是当前已确认到期或付款事实。'),
 (3,'留痕与故障监控','关键动作attempt/result可关联，失败入统计；实收、去重、脱敏、每日简报和异常查询。','字段、行为链、报表及TEL-01/BIZ-03有新证据。','平台配置/接收、查询权限、受控测试排除及完整窗口未知。'),
 (4,'原前端三缺陷及同步','直接回归与真实手机慢网、切页、首次watch等实际验收。','官方全测试集合已覆盖相关源回归；新增BIZ-05。','当前发布包及原生/手机慢网验收未取得；历史本地修复不等于已发布。'),
 (5,'录分并发和数据库权限','真实身份/规则公开字段/客户端新增权限；隔离锁接管、冲突、回滚及多号双机。','角色/锁/版本代码、BIZ-04精确SDK请求有证据。','真实云引擎及当前有效规则、隔离角色/双机仍未验证。'),
 (6,'打水首次记账','真实首次场景，进入→成员→首笔，测试排除及完整7日新账本首笔率。','事件语义、handler及资源路径已查。','真实用途、匿名账本关联、成熟创建队列与实际阻塞未知；不得凭猜测改界面。'),
 (7,'提前收赛','保留已录比分，待赛标取消，统计范围明确；不改变独立打水无结束按钮合同。','纯逻辑/权限/活跃锁约束与相关回归已查。','新函数与客户端实际部署、原生确认/分享、手机并发未驗。'),
 (8,'协作管理','主办授撤、真实成员绑定、最小权限、审计与撤权效果。','权限/版本/guest排除等源合同已查。','真实授权审计、跨会话撤权并发、云规则、原生双机未验。'),
 (9,'运行时SDK与依赖','工具链/云依赖分离，真实身份/事务/错误/日期数值/幂等/回退验证后维护。','根audit97个dev条目与精确云数据库链有新证据；主控补查公共云候选树162路径/17条目，本专项仅复核摘要与锁哈希，未重新扫描。','当前部署依赖、CloudBase实际runtime与回退未核；本轮未升级。'),
 (10,'首屏同步大赛事性能','低端Android与iPhone同场景首屏/读写/桥接/渲染P95及改前后比较。','源码单位动作和重复请求、受控算法耗时已查。','没有真实设备或同窗口调用/传输/存储/账单，不把Node计时当手机P95。'),
 (11,'赛事找回与跨设备','真实参赛身份/guest明确绑定、主办参与找回、权限/索引和跨设备结果。','server身份、cursor绑定、权威名单过滤及静态入口已查。','实际微信/数组索引/云查询成本/普通用户跨设备未验。'),
 (12,'单打循环','已采用2–8人/1–2场/1–2循环、分制/并列名次合同及全链路；原生/云/真实比赛验收。','独立排赛、终局、排名和60流程验证通过。','当前像素/尺寸/大字、原生交互、云部署和手机/发布版未知；历史图与离线测试不替代。')
]
history_matrix = [{'id':n,'goal':title,'documentary_review':'complete','historical_product_acceptance':'not_closed','required_acceptance':need,'current_audit_evidence':done,'remaining_evidence':gap} for n,title,need,done,gap in history]

corrections = [
 {'id':'COV-01','level':'required_completeness_correction','target':'root/audit-narrative.txt:245','original':'本轮无新连续 7 天、≥100 合格真实调用记录','reason':'历史原总计划第99行还有硬超时0和平台失败<1%的明确验收；表格未完整列出。没有误判通过，但对账不应漏门槛。','replacement':'本轮未取得带可靠来源/版本的连续7天、至少100次合格真实调用证据，不能核定硬超时0、平台失败率低于1%；平台与业务失败分开统计。历史观察截止另按 current.md 保留。','sources':['repo:docs/reports/2026-10-03-online-audit-and-roadmap.md:99','repo:docs/tasks/current.md:21']},
 {'id':'COV-02','level':'required_completeness_correction','target':'root/audit-narrative.txt:246','original':'未重新读取原 D/E 介质、恢复产物或当前账单/到期回执；13/16 集合历史差异原因仍未知','reason':'最新详细状态的收尾表仍明确一历史空函数代码及在线整环境恢复未验，应在“仍未闭合原验收”保留。','replacement':'未重新核原介质/恢复产物、当前账单和到期回执；一历史空函数代码、在线整环境恢复及13/16集合历史差异仍未闭合。原计划要求10月12日前复核续费，当前是否续费/有效期仍待新回执。','sources':['repo:docs/tasks/paused-plan-status.md:42','repo:docs/reports/2026-10-03-online-audit-and-roadmap.md:100']},
 {'id':'COV-03','level':'required_scope_wording_update','target':'root/audit-narrative.txt:260-273','original':'后续实施顺序与验收目标；下面是具体修复工作包，便于后续直接实施','reason':'用户本轮再次明确检查不是修复；发现优先级和验收参考可以保留，但不应把修复包装成本轮接续工作。','replacement':'改为“审计发现优先级与后续验证参考”。说明：本节仅记录发现的处理建议，不属于本轮实施任务；本次检查是否完成以证据核验和报告交付为准，不以缺陷是否修复为准。','sources':['visible_user_instruction:检查，不是修复','visible_user_instruction:继续检查做完汇总报告']}
]
final_correction_text = {
 'COV-01':'平台失败低于 1%',
 'COV-02':'1 个历史空代码函数及整套 CloudBase 恢复仍缺证据',
 'COV-03':'本轮不安排实施工作包'
}
for correction in corrections:
    marker = final_correction_text[correction['id']]
    assert marker in narrative
    matching = [(i, line) for i, line in enumerate(narrative.splitlines(), 1) if marker in line]
    correction.update({'status':'applied','final_evidence':[{'line':i,'text':line} for i,line in matching]})
assert '全面检查的线上部分仍未完成' in narrative
assert '全面检查的当前云平台部分仍因缺少读取条件或原件而未完成' in narrative
assert '# 11. 尚未完成的线上检查与具体证据需求' in narrative
assert 'P3 输入防护观察 TEL-02' in narrative
assert '具体修复工作包，便于后续直接实施' not in narrative
precision = [
 {'target':'root/audit-narrative.txt:3,283','note':'旧结束句不能覆盖10月9日最新状态。最新补查 root/report.md 已明确：可用源码、GitHub、公共依赖和合成验证完成，全面检查中的线上部分因缺少已认证只读入口仍受阻未完成；报告交付不等于线上检查已完成。'},
 {'target':'root/audit-narrative.txt:21','note':'“此提交Actions运行数0”正确。主控新查有6条仓库历史Actions，不能改述为全仓库没有Actions或从未运行CI。'},
 {'target':'root/audit-narrative.txt:24','note':'“远端最新提交”建议附核验时间；主控本轮重读仍a3fe96f，仅凭旧回执不能长期保证最新。'},
 {'target':'root/audit-narrative.txt:139-144','note':'所有计数核对通过；941是模板实例化前缀，200/400是合成排名算术样例，均不是线上通过率或所有参数穷举。'},
 {'target':'root/audit-narrative.txt:9 and combined-findings.json','note':'原18唯一条目及2/12/4正确，包含取舍及优化。TEL-02虽有真实CLI合成入口证据，尚无真实未成熟API响应或实际损害，独立审校建议P3防护观察；主控已采纳，主发现仍18，不改成19个已确认问题。'}
]

tel02_review = {
 'id':'TEL-02','recommended_priority':'P3','classification':'input_integrity_hardening_observation',
 'include_in_primary_findings':False,'main_agent_decision':'accepted_review_recommendation_keep_primary18',
 'confirmed':'真实公开CLI接受显式旧fetched_at、合成key7=0与后移人工latestComplete；未校验逐输入采集时间。',
 'not_confirmed':['微信真实未成熟接口会提供该占位形状','正常已核实接口数据会产生错误留存率','任何已有真实历史报告受影响','任意旧文件或缺失D7被补零','脚本自动推进latestComplete'],
 'controls':'缺key7时rate=null/status=missing；合成输出只有D7子项complete，window整体仍missing。',
 'contract':'docs/tools/we-analysis-local-script.md:112要求人工已核接口水位，120要求目标key存在，121明确零仅来自显式数值0；当前fixture未证明违反这些约定的真实正常输入场景。',
 'wording':'合成旧快照与后移人工水位可形成未被拒绝的矛盾输入，建议增加逐输入新鲜度校验。真实API是否存在该形状及历史损害均未证实。',
 'evidence':['remote-followup-20261009/telemetry/retention-freshness-probe.cjs','remote-followup-20261009/telemetry/retention-freshness-cli-report.json',follow_root+'retention-independent-check.json'],
 'upgrade_condition':'取得受支持采集链实际可产生的未成熟快照及成熟后权威数据，证明正常约定操作能将未知或过期值错误计入指标；不为提高级别而制造生产流量。'
}

inputs = ['root/audit-narrative.txt','root/combined-findings.json','business/report.md','business/findings.json','fairness/report.md','fairness/findings.json','telemetry/report.md','telemetry/findings.json','baseline/full-tests.json','baseline/full-tests.log','baseline/baseline-analysis.json','root/fairness-independent-recount.json']
inputs += [follow_root+'report.md',follow_root+'remote-access-and-github.json',follow_root+'retention-independent-check.json',follow_root+'cloud-dependency-audit/summary.json']
snapshots = [{'path':rel,'sha256':sha(EVIDENCE/rel),'bytes':(EVIDENCE/rel).stat().st_size} for rel in inputs]
for rel in ['AGENTS.md','docs/tasks/current.md','docs/tasks/paused-plan-status.md','docs/reports/2026-10-03-online-audit-and-roadmap.md']:
    snapshots.append({'path':'repo:'+rel,'sha256':sha(REPO/rel),'bytes':(REPO/rel).stat().st_size})

result = {
 'schemaVersion':1,'generatedAtUtc':datetime.now(timezone.utc).isoformat(),'commit':COMMIT,
 'scope':'Independent completion/evidence review; no application rerun, repair, commit, deploy, production access or user-device access',
 'checkout':{'path':str(REPO),'branch':git('branch','--show-current'),'head':git('rev-parse','HEAD'),'gitStatus':git('status','--porcelain')},
 'scope_basis':{'current_audit':'Visible user six answers plus seven audit objectives in narrative; parent confirmed no separate approved-plan file available.', 'original_approved_plan_verbatim_retrieved':False,'historical_roadmap':'12 development tasks are reviewed as historical progress/acceptance, not adopted as current implementation authorization.', 'user_constraints':['第1题题干未取得；只保留“不清楚，调研弹窗以后考虑”，不猜测画像。','搭档均衡和对手均衡并重。','实际使用未知；留痕完成度需查代码与实收边界。','只进行远端检查；不操作用户设备。','关注资源效率；日均90人不换算成并发/费用。','尽量全面检查；本轮以核验与汇总为交付，不修复。']},
 'findings_reconciliation':{'original_unique_entries':len(original_ids),'original_priorities':original_counts,'combined_snapshot_entries':len(findings),'combined_snapshot_priorities':counts,'source_records_identical_except_owner':source_matches,'unmerged_source_ids':unmerged_source_ids,'duplicate_ids':[],'BIZ_03_counted_once':True,'final_count_decision':'Keep18primaryfindings(2P1/12P2/4P3); TEL-02 is a separateP3hardeningobservation.'},
 'verification':{'official_test_files':len(files),'official_test_scope_matches':True,'raw_full_suite':tap_counts,'raw_full_suite_exit_code':1,'targeted_recheck':{'tests':10,'pass':10,'fail':0,'does_not_replace_full_suite':True},'ranking_cases':200,'ranking_comparisons':400,'singles_score_pairs':4107,'singles_score_comparisons':8214,'template_families':60,'template_prefixes':941,'singles_flows':60,'rank_states':1014,'runtime_cases':31,'root_npm_audit_entries':97,'matched_lock_paths':102,'all_matched_paths_marked_dev':True,'historical_roadmap_rows':roadmap_rows},
 'audit_objectives':objectives,'historical_roadmap':history_matrix,'required_report_updates':corrections,'precision_notes':precision,'TEL02_independent_classification':tel02_review,
 'completion':{'this_review':'completed','available_remote_source_metadata_public_dependencies_and_offline_audit':'completed_with_findings','current_remote_access_followup':'performed_no_usable_authenticated_cloud_readonly_entry_found','comprehensive_audit_online_portion':'blocked_incomplete','historical_12_product_plan':'not_accepted_as_complete','confirmed_issues':'unfixed_by_design_current_scope_is_inspection','online_unknowns':'unverified_not_passed','no_full_scope_pass_rate':True,'document_precedence':'Use newest dated root followup and final main report; earlier narrative completion sentence does not supersede current open online checks.'},
 'input_snapshots':snapshots,
 'finalVerification':{'verifiedAtUtc':datetime.now(timezone.utc).isoformat(),'narrativePath':'root/audit-narrative.txt','narrativeSha256':sha(EVIDENCE/'root/audit-narrative.txt'),'narrativeBytes':(EVIDENCE/'root/audit-narrative.txt').stat().st_size,'corrections':{row['id']:row['status'] for row in corrections},'original_review_excerpts':'Original sentences and initial line locations are retained in required_report_updates; no complete first-read narrative snapshot was saved.','opening_and_closing_state_online_incomplete':True,'section11_contains_six_readonly_evidence_groups':True,'primary_findings':18,'primary_priorities':original_counts,'TEL02':'separate_P3_observation_not_primary','github':'public; 6 repository historical Actions; 0 at pinned HEAD','parent_last_remote_head_check':'2026-10-09 09:11:42 UTC; same pinned commit; reported by parent, not a new network request by this reviewer','cloud_dependency_evidence':{'source':follow_root+'cloud-dependency-audit/summary.json','review_type':'Reconciled parent-supplied summary and lock hash; did not rerun registry resolution or npm audit','entries':17,'resolved_paths':162},'online_status':'blocked_incomplete','checkout_clean':git('status','--porcelain')==''}
}
HERE.mkdir(parents=True, exist_ok=True)
(HERE/'coverage-matrix.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

lines = [
 '# 全面远端检查的完成度与结论独立审校',
 '',
 f'固定提交：`{COMMIT}`。本专项读取既有报告、原始结果、实际源码入口及历史计划，未重跑公平性实例、未改源码、未提交部署、未接触用户设备或生产数据。开始和收口时 checkout 均为 `master`、工作树干净。',
 '',
 '**审校结论：原有 18 条发现及 2 P1 / 12 P2 / 4 P3 计数正确；没有发现必须撤回的原条目或把线上未知判为通过的结论。固定 HEAD 的源码检查和已执行离线核验可以收口，发现尚未修复不影响“检查完成”。历史 12 项开发计划仍未通过完整产品验收，其剩余开发、设备和云验收不是这次检查的实施清单。**',
 '',
 '主控已完成当前云端入口线索、插件及CLI可用性核验，未取得可用的已认证云端只读入口。因此本次可读取的远端源码、GitHub、公共依赖和合成验证完成；全面检查中涉及当前平台实况的部分仍受阻未完成。最新日期的补查 `../root/report.md` 与最终总报告优先，不能用旧报告“检查与报告完成”的结束句覆盖这些开放项。',
 '',
 'TEL-02 独立复核后不支持 P2 缺陷分级，主控已采纳，保留为单独的 P3 输入防护观察，不增加主发现数。主发现仍为18条、2 P1 / 12 P2 / 4 P3。',
 '',
 '未取得本次获批检查计划的独立原文文件。按主控确认，以当前可见用户六点及根报告七类目标作本次范围依据；`docs/tasks/current.md` 指向的是历史开发 12 项，不能声称已逐字取回本次原计划，也不能把历史授权自动恢复。',
 '',
 '## 已独立核实的数字与重要结论',
 '',
 '| 核验 | 结果与边界 |','|---|---|',
 '| 原发现登记 | 18 个唯一 ID；业务 5、公平性 4、留痕/效率 8、UI 1；BIZ-03 的跨专项引用只计一次。17 个分专项结构化条目与合并版逐字段一致（仅新增 owner）；UI-01 另有根 onLoad 复现。 |',
 '| 优先级 | P1 为 BIZ-01 旧 V1 数据覆盖与 BIZ-04 指定 SDK 请求事务标识缺失；P2 12 项、P3 4 项。CVE 的 critical/high 分类没有混入本项目 P1 数量。 |',
 '| 全量范围 | 实际运行的 307 个测试文件与官方 `tests/*.test.js` 完全相同，没有以过滤后的子集冒充全量。原 TAP 为 1777 / 1768 pass / 7 fail / 2 skip、退出1；10/10 定向复核独立记录，不能算全量零失败。 |',
 '| 公平性和排名 | 84 单打例、384 固搭核心例/320 休息字段反例、60模板/941前缀、4107比分对/8214两端断言、200排名样例/400两端对照、60流程/1014排名状态、31运行时例均与原JSON吻合。它们没有统一可加总的分母。 |',
 '| FA-01 / FA-03 | 明确以最大连打1→2换取搭档/对手覆盖改善，属于当前用户偏好下的质量断崖/产品取舍，不是硬赛程非法，也不是无代价严格支配。 |',
 '| FA-02 | 同队3–5场可改为人人4场；搭档重复不增、对手11→10、连打及最大连续休息不变差。根Python独立重算通过，只能称已核查指标下严格改善。 |',
 '| FA-04 | 实际生成器到页面投影的休息名单缺失，不是原生屏幕验收，亦不代表对阵和排名错误。 |',
 '| 两个重点参数可达性 | 8人1场地17场与12v10/5场地/24场经实际创建、设置与开赛源入口保留原值；前者不是被页面截到16的不可达内部例。 |',
 '| 业务影响边界 | BIZ-04精确请求无transactionId不等于已看到生产回滚事故；BIZ-01限V1兼容；BIZ-02未证明取得主办/协管；BIZ-03赛事仍running且零写；BIZ-05云端更正仍正确、仅本地投影旧。 |',
 '| 资源与依赖 | 账本读取公式逐样本吻合；DB方法数不等于账单。根npm快照97条目对应102个lock路径，均标dev；主控本轮补查公共云候选锁162路径/17条目，本专项只复核摘要与锁哈希，未重新执行扫描。两树数量不相加、不乘26，也不代表部署包漏洞实况。 |',
 '',
 '## 本次七类检查的客观状态',
 '',
 '| 检查目标 | 本次检查状态 | 尚不能证明 |','|---|---|---|'
]
for row in objectives:
    lines.append(f"| {row['objective']} | {row['observed']} | {row['unverified']} |")
lines += ['', '“源码检查已完成”描述限定范围的审计产出；“存在缺陷”描述被检查对象；“线上部分受阻未完成”描述本次整体检查仍缺的证据。三者可以同时成立，不能互相替代。主控已保存本轮实际入口核验，不能只引用历史失效会话当作本次结果，也无需为此操作用户设备。', '', '## 根报告更正记录：三项均已应用', '', '以下保留首次读取时的原句和位置，作为审校输入。已逐句核读10月9日最终叙事，COV-01、COV-02、COV-03均为applied；最终位置与实际采用文本记录在coverage-matrix.json。未保存首次读取的完整叙事文件，以下摘录不能冒充原文全量快照。', '']
for row in corrections:
    lines += [f"### {row['id']}：已应用（原位置 {row['target']}）", '', f"原句：{row['original']}", '', f"原因：{row['reason']}", '', f"当时建议：{row['replacement']}", '', '最终核验：'+'；'.join(f"第{x['line']}行已载明“{final_correction_text[row['id']]}”" for x in row['final_evidence'])+'。', '', '依据：'+'；'.join('`'+s+'`' for s in row['sources'])+'。', '']
lines += ['这些是报告范围和历史验收完整性的更正，不新增业务漏洞，不改变原18条优先级。', '', '## 必须保留的表述边界', '']
for item in precision:
    lines.append(f"- `{item['target']}`：{item['note']}")
lines += ['', '## TEL-02 的独立分级意见', '', '**建议 P3 输入防护观察，单列而不计入18项主发现；不支持原提议的 P2 缺陷。主控已经采纳。**', '', '已确认的行为是：公开CLI接受早于目标日的 `fetched_at`、fixture主动提供的 `key7=0`，以及操作者后移的 `latestComplete`，使D7子项变为0/complete；逐输入的新鲜度没有交叉校验。并非只有内部函数可达。', '', '但文档112行要求人工根据已核实接口状态指定水位，120–121行要求目标key确有数值且零仅来自明确0。当前证据没有证明真实未成熟接口会返回fixture那种占位，尚不能证明真实正常约定用法产生错误留存率。root独立对照删除key7后仍为null/missing；合成报告的整体 `window.status` 也是missing，不能说整份报表变成完整经营报告。', '', '建议报告措辞：合成旧快照与后移人工水位可形成未被拒绝的矛盾输入，建议增加逐输入新鲜度校验；真实API是否存在该形状及历史损害均未证实。不能写脚本自动推进水位、任意旧输入补0或历史报表已错。将来若取得受支持采集链实际返回和成熟后权威数据，可以重新评估；本轮不为此制造调用或修改统计代码。', '']
lines += ['', '## 历史12项：对账完成，产品验收未闭合', '', '| 项 | 历史验收目标 | 本次新证据 | 仍缺的证据 |','|---|---|---|---|']
for n,title,need,done,gap in history:
    lines.append(f'| {n} {title} | {need} | {done} | {gap} |')
lines += ['', '原计划出处：`docs/reports/2026-10-03-online-audit-and-roadmap.md:93–112`；当前状态出处：`docs/tasks/current.md:19–32` 和 `docs/tasks/paused-plan-status.md:35–54`。其中历史“38函数已恢复”和本次“26受管函数”属于不同清单，不能相减得出12函数丢失。原快照1793测试和本次1777也分别保留，未重新运行历史未跟踪候选来凑数。', '', '## 证据与收口', '', '`coverage-matrix.json` 保存七类范围、十二项历史验收、原18条对账、精确数字、原句及已应用更正、读取文件SHA-256，以及最终finalVerification。`review-evidence.py` 只读取本地证据并核对内容，不运行应用、不请求外网；原算法与业务复现没有重跑。', '', '复核命令：', '', '```bash', 'AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo python3 /workspace/scratch/0dae7c352c6b/remote-audit/evidence/remote-followup-20261009/coverage/review-evidence.py', '```', '', f"最终核读的总叙事SHA-256：`{result['finalVerification']['narrativeSha256']}`（{result['finalVerification']['narrativeBytes']}字节）。主控最后一次远端HEAD核验为2026-10-09 09:11:42 UTC，仍为固定提交；本专项未另发远端请求。", '', '本专项收口状态：完成度/结论审校完成；三处范围/验收更正全部应用，最终条目数为18项主发现加1项单列P3观察。主控的本轮远端访问核验与公共云依赖补查已纳入，线上实况仍因读取条件不足而受阻未完成。没有要求以修复所有问题、恢复设备或完成历史产品计划作为本次检查交付的前置条件。', '']
(HERE/'report.md').write_text('\n'.join(lines))
print(json.dumps({'review':'passed','original_entries':len(original_ids),'original_priorities':original_counts,'combined_snapshot_entries':len(findings),'unmerged_source_ids':unmerged_source_ids,'official_test_files':len(files),'roadmap_rows':len(roadmap_rows),'required_report_updates':len(corrections),'gitStatus':git('status','--porcelain')},ensure_ascii=False,indent=2))
