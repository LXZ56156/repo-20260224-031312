'use strict';
// Offline, synthetic fixture; unchanged repository report module; no API calls.
const fs = require('node:fs/promises');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const root = process.env.AUDIT_REPO ? path.resolve(process.env.AUDIT_REPO) : path.resolve(__dirname, '../../../repo');
const { buildReport } = require(path.join(root, 'scripts/we-analysis-report.js'));
async function main() {
  const fixturePath = path.join(__dirname, 'synthetic-dailyRetain-20261001.json');
  const fixture = {
    type: 'dailyRetain', begin_date: '20261001', end_date: '20261001',
    fetched_at: '2026-10-02T00:00:00.000Z',
    raw: { ref_date: '20261001', visit_uv_new: [{ key: 0, value: 100 }, { key: 1, value: 0 }, { key: 7, value: 0 }, { key: 14, value: 0 }], visit_uv: [] }
  };
  await fs.writeFile(fixturePath, JSON.stringify(fixture, null, 2) + '\n');
  const params = { files: [fixturePath], begin: '20261001', endExclusive: '20261002' };
  const original = await buildReport({ ...params, latestComplete: '20261001' });
  const later = await buildReport({ ...params, latestComplete: '20261008' });
  const oldD7 = original.window.newRetention.find(x => x.day === 7);
  const laterD7 = later.window.newRetention.find(x => x.day === 7);
  assert.equal(oldD7.rate, null);
  assert.deepEqual(oldD7.immature, ['20261001']);
  assert.equal(laterD7.rate, 0);
  assert.equal(laterD7.status, 'complete');
  assert.equal(laterD7.matureCohorts, 1);
  assert.equal(original.inputs.files[0].sha256, later.inputs.files[0].sha256);
  const result = {
    observationId: 'TEL-02', category: 'input-validation-observation', priority: 'P3', countedInConfirmedFindings: false, overallWindowStatus: later.window.status, evidenceKind: 'synthetic-offline-production-module',
    source: 'scripts/we-analysis-report.js:82-95,127-140; scripts/fetch-we-analysis.js:367-372',
    fixture: path.basename(fixturePath), fetchedAt: fixture.fetched_at,
    targetD7Date: '20261008', identicalInputSha256: original.inputs.files[0].sha256,
    firstRun: { latestComplete: '20261001', d7: oldD7 },
    secondRun: { latestComplete: '20261008', d7: laterD7 },
    noNetwork: true, applicationSourceUnchanged: true,
    scopeLimit: 'Synthetic explicit key7=0 accepted under a later manual watermark; not proven to match real immature D7 API output. Overall window remains missing. Input-defense observation only, not a confirmed live statistics defect.'
  };
  const argv = [path.join(root, 'scripts/we-analysis-report.js'), '--file', fixturePath, '--begin', '20261001', '--end-exclusive', '20261002', '--latest-complete', '20261008'];
  const cli = spawnSync(process.execPath, argv, { encoding: 'utf8', timeout: 5000 });
  assert.equal(cli.status, 0);
  const cliReport = JSON.parse(cli.stdout);
  assert.equal(cliReport.window.newRetention[1].rate, 0);
  assert.equal(cliReport.window.newRetention[1].status, 'complete');
  assert.equal(cliReport.window.status, 'missing');
  await fs.writeFile(path.join(__dirname, 'retention-freshness-cli-report.json'), cli.stdout);
  await fs.writeFile(path.join(__dirname, 'retention-freshness-cli-receipt.json'), JSON.stringify({ category: 'input-validation-observation', priority: 'P3', countedInConfirmedFindings: false, overallWindowStatus: cliReport.window.status, argv, exitCode: cli.status, signal: cli.signal, stderr: cli.stderr, d7Status: cliReport.window.newRetention[1].status, d7Rate: cliReport.window.newRetention[1].rate, sourceUnchanged: true, noNetworkByProgramDesign: true }, null, 2) + '\n');
  result.publicCliExitCode = cli.status;
  result.publicCliD7Status = cliReport.window.newRetention[1].status;
  const missingFixturePath = path.join(__dirname, 'synthetic-dailyRetain-missing-key7.json');
  const missingFixture = structuredClone(fixture);
  missingFixture.raw.visit_uv_new = missingFixture.raw.visit_uv_new.filter(row => row.key !== 7);
  await fs.writeFile(missingFixturePath, JSON.stringify(missingFixture, null, 2) + '\n');
  const missingArgv = [...argv]; missingArgv[2] = missingFixturePath;
  const missingCli = spawnSync(process.execPath, missingArgv, { encoding: 'utf8', timeout: 5000 });
  assert.equal(missingCli.status, 0);
  const missingReport = JSON.parse(missingCli.stdout);
  assert.equal(missingReport.window.newRetention[1].rate, null);
  assert.equal(missingReport.window.newRetention[1].status, 'missing');
  result.missingKeyControl = { cliExitCode: missingCli.status, d7: missingReport.window.newRetention[1], overallWindowStatus: missingReport.window.status };

  await fs.writeFile(path.join(__dirname, 'retention-freshness-results.json'), JSON.stringify(result, null, 2) + '\n');
  process.stdout.write(JSON.stringify({ observationId: result.observationId, oldRate: oldD7.rate, laterRate: laterD7.rate, laterStatus: laterD7.status, unchangedInputHash: original.inputs.files[0].sha256 === later.inputs.files[0].sha256, passed: true }) + '\n');
}
main().catch(e => { console.error(e.stack); process.exitCode = 1; });
