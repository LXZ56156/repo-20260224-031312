# 2026-10-09 云端部署、权限索引和备份恢复证据补查

本轮已完成指定仓库范围的补查。**仓库保留了详细的历史执行记录、预期配置和工具源码，但本次未找到可独立重算的完整云端导出、部署回执、规则/索引响应或恢复结果原件。**这些原件主要被文档引用到未入库的 `tmp/` 或用户机器的备份目录。本轮没有访问那些设备，也没有将历史自述升级为当前云环境验证。

审计固定于 `a3fe96f25015892ac30ee7148f97a5b441b0cb24`。开始和结束时 `git status --porcelain` 均为空；当前 Git 树共 1,638 个已跟踪文件，本地配置登记 26 个云函数。没有修改业务源码、重跑先前反例、执行部署/恢复、访问云 API 或检索凭据。仓库可见性及最新远端 HEAD 由主控另行核对，本报告不将仓库称为私有。

结构化结果见 [evidence-matrix.json](evidence-matrix.json)，共 **20 条证据记录**。每条包含准确来源文件和行范围、正文记载的事件时间、覆盖环境、证据类型、原件引用位置、仓库内可用性及结论边界。另保存来源 SHA-256 和当前可观察提交时间。此次 clone 经核实为 shallow，无法据边界 HEAD 判定文件真正的最后改动日期，矩阵将其明确标为未知，没有为此下载历史。**Git 提交时间、文件名日期都不当作云端采集时间**。

## 部署与版本：可以追溯历史，尚不能对齐今天的云端

| 矩阵 ID | 仓库中确实存在的来源 | 正文事件时间与覆盖环境 | 可用结论和缺口 |
| --- | --- | --- | --- |
| REM-01 | `docs/tasks/session-logs/2026-09-23-online-release-confirmed.md:3–18` | 9-23 查看客户端版本；记录发布时间 9-14 12:32 | 记载正式版 `6.1.2-702625a` 及源码映射。用户提供的平台截图原件未在本次仓库盘点中找到；`current.md` 明确本轮未实时重核。只属于客户端发布记录。 |
| REM-02 | `docs/reports/2026-10-03-backend-audit.md:6–22` | 10-03 01:34–01:49，上海生产环境 | 记载当时 39 个函数、23 个受管函数 Active/Available、23 个 `index.js` 一致。原始 `detail-*.json` 等位于未入库目录。这个比对只覆盖入口，不覆盖全包和依赖。 |
| REM-03 | `docs/tasks/session-logs/2026-10-03-start-timeout-repair.md:29–49` | 10-03 02:32:05，生产 `startTournament` 单函数 | 记载已部署、Timeout 3→10、20 个非依赖源码校验及缺参烟测；完整包的间接依赖也有变化。`deploy.log`、`detail-after.json`、`verification.json`、重新下载的代码均未入库。不能说另外函数也已同步部署。 |
| REM-04 | `cloudbaserc.json` | 本次固定提交的配置；没有云采集时间 | 当前登记 26 函数，全部 `installDependency:true`，仅开赛显式 `timeout:10`。这是配置，不是平台状态或部署回执。 |
| REM-17 | `docs/tasks/session-logs/2026-10-03-dependency-inventory.md:60–93` | 10-04/05，Windows/Linux 本地完整依赖包 | 先有 26 组旧源，再有单打 9 函数新包。文档明确 `targetEnv:null`、`isolationOnly:true`、只加载 SDK、未调用 main。包和原始回执未入库；本地 Linux 加载不能证明 CloudBase 接受或业务执行。 |

`startTournament` 的 10-03 部署发生在同日 23 个入口一致检查之后；当前提交还包含后续协管、提前收赛、找回和单打等变化。必须保留这些先后关系，不能拼接成“当前 26 个函数均已部署且与本次源码一致”。

可优先复用的历史原件入口是：

- `tmp/online-audit-2026-10-03/backend/`：当时函数清单、详情、规则、索引摘要。
- `tmp/audit-2026-10-03/startTournament-deploy/`：单函数实际部署及后验原件。
- `tmp/audit-2026-10-03/startTournament-rollback/manifest.json`：旧回退包的文件清单。文档明确当时没有单独保留原 ZIP，而是保留解压文件及逐文件 SHA。
- `tmp/singles-cloud-packages-20261005/`：后续单打本地候选，只可用于候选来源核对。

上述路径在固定 Git 树中均无对应产物；本报告仅标明来源，不尝试访问用户 Windows 设备。

## 权限、索引与真实身份：已有有限历史观察，范围不能扩大

| 矩阵 ID | 来源 | 日期/环境 | 已记录内容与限制 |
| --- | --- | --- | --- |
| REM-05 | `scripts/water-v2-cloud-bootstrap.manifest.json` | 无环境绑定的初始化声明 | 7 个集合、5 个索引、初始 revision 1、V2 默认关闭。文件明确 `declaration-only / remoteAccess:false / applySupported:false`；不能作为真实云配置。 |
| REM-06 | `docs/tasks/session-logs/2026-10-03-database-permission-preparation.md:3–17` | 10-03，当时 13 个生产集合 | 记录赛事 `CUSTOM`、登录可读、写入依据 `doc._openid`；其余按 `ADMINONLY`、`PRIVATE` 分组。原 `rule.json`/`rules-*.json` 不在仓库。预设 ACL 的空 Rule 不能解释为任意访问。 |
| REM-07 | `docs/reports/2026-10-03-backend-audit.md:80–92` | 10-03，当时生产索引 | 记录 5 个 water 索引字段方向一致，以及赛事 `playerIds ASC + status ASC`。缺今天完整索引定义及构建状态；旧 membership 索引不证明新增找回接口的双路排序/数组查询已经验收。 |
| REM-08 | 同上 `90–92` | 10-03，water 功能配置 | 记录 revision 11、V2 开关 true、紧急只读 false、灰度列表空。引用的脱敏 metadata 未入库；不能把源码默认 false 或历史 true 当今天实际值。 |
| REM-09 | 权限准备日志 `88–96` | 10-05 03:15:36，现有环境、单账号、DevTools SDK 3.17.2 | 记录一次真实 `login` 返回身份非空和 AppID 匹配。原始脱敏回执和图未入库；只覆盖这一次身份链路，不覆盖手机、其他账号、赛事角色或事务。 |
| REM-10 | 权限准备日志 `118–134` | 10-05 04:08:01，现有环境中专用临时集合 | 记录候选 `write:false` 下 2 读成功、8 写拒绝、4 合成文档不变、原 16 规则不变；04:14:40 观察到临时集合清理。原件未入库，驱动也保留 `engineOriginVerified/engineValidationPassed:false`。生产赛事规则未因此更改。 |

权限日志已经明确指出：**单账号临时集合候选规则观察，没有闭合现有业务函数兼容、角色矩阵、事务冲突/回滚、双账号双机或生产赛事新增路径。**本轮保留这一限定结论，不再用既有业务模拟用例替代它。

`docs/tasks/session-logs/2026-10-03-new-cloud-isolation-checklist.md` 是可复用的验收计划：规定提前收赛、锁、录分的配套版本，协管的多个权限消费者，以及真实 A/B/C、guest 和未登录状态。它是计划，当前的只检查任务没有执行其中部署或测试写入的授权。

## 备份恢复：历史记录分层完整，原件仍待只读交接

| 矩阵 ID | 来源及正文日期 | 文档记载的结果 | 本轮保留的边界 |
| --- | --- | --- | --- |
| REM-11 | `2026-10-03-backup-reconciliation.md:3–13、78–88`；补记 10-05 | 13,925/14,025 为汇总文字错数；13/16 集合差因仍未知。另三历史集合做两遍 JSON 观察和双盘补档。 | 三集合补档不是 16 集合新原子快照，不等于这三集合完成 BSON 恢复。不能推断它们是新建或原备份漏页。 |
| REM-12 | `2026-10-03-backup-integrity-verification.md:3–24` | 选定 raw pass 2：259 页、13,925 文档；2,735 对象重读一致；13,072 引用匹配；38 可用函数包核验。 | 原始 manifest、raw、完整性 JSON 未入库。历史另 1 函数无可下载代码，不得写成 39/39 完整。在线两遍一致不证明跨集合原子性。 |
| REM-13 | `2026-10-03-local-restore-verification.md:5–43` | 10-03 06:18:29–06:18:36，本机 MongoDB 恢复 13 集合/13,925 文档，hash、类型往返一致；33 索引。 | 13 个 `_id_` 的 unique 属性有平台差异，原报告明确 `indexesExactlyEqual:false`。这是本机数据库恢复，不是整套 CloudBase 服务恢复。 |
| REM-14 | `2026-10-03-second-disk-backup-review.md:5–42` | 第二物理盘归档的清单和封口 metadata 校验。 | 该阶段没有重新计算整个 tar 或执行恢复；后续实际恢复要引用下一阶段。用户已明确异地/离线不作为此次门槛，不能再据此扩张任务。 |
| REM-15 | `2026-10-03-second-disk-database-restore.md:9–34` | 10-03 07:59:19–07:59:26，从第二盘归档提取 733 文件，在新本机库实际恢复，结果与原演练一致。 | 仓库只保留叙述和结果 SHA，没有报告原件可核对；恢复工具本体取自原任务目录，未包含在该归档内。 |
| REM-16 | 同一日志 `3–7` 的后续补记 | 10-04 17:28:07–18:25:39，长路径版提取 246,398 成员，重读 2,735 对象/38 函数，引用匹配。 | 应记录后续已恢复文件资产，不能继续沿用早阶段“存储/函数未恢复”；仍未证明云服务启动、业务运行和整体恢复。 |

以上会话日志均位于 `docs/tasks/session-logs/`。它们引用了可望复用的原件：

- `2026-10-03-0607/database/manifest.json`、各集合 selected raw pass、`cloud/database/<集合>/rule.json` 和 `table.json`。
- 同备份根的 `verification/storage-reread-and-references.json`、`cloud-package-integrity.json`、`restore-report.json`、`backup-index.json`。
- 第二盘的 `source-manifest.json`、`verification.json`、`database-restore-receipt-20261003.json`，以及从该盘恢复后的 `extraction-verification.json`、`acceptance-summary.json`。
- `tmp/second-disk-assets-restore-20261004/` 的实际退出回执、恢复结果和独立复核文件。
- `2026-10-05-legacy-observed/` 的 manifest、SHA256SUMS 和 `tmp/legacy-collection-archive-20261005/` 的补档核验结果。

完整外部根位置已由原会话日志记载。这里保留相对后缀，避免再复制个人机器路径或业务内容。本轮没有打开这些备份，也没有生成新的云备份或执行恢复。

仓库中的 `scripts/backup-cloud-database.js` 可作为工具实现证据：限制为读取端点、保存 raw JSON 字符串、检查多遍内容，并主动声明 `ONLINE_NON_ATOMIC_NOT_FINAL_SNAPSHOT`。**工具存在不等于导出原件存在或恢复已通过。**本轮未运行该工具；其中 `verifyRawPasses` 会写回本地 manifest，也没有拿它修改既有证据。

## 当前仍未验证的项目与最小只读取证

以下补充仅需要既有结果或读取接口，无需生产业务写入。采集时保存实际时间、统一环境代号、完整分页及原件/脱敏副本关联；敏感原件可继续保留在受控位置，审计只接收所需字段。

| 目的 | 最小需要的只读材料 | 材料到位后能确认什么 |
| --- | --- | --- |
| 当前环境和近期可用性 | 区域、环境状态、服务状态、当前套餐到期/续费状态、采集时间 | 排除把旧环境状态当今天状态。10-03 文档记载到期为 10-12 23:59:59；没有当前回执，不能断言今天仍未续费。 |
| 当前函数/源码对应 | 完整函数列表；名称、Status/CodeStatus、Runtime、Timeout、Memory、Handler、InstallDependency、修改时间、包摘要；相关函数完整源码/依赖文件 SHA 清单 | 确认哪一版实际部署，尤其本次 BIZ-04 涉及的 5 个入口及新增收赛/协管/找回函数。只比 `index.js` 不够。无需环境变量值或下载签名 URL。 |
| 当前规则和索引 | 完整集合清单与分页；每集合的 AclTag/Rule；索引名称、字段顺序、方向、unique/sparse/partial、构建状态 | 可确认当前静态配置，比较历史 13/16 集合差别，检查预期索引是否存在。仍不能单靠配置判真实事务/权限执行通过。 |
| 当前 water 开关 | revision、布尔开关、灰度名单数量、采集时间 | 确认当前是否开放及只读状态，不需要任何名单身份或账本内容。 |
| 历史备份/恢复可复核性 | 脱敏 manifest：集合数、文档/页数、selected pass、hash；存储/函数完整性摘要；恢复报告、源绑定、runtime/退出结果、索引差异；三历史集合补档 manifest | 核对先前结果、来源和范围。第一阶段无需下载 13,925 条用户文档、头像或整个归档。若要重新计算内容 hash，再单独限定受控原件访问。 |
| 单号权限历史证据 | 脱敏身份布尔、十类 ACL 操作结果、前后聚合 hash、规则对比、清理观察回执 | 能复核那一次临时测试的限定结论，不扩展成原生产赛事规则或多角色验收。 |
| 当前客户端发布版 | 脱敏平台版本详情及源码映射、发布时间 | 区分远端仓库、云函数和已发布客户端三条版本线。 |

**仅靠只读取证仍不能新增证明**真实云引擎的竞争回放/回滚、多角色双设备行为或整套 CloudBase 恢复。这些项目若没有已有且完整的真实执行回执，应继续记为未验证；本轮不会为了补齐状态而运行生产测试或恢复演练。

本轮没有新增业务缺陷编号；原业务专项 [5 项问题报告](../../business/report.md) 保持独立，不重复运行已经充分验证的反例。补查的新增价值是明确 **20 条证据的来源与时点、原件缺口及最小补证范围**，使总报告能够准确区分“代码已检查”“历史记录可追溯”和“当前云端已验证”。
