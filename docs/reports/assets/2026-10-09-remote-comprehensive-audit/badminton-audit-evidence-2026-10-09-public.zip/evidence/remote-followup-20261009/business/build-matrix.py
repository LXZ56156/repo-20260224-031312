import json, hashlib, subprocess, fnmatch
from pathlib import Path

REPO=Path('/workspace/scratch/0dae7c352c6b/remote-audit/repo')
OUT=Path(__file__).parent
COMMIT='a3fe96f25015892ac30ee7148f97a5b441b0cb24'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
assert git('rev-parse','HEAD')==COMMIT
assert git('status','--porcelain')==''
SHALLOW=git('rev-parse','--is-shallow-repository')=='true'
tracked=set(git('ls-files','-z').split('\0'))
tracked.discard('')
rows=[]
def src(path,lines):
    c=git('log','-1','--format=%H%x09%cI','--',path).split('\t')
    return {'path':path,'lines':lines,'sha256':hashlib.sha256((REPO/path).read_bytes()).hexdigest(),
            'observedCommit':c[0],'observedCommitDate':c[1],
            'lastChangeDateStatus':'unknown_in_shallow_checkout' if SHALLOW else 'available_in_local_history',
            'commitDateIsNotObservationDate':True}
def add(i,area,date,env,kind,path,lines,claim,refs,limits):
    row={'id':i,'area':area,'reportedObservationDate':date,'dateTimezone':'Asia/Shanghai unless explicitly UTC',
         'environmentScope':env,'evidenceType':kind,'source':src(path,lines),'recordedClaim':claim,
         'rawEvidenceAvailableInPinnedRepository':False,
         'referencedArtifacts':[{'path':p,'availability':'external_location_not_accessed' if p.startswith('<') else 'not_in_pinned_git_tree',
             'trackedMatches':sorted(f for f in tracked if fnmatch.fnmatch(f,p) or f.startswith(p.rstrip('/')+'/'))} for p in refs],
         'currentCloudVerified':False,'limits':limits}
    if kind in ['declaration','tool_source','acceptance_plan']:
        row['sourceReusableAs']=kind
    else:
        row['sourceReusableAs']='historical_provenance_pointer_only'
    rows.append(row)

add('REM-01','client_release','2026-09-23; recorded release 2026-09-14 12:32','published mini-program client','historical_observation_narrative',
 'docs/tasks/session-logs/2026-09-23-online-release-confirmed.md','3-18',
 '文档根据用户提供平台截图记录正式版6.1.2-702625a，对应702625a3afeeffb4254a4d2c155ef7df28a9a2d8。',
 ['<user-provided-platform-version-screenshot; no retained repository artifact identified>'],
 ['截图原件不在当前仓库证据中','仅客户端发布，不证明云函数版本','current.md明确本轮未实时重核'])
add('REM-02','function_inventory_and_runtime','2026-10-03 01:34-01:49','primary production, Shanghai, then-managed 23 functions / total 39','historical_observation_narrative',
 'docs/reports/2026-10-03-backend-audit.md','6-22',
 '历史清点39函数；主线23个Active/Available，23/23 index.js字节相同；多数Node16.13/3秒，2个Node18.15/10秒。',
 ['tmp/online-audit-2026-10-03/backend/cli-functions.json','tmp/online-audit-2026-10-03/backend/detail-*.json','tmp/online-audit-2026-10-03/backend/functions-summary.json'],
 ['原始接口JSON缺失','入口一致不代表lib/logic/排阵/依赖全包一致','该时点早于当日startTournament单函数部署，更早于当前26函数源码'])
add('REM-03','actual_start_deployment','2026-10-03 02:32:05','primary production, startTournament only','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-start-timeout-repair.md','29-49',
 '记录一次仅startTournament部署、Timeout3→10、Active/Available、20源码比对和缺参TOURNAMENT_ID_REQUIRED；依赖包有3项间接变化。',
 ['tmp/audit-2026-10-03/startTournament-deploy/deploy.log','tmp/audit-2026-10-03/startTournament-deploy/detail-after.json','tmp/audit-2026-10-03/startTournament-deploy/code-download.json','tmp/audit-2026-10-03/startTournament-deploy/verification.json','tmp/audit-2026-10-03/startTournament-deploy/code/','tmp/audit-2026-10-03/startTournament-rollback/manifest.json'],
 ['执行和校验原件未入库','缺参启动不验证业务/事务','回退原始ZIP当时未保留，文档称保留解压文件与SHA','不能扩大到其他25函数或今天状态'])
add('REM-04','current_deployment_declaration','no cloud observation; pinned source inspected 2026-10-09','configured project target, not a queried deployment','declaration',
 'cloudbaserc.json','entire file; selected non-sensitive fields inspected',
 '当前声明26个函数；全部installDependency=true；仅startTournament显式timeout10。',[],
 ['注册不等于已部署','未声明的runtime/timeout/memory不能推定实际值','函数直接依赖锁定及供应链由主控专项核，不重复解析'])
add('REM-05','water_bootstrap_expected_state','no cloud observation; declaration in pinned source','explicit-at-execution, environment unbound','declaration',
 'scripts/water-v2-cloud-bootstrap.manifest.json','entire file',
 'declaration-only、remoteAccess=false、applySupported=false；7私有集合、5索引、初始revision1且V2功能关闭。',[],
 ['是期望初始化声明，不是实际规则/索引/flags快照','历史8-13交接写4索引，不能覆盖当前5项声明'])
add('REM-06','production_rules','2026-10-03 approximately 01:42 and 0607 backup','13 then-observed production collections','historical_observation_narrative',
 'docs/tasks/session-logs/2026-10-03-database-permission-preparation.md','3-17',
 '记录tournaments CUSTOM登录可读/write基于doc._openid，7集合ADMINONLY、5集合PRIVATE；预设ACL的空Rule不表示允许任意访问。',
 ['<backup-root>/2026-10-03-0607/cloud/database/<collection>/rule.json','tmp/online-audit-2026-10-03/backend/rules-*.json','tmp/online-audit-2026-10-03/backend/rules-summary.json'],
 ['缺原始Rule/AclTag回执','尚不能判定今天规则相同','存量无_openid不证明新增写路径拒绝','文档说明生产tournaments未应用write:false'])
add('REM-07','production_indexes','2026-10-03 approximately 01:42','water collections and tournaments in primary production','historical_observation_narrative',
 'docs/reports/2026-10-03-backend-audit.md','80-92',
 '记录5个water复合索引字段/方向一致，以及tournaments playerIds ASC+status ASC；记录使用次数是当时观察。',
 ['tmp/online-audit-2026-10-03/backend/indexes-*.json','<backup-root>/2026-10-03-0607/cloud/database/<collection>/table.json'],
 ['缺完整索引原件与当前build/status','旧membership索引存在不证明新增找回双路排序/数组查询合同或当前耗时'])
add('REM-08','production_feature_flags','2026-10-03 approximately 01:42','water_feature_flags/collaborative_v2 in primary production','historical_observation_narrative',
 'docs/reports/2026-10-03-backend-audit.md','90-92',
 '历史记录revision11、V2读写开关true、emergencyReadOnly=false、灰度名单空。',
 ['tmp/audit-20261003-data/water_feature_flags-metadata.json'],
 ['实际脱敏元数据文件未入库','不能把源码初始false或历史true当今天开关状态'])
add('REM-09','real_wechat_identity','2026-10-05 03:15:36 call; 03:16:18 receipt','primary production login, one real account, DevTools SDK3.17.2','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-database-permission-preparation.md','88-96',
 '记录一次真实客户端空参login，身份非空/AppID匹配；原件仅保存布尔及固定码。',
 ['tmp/wx-identity-readonly-root-20261005/actual-identity-receipt.json','tmp/wx-identity-readonly-root-20261005/runtime-info.json','tmp/wx-identity-readonly-root-20261005/actual-login.png'],
 ['原件缺失；本轮不能重核','只覆盖单账号DevTools→login，不覆盖手机、角色矩阵、ACL、事务和多设备'])
add('REM-10','temporary_acl_probe','2026-10-05 04:08:01; cleanup observed 04:14:40','new temporary synthetic collection in existing production environment, one real account','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-database-permission-preparation.md','118-134',
 '记录候选登录可读/write:false规则2读成功8写权限拒绝，4文档不变、原16规则不变、临时集合清理。',
 ['tmp/wx-acl-live-20261005-0347/actual-client-receipt.json','tmp/wx-acl-live-20261005-0347/','tmp/wx-acl-actual-cold-20261005/assessment.json'],
 ['完整before/after/规则/清理原件未入库','driver明确engineOriginVerified/engineValidationPassed=false','未修改现有业务集合规则，不证明原业务角色/事务通过','不能复用历史授权执行写入'])
add('REM-11','backup_13_vs_16_and_legacy_archive','2026-10-03 and 2026-10-05','13 historical business collections plus 3 separately observed legacy collections','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-backup-reconciliation.md','3-13; 78-88',
 '13925/14025差额归为文档汇总错；13/16集合差因仍未知。3历史集合两遍0/0/1文档、索引6/2/2，规则/manifest/SHA另存D/E。',
 ['tmp/audit-20261003-data/db-fetch-manifest.json','tmp/audit-20261003-data/inventory.json','tmp/audit-20261003-data/inventory-after.json','tmp/legacy-collection-archive-20261005/','<backup-root>/2026-10-05-legacy-observed/manifest.json','<second-disk-root>/2026-10-05-legacy-observed/SHA256SUMS'],
 ['无法对原清单重算','3集合JSON补档不等于16集合新原子快照或BSON恢复','不能推断3集合是新建或有3集合丢失'])
add('REM-12','backup_integrity','2026-10-03, selected backup root 0607','local exports of primary production','historical_verification_narrative',
 'docs/tasks/session-logs/2026-10-03-backup-integrity-verification.md','3-24',
 '记录selected pass2共259页13925文档；2735对象重读一致；13072引用全部匹配；38可用函数包一致，1历史函数无可下载代码。',
 ['<backup-root>/2026-10-03-0607/database/manifest.json','<backup-root>/2026-10-03-0607/verification/storage-reread-and-references.json','<backup-root>/2026-10-03-0607/verification/cloud-package-integrity.json','<backup-root>/2026-10-03-0607/verification/partial-preservation-after.json','tmp/verify-backup-integrity-0607.cjs'],
 ['清单/输入/逐项结果均不在仓库，无法本轮复算','在线非原子导出，不保证跨集合一致','38/39缺口保留，完整文件不代表整云可恢复'])
add('REM-13','local_database_restore','2026-10-03 06:18:29-06:18:36','isolated local MongoDB8.0.32, localhost27028','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-local-restore-verification.md','5-43',
 '记录13集合13925文档hash/类型一致；33索引、13个_id unique平台差异；四类引用无孤儿；进程退出。',
 ['<backup-root>/2026-10-03-0607/verification/restore-local-mongo.py','<backup-root>/2026-10-03-0607/verification/restore-report.json'],
 ['原始restore-report和源raw未入库','indexesExactlyEqual=false不能写全部索引相同','本机Mongo往返不证明CloudBase规则/身份/事务/OpenAPI/整体服务恢复'])
add('REM-14','second_disk_copy','2026-10-03','second physical disk on same Windows host','historical_verification_narrative',
 'docs/tasks/session-logs/2026-10-03-second-disk-backup-review.md','5-42',
 '记录251040文件/2605769727源字节，tar3061841920字节；metadata复核，D/E映射不同物理盘。',
 ['<second-disk-root>/2026-10-03-second-disk/source-manifest.json','<second-disk-root>/2026-10-03-second-disk/verification.json','<second-disk-root>/2026-10-03-second-disk/disk-location.json'],
 ['此文阶段未重新hash完整tar或执行恢复','同机第二盘不是异地/离线；用户后来已明确异地不为本轮门槛','仓库无归档及元数据'])
add('REM-15','restore_database_from_second_disk','2026-10-03 07:59:19-07:59:26','new isolated local MongoDB8.0.32, localhost27029, inputs from second-disk tar','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-second-disk-database-restore.md','9-34',
 '记录仅从E归档提取733文件并重做13集合13925文档恢复，hash/types一致、索引平台差异单列；文档保存结果SHA。',
 ['<second-disk-root>/2026-10-03-second-disk/database-restore-receipt-20261003.json','<backup-root>/2026-10-03-second-disk-restore/extraction-verification.json','<backup-root>/2026-10-03-second-disk-restore/acceptance-summary.json','<backup-root>/2026-10-03-second-disk-restore/0607/verification/restore-report.json'],
 ['存在文档内SHA不等于有可核验报告bytes','工具本体来自原任务目录，未包含于E归档','未证明CloudBase在线恢复'])
add('REM-16','restore_storage_and_function_assets','2026-10-04 17:28:07-18:25:39','new local extraction target, second-disk archive input','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-second-disk-database-restore.md','3-7',
 '后续记录长路径版246398成员提取、2735对象/38函数重读、13072引用匹配，原长路径失败保留。',
 ['tmp/second-disk-assets-restore-20261004/unified-exec-terminal-receipt.json','tmp/second-disk-assets-restore-20261004/postrun-execution-receipt.json','tmp/second-disk-assets-restore-20261004/postrun-cold-review.txt'],
 ['不是仅复制：文档确记后续恢复，不能继续沿用前阶段未恢复结论','当前仓库缺原件，仍只能按历史记载引用','仅文件资产，不是服务上线/函数执行/整体云恢复'])
add('REM-17','offline_candidates_not_deployment','2026-10-04/05; later singles candidate stage 2026-10-05','Windows/Linux isolated local packages; targetEnv=null/isolationOnly=true','historical_execution_narrative',
 'docs/tasks/session-logs/2026-10-03-dependency-inventory.md','60-93',
 '历史26组315源Linux证据后，单打又另建9函数包；真实SDK require，main/网络/子进程均0。',
 ['tmp/dependency-nine-eight-current-20261004/','tmp/dependency-nine-root-20261004/eight-acceptance.json','tmp/singles-cloud-packages-20261005/'],
 ['包/manifest/回执未入库','不同源码阶段不可合并说当前26包全部已云验证','离线require仅加载，不证明平台部署和事务','供应链解析由主控继续，此处不重复'])
add('REM-18','isolation_environment_and_expiry','2026-10-03 08:09; 12:39 and same-day page review','authorized visible regions Shanghai/Guangzhou/Singapore and existing primary production console','historical_observation_narrative',
 'docs/tasks/session-logs/2026-10-03-authorized-isolation-plan.md','15-20; 24-31; 51-58',
 '记录只见已知生产环境，免费路线未完成绑定；历史套餐到期2026-10-12 23:59:59、未自动续费。',
 ['<CLI environment-list raw receipts; not attached to report>','<CloudBase package/expiry page screenshot or raw receipt; not attached>'],
 ['旧授权可见范围不代表全球全部账号/区域','没有当前环境/到期/续费原件，不能宣称今天仍未续费','本轮不创建环境、不兑换或付款'])
add('REM-19','cloud_acceptance_plan','2026-10-03 plan with 10-04/05 updates','future explicitly confirmed isolation target','acceptance_plan',
 'docs/tasks/session-logs/2026-10-03-new-cloud-isolation-checklist.md','7-20; 24-34; 36-77',
 '列明finish+scoreLock+submitScore配套、协管8管理函数、找回双路索引和A/B/C/G/U角色，均要求真实平台验证。',[],
 ['清单不是执行结果','真实事务/跨设备/新索引查询不能靠只读源码完成','当前只检查授权不覆盖执行这些部署/写入步骤'])
add('REM-20','backup_tool_capability','no cloud observation; pinned source inspected 2026-10-09','explicit output/export target when executed; not executed this round','tool_source',
 'scripts/backup-cloud-database.js','4-11; 62-79; 222-281',
 '实现只读导出端点白名单、保留raw数据字符串、多pass内容核对，明确ONLINE_NON_ATOMIC_NOT_FINAL_SNAPSHOT。',[],
 ['工具代码不证明曾导出或当前backup存在','verifyRawPasses会写本地manifest，本轮不运行以保持现有证据原状','原始业务文档不应为补充审计而公开上传'])

for r in rows:
    for a in r['referencedArtifacts']:
        assert not a['trackedMatches'], (r['id'],a)
config=json.loads((REPO/'cloudbaserc.json').read_text())
matrix={'schemaVersion':1,'auditDateUtc':'2026-10-09','pinnedCommit':COMMIT,'shallowCheckout':SHALLOW,
 'repository':'LXZ56156/repo-20260224-031312','repositoryVisibility':'root independently verified public; not queried by this subtask',
 'scope':'repository evidence of cloud deployment, rules, indexes, backup and recovery',
 'worktreeCleanAtStartAndEnd':git('status','--porcelain')=='',
 'trackedFileCount':len(tracked),'declaredFunctionCount':len(config['functions']),
 'newBusinessDefectsAdded':0,'priorBusinessReport':'../../business/report.md',
 'currentCloudVerified':False,'reusableRawCloudOrRestoreEvidenceFilesInPinnedTree':0,
 'observedRepositoryArtifactsOutsideScope':'Historical 2026-08-31 UI receipt JSON exists; does not evidence cloud deployment, rules, indexes or recovery.',
 'operations':{'readPinnedRepository':True,'readGitMetadata':True,'cloudApiCalls':0,'businessSourceChanges':0,'testsRerun':0,'windowsDeviceAccess':False,'credentialSearch':False,'deployment':False,'businessWrites':False},
 'datePolicy':'Document filename and observed Git commit are not the event observation time; report narrative dates separately. In this shallow checkout actual last file change is unknown; do not treat boundary HEAD as file last change. All cloud claims remain historical until raw/current evidence is acquired.',
 'entries':rows,
 'minimumReadOnlyEvidenceRequests':[
  {'id':'REQ-01','purpose':'current cloud scope and near-term expiry','fields':['sampledAt','region','stable environment alias','environment/service status','package expiry','auto-renew state'],'exclude':['account IDs','payment information','credentials'],'writesRequired':False},
  {'id':'REQ-02','purpose':'map current deployed functions to audited source','fields':['complete paginated function list','name/status/codeStatus','runtime/timeout/memory/handler/installDependency','lastModified/codeSize/package digest','source and dependency per-file SHA manifest for affected and new function groups'],'exclude':['environment variable values','secret URLs','full business logs'],'writesRequired':False},
  {'id':'REQ-03','purpose':'current rules and indexes','fields':['complete collection list with cursor/count','per-collection AclTag and Rule','indexes names/key order/unique/sparse/partial/status','sampledAt and environment alias'],'exclude':['document bodies','OPENID'],'writesRequired':False},
  {'id':'REQ-04','purpose':'current water feature state','fields':['collaborative_v2 revision','boolean flags','canary list counts only','sampledAt and environment alias'],'exclude':['canary identities','ledger contents'],'writesRequired':False},
  {'id':'REQ-05','purpose':'historical backup and restore revalidation','fields':['sanitized database manifest with selected pass/count/page/hash','backup-index/storage/function integrity summaries','second-disk source/verification manifests','restore-report plus runtime/exit/source binding/known platform differences','legacy archive manifest and SHA256SUMS'],'exclude':['raw user documents','user avatars','original identity fields','absolute personal paths'],'writesRequired':False},
  {'id':'REQ-06','purpose':'historical deployment/identity/temporary ACL provenance','fields':['sanitized deployment verification/detail hashes','actual identity booleans/runtime/time','10 ACL case results and before/after aggregate hashes','rule before/after aggregate comparison','cleanup observed receipt'],'exclude':['OPENID/UNIONID','tokens','original private snapshots'],'writesRequired':False},
  {'id':'REQ-07','purpose':'current published client/source mapping','fields':['sanitized platform version detail with version/release time/source mapping'],'exclude':['account identity','QR codes'],'writesRequired':False}
 ],
 'cannotCloseWithReadOnlyEvidenceAlone':['Real cloud transaction replay/rollback and contention without existing valid execution receipts','Multi-role real WX and two-device behavior without existing valid execution receipts','Whole CloudBase service restoration without an existing completed isolated restore exercise','Cross-collection atomicity cannot be inferred from equal online export passes'],
 'notes':['No audit task completion is claimed for unavailable cloud or device checks.','No historical operational authorization is reused.','No public repository exposure is classified as a vulnerability merely from visibility.']}
(OUT/'evidence-matrix.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(rows),'currentCloudVerified':False,'rawCloudEvidenceFiles':0,'worktreeClean':matrix['worktreeCleanAtStartAndEnd'],'matrix':str(OUT/'evidence-matrix.json')},ensure_ascii=False,indent=2))
