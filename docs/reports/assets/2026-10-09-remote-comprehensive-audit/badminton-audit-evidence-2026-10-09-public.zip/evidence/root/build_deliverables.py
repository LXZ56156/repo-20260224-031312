#!/usr/bin/env python3
"""Build a self-contained audit report and a bounded, reproducible evidence archive."""
import collections
import datetime
import hashlib
import html
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

from lxml import html as lhtml

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'evidence'
REPO = Path(os.environ.get('AUDIT_REPO', str(ROOT / 'repo'))).resolve()
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
SHA = 'a3fe96f25015892ac30ee7148f97a5b441b0cb24'
REPO_URL = 'https://github.com/LXZ56156/repo-20260224-031312'
REPORT_NAME = 'badminton-audit-2026-10-08.html'
ZIP_NAME = 'badminton-audit-evidence-2026-10-08.zip'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def check_source():
    manifest = json.loads((EVIDENCE / 'baseline/source-manifest.json').read_text())
    changed = []
    for row in manifest['files']:
        p = REPO / row['path']
        if not p.is_file() or p.stat().st_size != row['bytes'] or digest(p) != row['sha256']:
            changed.append(row['path'])
    git = lambda *args: subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()
    head, status = git('rev-parse', 'HEAD'), git('status', '--porcelain')
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).split(b'\0')
    tracked = {p.decode() for p in tracked if p}
    expected = {row['path'] for row in manifest['files']}
    assert head == SHA and not changed and not status and tracked == expected
    result = {'checkedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'commit': head, 'trackedFileCount': len(expected), 'changedFiles': changed,
              'trackedSetMatches': tracked == expected, 'gitStatus': status, 'verified': True}
    write_json(EVIDENCE / 'root/final-source-integrity.json', result)
    return result


def combine_findings():
    business = json.loads((EVIDENCE / 'business/findings.json').read_text())['findings']
    fairness = json.loads((EVIDENCE / 'fairness/findings.json').read_text())['findings']
    telemetry = json.loads((EVIDENCE / 'telemetry/findings.json').read_text())['ownedFindings']
    ui = json.loads((EVIDENCE / 'telemetry/ui-config-coverage.json').read_text())['staticEdgeFindings']
    merged = []
    for owner, rows in [('business', business), ('fairness', fairness), ('telemetry', telemetry), ('ui', ui)]:
        for row in rows:
            merged.append({'owner': owner, **row})
    assert len(merged) == len({r['id'] for r in merged}) == 18
    counts = dict(collections.Counter(r['priority'] for r in merged))
    assert counts == {'P1': 2, 'P2': 12, 'P3': 4}, counts
    addendum = json.loads((EVIDENCE / 'remote-followup-20261009/telemetry/findings-addendum.json').read_text())
    observations = addendum.get('observations', addendum.get('newFindings', []))
    assert len(observations) == 1 and observations[0]['id'] == 'TEL-02'
    assert observations[0]['priority'] == 'P3' and observations[0]['countedInConfirmedFindings'] is False
    write_json(EVIDENCE / 'root/combined-findings.json', {
        'commit': SHA, 'entryCount': len(merged), 'priorities': counts,
        'interpretation': 'Audit entries include defects, quality tradeoffs and efficiency improvements; counts are not production incident counts.',
        'findings': merged,
        'observationCount': len(observations),
        'observations': observations,
        'auditScopeStatus': 'Available remote repository and synthetic checks completed; current cloud verification blocked by unavailable authenticated read access or missing raw evidence.',
    })
    return merged


def link_sources(markdown):
    def replace(match):
        label = match.group(1)
        m = re.fullmatch(r'((?:miniprogram|cloudfunctions|scripts|tests|docs)/[^:\s`]+)(?::(\d+)(?:[–-](\d+))?)?', label)
        if not m or not (REPO / m.group(1)).is_file():
            return match.group(0)
        anchor = f'#L{m.group(2)}' if m.group(2) else ''
        if m.group(3):
            anchor += '-L' + m.group(3)
        return f'[`{label}`]({REPO_URL}/blob/{SHA}/{m.group(1)}{anchor})'
    return re.sub(r'`([^`\n]+)`', replace, markdown)


def normalize_evidence_links(markdown, source_path):
    """Standalone HTML must not expose broken links to files inside the ZIP."""
    def replace(match):
        label, target = match.group(1), match.group(2)
        if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) or target.startswith('#'):
            return match.group(0)
        parts = target.split('#', 1)
        candidate = (source_path.parent / parts[0]).resolve()
        if candidate.is_file() and candidate.is_relative_to(REPO):
            suffix = '#' + parts[1] if len(parts) > 1 else ''
            return f'[{label}]({REPO_URL}/blob/{SHA}/{candidate.relative_to(REPO)}{suffix})'
        if candidate.is_file() and candidate.is_relative_to(ROOT):
            return f'{label}（证据包：`{candidate.relative_to(ROOT)}`）'
        return f'{label}（引用路径：`{target}`）'
    return re.sub(r'(?<!!)\[([^\]\n]+)\]\(([^)\s]+)\)', replace, markdown)


CSS = '''
<style>
:root { color-scheme: light; --ink:#172d35; --muted:#516970; --line:#dce6e7; --teal:#176b69; }
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { max-width: 1120px; margin:0 auto; padding:44px 42px 72px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; font-size:16px; line-height:1.8; color:var(--ink); background:#fff; }
header { border-top:7px solid var(--teal); border-bottom:1px solid var(--line); padding:24px 0 28px; margin-bottom:28px; }
header h1 { font-size:34px; line-height:1.4; margin:0 0 12px; border:0; padding:0; }
.date { color:var(--muted); font-size:14px; }
h1 { margin:50px 0 20px; padding-top:12px; font-size:27px; line-height:1.5; border-top:2px solid var(--line); scroll-margin-top:20px; }
h2 { margin:30px 0 12px; font-size:21px; line-height:1.6; }
h3 { font-size:18px; margin:22px 0 8px; }
h4 { font-size:17px; }
p { margin:13px 0; }
a { color:#125f79; text-decoration-thickness:1px; text-underline-offset:3px; overflow-wrap:anywhere; }
strong { color:#123e47; }
code { font-family:ui-monospace,SFMono-Regular,Consolas,monospace; font-size:.88em; padding:.1em .25em; background:#f1f5f6; border-radius:3px; overflow-wrap:anywhere; }
pre { padding:16px 18px; background:#f1f5f6; border:1px solid var(--line); border-radius:6px; overflow-x:auto; line-height:1.55; }
pre code { padding:0; font-size:13px; }
table { border-collapse:collapse; width:100%; margin:12px 0 20px; font-size:14px; line-height:1.65; }
th { background:#e9f2f2; color:#214c54; text-align:left; font-weight:650; }
th,td { padding:12px 13px; border:1px solid var(--line); vertical-align:top; min-width:95px; }
tr:nth-child(even) td { background:#f8fafb; }
.table-wrap { overflow-x:auto; margin:10px 0; }
#TOC { padding:18px 24px; background:#f4f8f8; border:1px solid var(--line); border-radius:7px; }
#TOC:before { content:"报告目录"; display:block; font-size:18px; font-weight:650; margin-bottom:10px; }
#TOC ul { margin:0; padding-left:21px; }
#TOC > ul { columns:2; column-gap:34px; }
#TOC li { break-inside:avoid; margin:4px 0; font-size:14px; }
blockquote { margin:18px 0; padding:8px 20px; border-left:4px solid var(--teal); background:#f4f8f8; }
li { margin:6px 0; }
footer { margin-top:48px; padding-top:18px; color:var(--muted); border-top:1px solid var(--line); font-size:13px; }
@media(max-width:720px) { body { padding:22px 18px 42px; font-size:15px; } header h1 { font-size:28px; } h1 {font-size:23px;} #TOC > ul { columns:1; } table {font-size:13px;} th,td {padding:9px;min-width:110px;} }
@media print { body { max-width:none; padding:0; font-size:10pt; } #TOC { break-after:page; } h1 { break-before:page; } h2,h3,h4 {break-after:avoid;} .table-wrap {overflow:visible;} th,td {min-width:0;padding:6px;font-size:9pt;} tr {break-inside:avoid;} a {color:inherit;} pre {white-space:pre-wrap;} }
</style>
'''


def render(markdown, title, target):
    style = EVIDENCE / 'root/report-style.html'
    style.write_text(CSS)
    command = ['pandoc', '-f', 'gfm', '-t', 'html5', '--standalone', '--toc', '--toc-depth=2',
               '--wrap=none', '--metadata', 'lang=zh-CN', '--metadata', 'title=' + title,
               '--metadata', 'date=检查期间：2026-10-08—10-09 UTC · 10月9日补查版 · 固定提交 a3fe96f · 线上部分受阻',
               '--include-in-header', str(style)]
    completed = subprocess.run(command, input=link_sources(markdown), text=True, capture_output=True, check=True)
    doc = lhtml.document_fromstring(completed.stdout)
    for table in doc.xpath('//table'):
        wrapper = lhtml.Element('div', {'class': 'table-wrap'})
        table.addprevious(wrapper)
        wrapper.append(table)
    footer = lhtml.Element('footer')
    footer.text = '羽球轮转助手 · 远端全面检查报告（10月9日补查版）· 18项主条目与1项P3观察分别计数。当前云实况仍未验证；报告完成不等于全项检查完成。'
    doc.find('body').append(footer)
    result = '<!DOCTYPE html>\n' + lhtml.tostring(doc, encoding='unicode', method='html')
    target.write_text(result)
    ids = doc.xpath('//*[@id]/@id')
    assert len(ids) == len(set(ids)), 'Duplicate section IDs'
    broken = [href for href in doc.xpath('//a/@href') if href.startswith('#') and href[1:] not in ids]
    assert not broken, broken
    assert not doc.xpath('//script'), 'No external scripts are needed for this report'
    assert not doc.xpath('//img'), 'This report does not depend on external images'
    relative = [href for href in doc.xpath('//a/@href') if not href.startswith('#') and not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', href)]
    assert not relative, relative
    return {'file': target.name, 'bytes': target.stat().st_size, 'sha256': digest(target),
            'headings': len(doc.xpath('//h1|//h2|//h3|//h4')), 'tables': len(doc.xpath('//table')),
            'links': len(doc.xpath('//a')), 'internalLinksValid': True, 'pandocStderr': completed.stderr}


def make_report():
    primary = EVIDENCE / 'root/audit-narrative.txt'
    text = normalize_evidence_links(primary.read_text(), primary)
    appendices = [
        ('A', '业务、身份与事务完整专项', 'business/report.md'),
        ('B', '排赛、比分与排名完整专项', 'fairness/report.md'),
        ('C', '使用留痕与资源效率完整专项', 'telemetry/report.md'),
        ('D', '页面、导航、权限与打包静态收口', 'telemetry/ui-config-coverage.md'),
        ('E', '10月9日远端补查、公共云依赖与访问缺口', 'remote-followup-20261009/root/report.md'),
        ('F', '部署、权限、索引与备份历史证据的20条对账', 'remote-followup-20261009/business/report.md'),
        ('G', '日志、留痕、资源和保留策略的补查', 'remote-followup-20261009/telemetry/report.md'),
        ('H', '独立范围完成度与证据审校', 'remote-followup-20261009/coverage/report.md'),
    ]
    for label, title, file in appendices:
        source_path = EVIDENCE / file
        source = normalize_evidence_links(source_path.read_text(), source_path).splitlines()
        shifted = []
        for line in source:
            if re.match(r'^#{1,5} ', line):
                line = '#' + line
            shifted.append(line)
        text += '\n\n# 附录 ' + label + '：' + title + '\n\n' + '\n'.join(shifted)
    text = text.replace(str(ROOT) + '/', 'AUDIT_ROOT/')
    return render(text, '羽球轮转助手｜远端全面检查汇总报告 · 10月9日补查版', OUT / REPORT_NAME)


README = '''# 阅读顺序

先打开本目录的 `badminton-audit-2026-10-08.html`；文件沿用首轮名称，内容已更新为10月9日补查版，包含主报告、历史12项对账和八份附录。`evidence/root/combined-findings.json` 为18个主审计条目及单独1项P3输入防护观察的结构化清单。`SHA256SUMS` 给出本包文件的完整性校验值。当前云实况仍未验证，报告交付不表示全项检查已完成。

# 固定源码

仓库为 LXZ56156/repo-20260224-031312，提交必须为 `a3fe96f25015892ac30ee7148f97a5b441b0cb24`。本包没有复制业务仓库；请使用你有权访问的固定检出，不要把复现改为调用生产云函数。

# 复现主要问题

本次运行使用 Node 24.19.0。先在终端进入本证据包解压目录，再设置实际仓库路径：

```bash
export AUDIT_REPO=/absolute/path/to/pinned/repository
node evidence/business/verify-business.cjs
node evidence/fairness/reproduce-findings.cjs
node evidence/telemetry/resource-probes.cjs
node evidence/telemetry/telemetry-probes.cjs
node evidence/telemetry/frontend-resource-probes.cjs
node evidence/root/profile-query-repro.cjs
python3 evidence/root/verify-fairness-witnesses.py
```

这些脚本使用合成数据，加载实际业务代码并替换云 SDK、平台出口或远端返回。返回 0 表示报告所述行为被成功复现，不表示缺陷已修复。脚本会更新各自的结果文件，因此复跑后与原 `SHA256SUMS` 的差异需按新运行记录解释；请保留原始解压副本用于对账。

事务探针使用本包 `evidence/business/sdk-inspection/runtime/` 的小型精确数据库 SDK 依赖集，不使用账户凭据；所有请求由本地捕获器接收。对应三个原始 npm 发布包、版本/哈希和许可证也在 sdk-inspection 中。可选通过 `AUDIT_DATABASE_SDK` 指向另一个已安装的 @cloudbase/database@1.4.1 路径。

两项参数可达性可另外运行 `node evidence/fairness/reachability-audit.cjs`，约数秒，涵盖真实创建/导入/设置/开赛代码，仍使用内存数据库。较完整搜索样例为 `runtime-audit.cjs`，时间预算与名单在文件内明确。

# 原始基线

`evidence/baseline/full-tests.log` 保存 1,777 项测试的原始 TAP；结果为 1,768 通过、7 失败、2 跳过。`baseline-analysis.json` 记录失败归因和针对性复核；check 与 lint 回执单独保存。完整全量复跑需要安装仓库依赖，Bash/tmp 前提和 WSL/Windows 专用环境应按报告区分。

本包没有保存业务仓库的 node_modules。只有 SDK 请求探针所需的小型依赖集被保留，便于无网络复核。当前 SDK runtime 的完整 package.json/package-lock.json 和许可证随包提供。

# 证据结构

| 目录 | 内容 |
|---|---|
| evidence/baseline | 固定清单、完整测试、运行环境、检查和主控复跑回执 |
| evidence/business | 五项业务问题、真实 SDK 请求序列、详细报告及复现 |
| evidence/fairness | 模板/参数/比分/排名验证、完整见证排程、质量反例及可达性 |
| evidence/telemetry | 两套留痕、指标矩阵、资源动作计数、UI/config 静态清单 |
| evidence/root | 主控独立重算、依赖公告数据、原12项对账、报告构建与最终完整性 |
| evidence/remote-followup-20261009 | 当前GitHub读取、云访问缺口、历史云证据20条、日志/资源矩阵、公共云依赖新锁、留存输入观察与独立范围审校 |

# 验证边界

本轮没有读取真实生产业务数据、部署、发布、迁移或操作用户设备。没有新的云部署/账单/事件实收回执。当前云检查因缺少已认证只读连接或原件而保留受阻；手机/原生门槛仅作为历史开发状态，不扩张本次远端范围。确认问题不以修复为检查完成前提；历史12项产品计划也不因报告完成而自动通过。

TEL-02是P3输入防护观察：真实CLI可接受合成旧快照与后移人工水位的矛盾组合，但未证明真实微信未成熟快照出现该key7=0格式。缺key7时仍unknown，整体window.status仍missing。主控缺key对照保留在followup/root/retention-independent-check.json，不将该观察当确定线上统计故障。

公共云依赖目录只保存依赖清单与锁、解析日志和扫描JSON。17项扫描影响不乘26，不与根工具链97项相加，也不代表已部署版本。首次锁未完成时的ENOLOCK回执原样保留；最终统计取有效锁后的扫描。
'''


def collect_files():
    result = []
    for directory in ['baseline', 'fairness', 'telemetry', 'root', 'remote-followup-20261009']:
        for path in (EVIDENCE / directory).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                result.append(path)
    business = EVIDENCE / 'business'
    result.extend(p for p in business.iterdir() if p.is_file())
    sdk = business / 'sdk-inspection'
    result.extend(p for p in sdk.iterdir() if p.is_file())
    result.extend(p for p in (sdk / 'runtime').rglob('*') if p.is_file())
    selected_sources = {
        'wx-server-sdk-2.6.3/package': ['index.js', 'package.json', 'LICENSE'],
        'cloudbase-node-sdk-2.9.1/package': ['lib/utils/dbRequest.js', 'lib/cloudbase.js', 'package.json', 'LICENSE'],
        'cloudbase-database-1.4.1/package': ['src/query.ts', 'src/document.ts', 'src/collection.ts', 'src/transaction/index.ts', 'src/index.ts', 'package.json', 'LICENSE'],
    }
    for prefix, files in selected_sources.items():
        result.extend(sdk / prefix / file for file in files if (sdk / prefix / file).is_file())
    return sorted(set(result))


def make_archive(paths):
    mapping = {str(path.relative_to(ROOT)): path for path in paths}
    mapping[REPORT_NAME] = OUT / REPORT_NAME
    mapping['README.html'] = OUT / 'README.html'
    checksum_lines = [f'{digest(path)}  {relative}' for relative, path in sorted(mapping.items())]
    checksums = '\n'.join(checksum_lines) + '\n'
    target = OUT / ZIP_NAME
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative, path in sorted(mapping.items()):
            assert not relative.startswith('/') and '..' not in Path(relative).parts
            assert path.is_file() and not path.is_symlink(), str(path)
            info = zipfile.ZipInfo(relative, (2026, 10, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o100644 << 16)
            archive.writestr(info, path.read_bytes())
        archive.writestr('SHA256SUMS', checksums)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for relative, path in mapping.items():
            assert hashlib.sha256(archive.read(relative)).hexdigest() == digest(path), relative
        assert archive.read('SHA256SUMS').decode() == checksums
    return {'file': target.name, 'bytes': target.stat().st_size, 'sha256': digest(target),
            'files': len(mapping) + 1, 'membersHashVerified': len(mapping), 'zipCrcVerified': True}


def main():
    integrity = check_source()
    findings = combine_findings()
    report = make_report()
    readme = render(README, '远端检查证据包｜使用说明', OUT / 'README.html')
    assert all((OUT / REPORT_NAME).read_text().count(row['id']) for row in findings)
    assert 'TEL-02' in (OUT / REPORT_NAME).read_text()
    write_json(EVIDENCE / 'root/report-build-results.json', {
        'report': report, 'readme': readme, 'sourceIntegrity': integrity,
        'entryIdsVerified': [row['id'] for row in findings],
        'reportSources': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in
            [EVIDENCE / 'root/audit-narrative.txt', EVIDENCE / 'business/report.md',
             EVIDENCE / 'fairness/report.md', EVIDENCE / 'telemetry/report.md',
             EVIDENCE / 'telemetry/ui-config-coverage.md',
             EVIDENCE / 'remote-followup-20261009/root/report.md',
             EVIDENCE / 'remote-followup-20261009/business/report.md',
             EVIDENCE / 'remote-followup-20261009/telemetry/report.md',
             EVIDENCE / 'remote-followup-20261009/coverage/report.md']],
    })
    paths = collect_files()
    archive = make_archive(paths)
    receipt = {'report': report, 'archive': archive,
               'trackedSourceUnchanged': integrity['verified'],
               'deliveryComplete': True,
               'fullAuditComplete': False,
               'reason': 'Current cloud deployment, rules/indexes, usage/billing, event reception and raw backup/restore evidence remain blocked/unverified.'}
    write_json(OUT / 'delivery-receipt.json', receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
