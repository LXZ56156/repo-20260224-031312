'use strict';
// Invoke the unchanged page initialization with malformed synthetic query values.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const repo = path.resolve(process.env.AUDIT_REPO || path.join(__dirname, '../../repo'));
let page;
global.Page = value => { page = value; };
global.wx = {};
require(path.join(repo, 'miniprogram/pages/profile/index.js'));
(async () => {
  const results = [];
  for (const returnUrl of ['%', '%E0%A4%A']) {
    let setDataCount = 0;
    const ctx = { setData() { setDataCount += 1; } };
    await assert.rejects(page.onLoad.call(ctx, { returnUrl }), URIError);
    assert.equal(setDataCount, 0);
    results.push({ returnUrl, error: 'URIError', setDataCount });
  }
  const result = { id: 'UI-01', method: 'Actual profile onLoad; synthetic options, no device or network', results };
  fs.writeFileSync(path.join(__dirname, 'profile-query-results.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
})().catch(error => { console.error(error); process.exitCode = 1; });
