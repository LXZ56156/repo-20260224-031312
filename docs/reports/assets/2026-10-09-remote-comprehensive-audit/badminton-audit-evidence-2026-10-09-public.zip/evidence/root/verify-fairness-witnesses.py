#!/usr/bin/env python3
"""Independent Python recount of the unchanged scheduler's captured witnesses."""
import collections
import hashlib
import itertools
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / 'fairness' / 'quality-counterexamples.json'
data = json.loads(SOURCE.read_text())


def identifier(value):
    return str(value['id']) if isinstance(value, dict) else str(value)


def recount(rounds, players, squads=False):
    partner, opponent, matches = collections.Counter(), collections.Counter(), collections.Counter()
    appearances = dict.fromkeys(players, 0)
    playing = {p: [] for p in players}
    indices = set()
    for round_doc in rounds:
        used = set()
        for match in round_doc['matches']:
            a, b = [tuple(map(identifier, match[k])) for k in ('teamA', 'teamB')]
            assert len(a) == len(b) == 2
            assert len(set(a + b)) == 4
            assert set(a + b) <= set(players)
            assert not used.intersection(a + b), 'A player is assigned twice within one batch'
            used.update(a + b)
            assert match['matchIndex'] not in indices
            indices.add(match['matchIndex'])
            if squads:
                assert all(p.startswith('A') for p in a)
                assert all(p.startswith('B') for p in b)
            partner[tuple(sorted(a))] += 1
            partner[tuple(sorted(b))] += 1
            for x, y in itertools.product(a, b):
                opponent[tuple(sorted((x, y)))] += 1
            matches[tuple(sorted((tuple(sorted(a)), tuple(sorted(b)))))] += 1
            for p in a + b:
                appearances[p] += 1
        assert set(map(identifier, round_doc['restPlayers'])) == set(players) - used
        for p in players:
            playing[p].append(p in used)

    def streak(target):
        return max((len(list(g)) for sequence in playing.values()
                    for value, g in itertools.groupby(sequence) if value is target), default=0)

    return {
        'matches': sum(matches.values()), 'batches': len(rounds),
        'appearances': appearances,
        'playSpread': max(appearances.values()) - min(appearances.values()),
        'partnerPairs': len(partner), 'opponentPairs': len(opponent),
        'partnerRepeats': sum(partner.values()) - len(partner),
        'opponentRepeats': sum(opponent.values()) - len(opponent),
        'exactMatches': len(matches),
        'maxConsecutivePlay': streak(True), 'maxConsecutiveRest': streak(False),
    }


rotation = data['rotationBoundary']
players8 = [f'P{i:02}' for i in range(1, 9)]
rotation_counts = {key: recount(rotation[key]['rounds'], players8)
                   for key in ('template16', 'actual17', 'reference17')}
actual, reference = rotation_counts['actual17'], rotation_counts['reference17']
assert actual['matches'] == reference['matches'] == 17
assert actual['partnerPairs'] == actual['opponentPairs'] == 12
assert reference['partnerPairs'] == reference['opponentPairs'] == 28
assert actual['exactMatches'] == 6 and reference['exactMatches'] == 17
assert actual['playSpread'] == reference['playSpread'] == 1
assert actual['maxConsecutivePlay'] == 1 and reference['maxConsecutivePlay'] == 2

squad = data['squadFallback']
players22 = [f'A{i:02}' for i in range(1, 13)] + [f'B{i:02}' for i in range(1, 11)]
squad_counts = {key: recount(squad[key]['rounds'], players22, squads=True)
                for key in ('actual', 'reference')}
actual, reference = squad_counts['actual'], squad_counts['reference']
assert actual['matches'] == reference['matches'] == 24
assert {v for k, v in actual['appearances'].items() if k.startswith('A')} == {3, 4, 5}
assert {v for k, v in reference['appearances'].items() if k.startswith('A')} == {4}
for key in ('partnerRepeats', 'opponentRepeats', 'maxConsecutivePlay', 'maxConsecutiveRest'):
    assert reference[key] <= actual[key], key
assert reference['opponentRepeats'] == 10 < actual['opponentRepeats'] == 11
assert actual['exactMatches'] == reference['exactMatches'] == 24

report = {
    'commit': data['commit'],
    'method': 'Independent Python metrics; no production/agent statistics function imported',
    'sourceSha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'result': 'passed',
    'rotationBoundary': rotation_counts,
    'squadFallback': squad_counts,
    'limits': 'Recounts captured legal witnesses. Timings and live cloud execution are not measured. Rotation alternative trades maximum consecutive play from 1 to 2.',
}
output = Path(__file__).with_name('fairness-independent-recount.json')
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': 'passed', 'output': str(output)}, ensure_ascii=False))
