'use strict';
// Exactly the two reported parameter sets. All state and SDK traffic stay in memory.
// Real source handlers and generators execute; only SDK, transport and visual effects are mocked.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const Module = require('node:module');
const { ROOT, load } = require('./independent-audit.cjs');
const fixture = load('tests/helpers/tournament-cloud-fixture.js');
const viewModel = load('miniprogram/pages/settings/settingsViewModel.js');
const readiness = load('miniprogram/core/draftStartReadiness.js');
const startLogic = load('cloudfunctions/startTournament/logic.js');
const templateEngine = load('cloudfunctions/startTournament/rotationDoublesEngine.js');
const startPath = path.join(ROOT, 'cloudfunctions/startTournament/index.js');
const actionsPath = path.join(ROOT, 'miniprogram/pages/settings/settingsActions.js');
const clone = value => structuredClone(value);
const output = [];

async function run(scenario) {
  const db = fixture.createDb({});
  const algorithmCalls = [];
  const payloads = [];
  const consoleMessages = [];
  const savedLoad = Module._load;
  const savedInfo = console.info;
  const savedWx = global.wx;
  console.info = (...args) => consoleMessages.push(args);
  global.wx = { showToast() {}, showLoading() {}, hideLoading() {} };
  let handlers;
  try {
    Module._load = function(request, parent, main) {
      const result = savedLoad.call(this, request, parent, main);
      if (parent && parent.filename === startPath && request === './rotation') {
        return { ...result, generateSchedule(players, totalMatches, courts, options) {
          algorithmCalls.push({ name: 'generateSchedule', players: players.length, totalMatches, courts,
            runtimeBudgetMs: options.runtimeBudgetMs, seedProvided: Object.hasOwn(options, 'seed') });
          return result.generateSchedule(players, totalMatches, courts, options);
        } };
      }
      if (parent && parent.filename === startPath && request === './scheduleModes') {
        return { ...result, buildSquadSchedule(players, totalMatches, courts, rules) {
          algorithmCalls.push({ name: 'buildSquadSchedule', players: players.length,
            squadA: players.filter(p => p.squad === 'A').length, squadB: players.filter(p => p.squad === 'B').length,
            totalMatches, courts, rules: clone(rules) });
          return result.buildSquadSchedule(players, totalMatches, courts, rules);
        } };
      }
      return result;
    };
    handlers = fixture.load(db, { openid: 'audit_owner' },
      ['createTournament', 'addPlayers', 'setPlayerSquad', 'updateSettings', 'startTournament']);
    Module._load = savedLoad;
    const created = await handlers.createTournament({ name: 'Parameter reachability audit', mode: scenario.mode,
      presetKey: '', nickname: 'P01', creatorGender: 'unknown' });
    assert.equal(created.ok, true, JSON.stringify(created));
    const tournamentId = created.tournamentId;
    const read = async () => (await db.collection('tournaments').doc(tournamentId).get()).data;
    const initial = await read();
    assert.equal(initial.mode, scenario.mode);
    assert.equal(initial.presetKey, 'custom');
    assert.equal(initial.totalMatches, 0);
    const imported = await handlers.addPlayers({ tournamentId,
      names: Array.from({ length: scenario.players - 1 }, (_, i) => `P${String(i + 2).padStart(2, '0')}`) });
    assert.equal(imported.ok, true, JSON.stringify(imported));
    assert.equal((await read()).players.length, scenario.players);
    let squadChanges = 0;
    if (scenario.mode === 'squad_doubles') {
      for (const [index, player] of (await read()).players.entries()) {
        const result = await handlers.setPlayerSquad({ tournamentId, playerId: player.id,
          squad: index < 12 ? 'A' : 'B' });
        assert.equal(result.ok, true, JSON.stringify(result));
        squadChanges++;
      }
    }
    Module._load = function(request, parent, main) {
      const result = savedLoad.call(this, request, parent, main);
      if (!parent || parent.filename !== actionsPath) return result;
      if (request === '../../core/cloud') return { ...result, async call(name, payload) {
        assert.equal(name, 'updateSettings');
        payloads.push(clone(payload));
        return handlers.updateSettings(payload);
      } };
      if (request === '../../core/actionGuard') return { isBusy: () => false,
        runWithCriticalPageBusy: async (page, busyKey, actionKey, callback) => callback() };
      if (request === '../../core/nav') return { markRefreshFlag() {}, setLobbyIntent() {} };
      return result;
    };
    delete require.cache[actionsPath];
    const actions = require(actionsPath);
    Module._load = savedLoad;
    const page = {
      ...actions,
      data: { tournamentId, ...viewModel.buildSettingsViewState(await read(), { openid: 'audit_owner' }) },
      setData(patch, callback) { Object.assign(this.data, patch); if (callback) callback(); },
      clearLastFailedAction() {},
      async fetchTournament() { this.setData(viewModel.buildSettingsViewState(await read(), { openid: 'audit_owner' })); },
      hasUnsavedSettingsDraft: () => true, // Prevent navigation timer; does not affect validation or saving.
      handleWriteError(error) { throw error; }
    };
    assert.equal(page.data.canManageTournament, true);
    assert.equal(page.data.canConfigureSettings, true);
    assert.equal(page.data.maxMatches, scenario.expectedMaxMatches);
    assert(page.data.courtOptions.includes(scenario.courts));
    page.onPickCourts({ detail: { value: page.data.courtOptions.indexOf(scenario.courts) } });
    if (scenario.mode === 'multi_rotate') {
      assert.equal(page.data.showAdvancedMatchEntry, true);
      page.toggleAdvancedMatchPicker();
      assert.equal(page.data.showAdvancedMatchPicker, true);
    }
    assert.equal(page.data.useSimpleMPicker, false);
    const digits = viewModel.valueToDigitValue(scenario.totalMatches, page.data.mDigitRange.length);
    page.onPickTotalMatches({ detail: { value: digits } });
    assert.equal(page.data.editM, scenario.totalMatches);
    assert.equal(page.data.editC, scenario.courts);
    assert.equal(page.data.endConditionType, 'total_matches');
    const pickerState = { maxMatches: page.data.maxMatches, digits,
      advancedEntry: page.data.showAdvancedMatchEntry, advancedPicker: page.data.showAdvancedMatchPicker,
      currentCustomMatchLabel: page.data.currentCustomMatchLabel, totalMatches: page.data.editM, courts: page.data.editC };
    await page.saveSettings({ clientRequestId: `audit_reachability_${scenario.id}` });
    assert.equal(payloads.length, 1);
    assert.equal(payloads[0].totalMatches, scenario.totalMatches);
    assert.equal(payloads[0].courts, scenario.courts);
    const saved = await read();
    assert.equal(saved.totalMatches, scenario.totalMatches);
    assert.equal(saved.courts, scenario.courts);
    assert.equal(saved.rules.endCondition.target, scenario.totalMatches);
    assert.equal(saved.settingsConfigured, true);
    assert.equal(page.data.editM, scenario.totalMatches, 'Reopening saved form must preserve the custom value');
    const ready = readiness.buildDraftStartReadiness(saved);
    assert.equal(ready.checkStartReady, true);
    const checked = startLogic.validateBeforeGenerate(saved);
    assert.equal(checked.totalMatches, scenario.totalMatches);
    assert.equal(checked.scheduledMatches, scenario.totalMatches);
    assert.equal(checked.courts, scenario.courts);
    if (scenario.mode === 'multi_rotate') assert.equal(templateEngine.findTemplateCase(8, 1, 17), null);
    const started = await handlers.startTournament({ tournamentId, schedulerProfile: 'rest' });
    assert.equal(started.ok, true, JSON.stringify(started));
    const final = await read();
    const count = final.rounds.reduce((sum, round) => sum + round.matches.length, 0);
    assert.equal(count, scenario.totalMatches);
    assert.equal(final.scheduledMatches, scenario.totalMatches);
    assert.equal(final.totalMatches, scenario.totalMatches);
    assert.equal(algorithmCalls.length, 1);
    assert.equal(algorithmCalls[0].totalMatches, scenario.totalMatches);
    assert.equal(algorithmCalls[0].courts, scenario.courts);
    const meta = JSON.parse(final.schedulerMetaJson);
    if (scenario.mode === 'multi_rotate') assert.notEqual(meta.engine, 'template');
    output.push({ id: scenario.id, parameters: scenario, create: { code: created.code, mode: initial.mode,
      presetKey: initial.presetKey, totalMatches: initial.totalMatches, playerLimit: initial.playerLimit || null },
      roster: { importedCount: imported.addedCount, squadChanges, ...ready }, pickerState,
      settingsPayload: payloads[0], persisted: { totalMatches: saved.totalMatches, courts: saved.courts,
        settingsConfigured: saved.settingsConfigured, endCondition: saved.rules.endCondition },
      checked: { totalMatches: checked.totalMatches, scheduledMatches: checked.scheduledMatches,
        courts: checked.courts, maxMatches: checked.maxMatches }, algorithmCalls,
      final: { code: started.code, status: final.status, totalMatches: final.totalMatches,
        scheduledMatches: final.scheduledMatches, count, engine: meta.engine, executionProfile: meta.executionProfile,
        effectiveCourts: meta.effectiveCourts, templateKey: meta.templateKey || '' },
      timing: consoleMessages.filter(args => args[0] === '[startTournament:timing]').map(args => JSON.parse(args[1])) });
  } finally {
    Module._load = savedLoad;
    console.info = savedInfo;
    global.wx = savedWx;
    delete require.cache[actionsPath];
  }
}

(async () => {
  await run({ id: 'FA-01', mode: 'multi_rotate', players: 8, courts: 1, totalMatches: 17, expectedMaxMatches: 210 });
  await run({ id: 'FA-02', mode: 'squad_doubles', players: 22, courts: 5, totalMatches: 24, expectedMaxMatches: 21945 });
  const result = { sourceRoot: ROOT, scope: 'Two parameter reachability checks only; no production access',
    method: 'Real create/import/squad assignment/settings/start handlers plus real settings picker/save and real algorithms; in-memory DB and SDK/transport/visual-effect mocks',
    seedBoundary: 'This verifies actual cloud routing without altering its seed or budget; seeded quality witnesses remain in separate artifacts.',
    cases: output };
  fs.writeFileSync(path.join(__dirname, 'reachability-results.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ cases: output.map(item => ({ id: item.id, uiMaxMatches: item.pickerState.maxMatches,
    savedMatches: item.persisted.totalMatches, savedCourts: item.persisted.courts,
    canStart: item.roster.checkStartReady, algorithm: item.algorithmCalls[0].name,
    actualMatches: item.final.count, engine: item.final.engine, executionProfile: item.final.executionProfile })),
    result: 'Both parameter sets are reachable and remain unchanged through the real source entry points.' }, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
