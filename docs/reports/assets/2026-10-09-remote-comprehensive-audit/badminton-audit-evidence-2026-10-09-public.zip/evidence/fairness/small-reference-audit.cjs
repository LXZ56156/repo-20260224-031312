'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {load,roster,collect}=require('./independent-audit.cjs');
const {buildSquadSchedule}=load('cloudfunctions/startTournament/scheduleModes.js');
const players=roster(4,'A').map(p=>({...p,squad:'A'})).concat(roster(4,'B').map(p=>({...p,squad:'B'})));
const pairs=[];for(let i=0;i<4;i++)for(let j=i+1;j<4;j++)pairs.push([i,j]);
const matches=[];for(let a=0;a<pairs.length;a++)for(let b=0;b<pairs.length;b++)matches.push({a,b,aa:pairs[a],bb:pairs[b]});
const byMetric=new Map();let examined=0,balanced=0;
for(let i=0;i<36;i++)for(let j=0;j<36;j++)for(let k=0;k<36;k++) {
  examined++;
  const chosen=[matches[i],matches[j],matches[k]],play=Array(8).fill(0),partner=Array(12).fill(0),opponent=Array(16).fill(0),streak=Array(8).fill(0);
  let maxConsecutivePlay=0;
  for(const m of chosen) {
    const active=new Set(m.aa.concat(m.bb.map(b=>b+4)));
    for(const id of active)play[id]++;
    partner[m.a]++;partner[6+m.b]++;
    for(const a of m.aa)for(const b of m.bb)opponent[a*4+b]++;
    for(let x=0;x<8;x++){streak[x]=active.has(x)?streak[x]+1:0;maxConsecutivePlay=Math.max(maxConsecutivePlay,streak[x]);}
  }
  const playSpread=Math.max(...play)-Math.min(...play);
  if(playSpread!==1)continue;balanced++;
  const partnerRepeats=partner.reduce((s,c)=>s+Math.max(0,c-1),0),opponentRepeats=opponent.reduce((s,c)=>s+Math.max(0,c-1),0);
  const key=`${partnerRepeats},${opponentRepeats},${maxConsecutivePlay}`;
  if(!byMetric.has(key))byMetric.set(key,{partnerRepeats,opponentRepeats,maxConsecutivePlay,witness:[i,j,k]});
}
const entries=[...byMetric.values()];
const pareto=entries.filter(a=>!entries.some(b=>b.partnerRepeats<=a.partnerRepeats&&b.opponentRepeats<=a.opponentRepeats&&b.maxConsecutivePlay<=a.maxConsecutivePlay&&(b.partnerRepeats<a.partnerRepeats||b.opponentRepeats<a.opponentRepeats||b.maxConsecutivePlay<a.maxConsecutivePlay)));
const actual=collect(buildSquadSchedule(players,3,1,{endCondition:{type:'total_matches',target:3}}),players);
assert(pareto.some(p=>p.partnerRepeats===actual.partnerRepeats&&p.opponentRepeats===actual.opponentRepeats&&p.maxConsecutivePlay===actual.maxConsecutivePlay));
const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',scenario:'squad 4v4, 1 court, 3 matches',examined,balanced,pareto,actual:{partnerRepeats:actual.partnerRepeats,opponentRepeats:actual.opponentRepeats,maxConsecutivePlay:actual.maxConsecutivePlay},conclusion:'The actual small schedule lies on the exhaustively enumerated Pareto frontier. Its one opponent repeat cannot be removed while keeping zero partner repeats and the same play-count balance.'};
fs.writeFileSync(path.join(__dirname,'small-reference-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
