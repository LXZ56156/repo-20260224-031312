'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {load,roster,collect}=require('./independent-audit.cjs');
const {buildSquadSchedule}=load('cloudfunctions/startTournament/scheduleModes.js');
const rotation=load('cloudfunctions/startTournament/rotation.js');
const runtime=JSON.parse(fs.readFileSync(path.join(__dirname,'runtime-results.json'),'utf8'));
function refreshRest(rounds,players){for(const r of rounds){const active=new Set(r.matches.flatMap(m=>m.teamA.concat(m.teamB)));r.restPlayers=players.map(p=>p.id).filter(id=>!active.has(id));}return rounds;}
function summarize(m){return Object.fromEntries(['count','batches','play','playSpread','maxConsecutivePlay','partnerPairs','opponentPairs','partnerRepeats','opponentRepeats','exactMatches'].map(k=>[k,m[k]]));}
const players8=roster(8),template16=rotation.generateSchedule(players8,16,1,{seed:1});
const m16=collect(template16,players8),actual17=runtime.cases.find(r=>r.scenario.mode==='multi_rotate'&&r.scenario.n===8&&r.scenario.courts===1&&r.scenario.target===17);
assert(actual17);
const originalRounds=template16.rounds,refs=[];
for(let a=0;a<8;a++)for(let b=a+1;b<8;b++)for(let c=b+1;c<8;c++)for(let d=c+1;d<8;d++){
  for(const four of [[a,b,c,d],[a,c,b,d],[a,d,b,c]]){
    const rounds=structuredClone(originalRounds);
    rounds.push({roundIndex:16,matches:[{matchIndex:16,teamA:four.slice(0,2).map(i=>players8[i].id),teamB:four.slice(2).map(i=>players8[i].id),status:'pending'}]});
    refreshRest(rounds,players8);
    const m=collect({rounds},players8);
    if(m.exactMatches===17&&m.maxConsecutivePlay<=2)refs.push({rounds,metrics:summarize(m)});
  }
}
assert(refs.length>0);const reference17=refs[0];assert.equal(reference17.metrics.partnerPairs,28);assert.equal(reference17.metrics.opponentPairs,28);
const p=roster(12,'A').map(p=>({...p,squad:'A'})).concat(roster(10,'B').map(p=>({...p,squad:'B'})));
const fallback=buildSquadSchedule(p,24,5,{endCondition:{type:'total_matches',target:24},_debugForceFallback:true});
const actualFallbackMetrics=collect(fallback,p);
const capturedFallback=runtime.cases.find(r=>r.scenario.mode==='squad_doubles'&&r.scenario.a===12&&r.scenario.b===10);
assert.deepEqual(fallback.rounds,capturedFallback.rounds,'forced path must reproduce naturally timed-out fallback exactly');
const candidates=[];
for(const changeRound of [0,4]){
  const base=structuredClone(fallback.rounds);
  const match=base[changeRound].matches.find(m=>m.teamA.includes('A01'));
  match.teamA[match.teamA.indexOf('A01')]='A12';
  for(let rr=0;rr<base.length;rr++){
    const coordinates=base[rr].matches.flatMap((m,mi)=>m.teamA.map((id,pi)=>({mi,pi,id})));
    for(let i=0;i<coordinates.length;i++)for(let j=i+1;j<coordinates.length;j++){
      if(coordinates[i].mi===coordinates[j].mi)continue;
      const rounds=structuredClone(base),x=coordinates[i],y=coordinates[j];
      rounds[rr].matches[x.mi].teamA[x.pi]=y.id;rounds[rr].matches[y.mi].teamA[y.pi]=x.id;
      refreshRest(rounds,p);const m=collect({rounds},p);
      if(m.playSpread<=1&&m.partnerRepeats<=actualFallbackMetrics.partnerRepeats&&m.opponentRepeats<=actualFallbackMetrics.opponentRepeats&&m.maxConsecutivePlay<=actualFallbackMetrics.maxConsecutivePlay&&m.exactMatches>=actualFallbackMetrics.exactMatches)candidates.push({changeRound,swapRound:rr,swap:[x,y],rounds,metrics:summarize(m)});
    }
  }
}
candidates.sort((a,b)=>a.metrics.partnerRepeats-b.metrics.partnerRepeats||a.metrics.opponentRepeats-b.metrics.opponentRepeats);
const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',rotationBoundary:{parameters:{players:8,courts:1},template16:{rounds:template16.rounds,metrics:summarize(m16)},actual17:{rounds:actual17.rounds,metrics:actual17.metrics,seed:1,scheduleHash:actual17.scheduleHash},reference17,validReferenceCount:refs.length,classification:'Verified quality discontinuity at template boundary; legal schedule, but current rest-first priority sacrifices both partner/opponent coverage and repeats exact matches.'},squadFallback:{parameters:{a:12,b:10,courts:5,matches:24},actual:{rounds:fallback.rounds,metrics:summarize(actualFallbackMetrics)},strictImprovementsFound:candidates.length,reference:candidates[0]||null,classification:candidates.length?'Verified avoidable quality defect: corrected appearances improve, with no loss of partner diversity, opponent diversity, exact-match diversity or maximum consecutive-play metric.':'Avoidable play-count imbalance; simultaneous repetition/continuity tradeoff not yet resolved.'}};
fs.writeFileSync(path.join(__dirname,'quality-counterexamples.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({rotation16:result.rotationBoundary.template16.metrics,rotationActual17:result.rotationBoundary.actual17.metrics,rotationReference17:reference17.metrics,squadActual:result.squadFallback.actual.metrics,squadReference:result.squadFallback.reference?.metrics,strictSquadImprovements:candidates.length},null,2));
