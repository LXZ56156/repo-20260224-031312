'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {load,roster,referenceRankings}=require('./independent-audit.cjs');
const {buildSinglesSchedule}=load('cloudfunctions/startTournament/singlesRoundRobinV1.js');
const {validateBeforeGenerate}=load('cloudfunctions/startTournament/logic.js');
const {buildSubmitResult}=load('cloudfunctions/submitScore/logic.js');
const {buildManualFinish}=load('cloudfunctions/finishTournament/logic.js');
const {buildResetTournamentPatch}=load('cloudfunctions/resetTournament/logic.js');
const clientRanking=load('miniprogram/core/rankingCore.js');
const cloudScore=load('cloudfunctions/submitScore/lib/score.js');
const mode='singles_round_robin';
const summary=[];let writes=0,assertedRankStates=0;
function expected(t){return referenceRankings({...t,rounds:t.rounds.map(r=>({...r,matches:r.matches.map(m=>({...m,scoreA:m.score?.teamA,scoreB:m.score?.teamB}))}))});}
function checkRanking(t){const e=expected(t);assert.deepEqual(t.rankings,e);assert.deepEqual(clientRanking.computeRankings(t),e);assertedRankStates++;}
for(const n of [2,3,4,6,8])for(const courts of [1,2])for(const cycles of [1,2])for(const target of [11,15,21]){
  let t={mode,players:roster(n),rules:{cycles,pointsPerGame:target},courts,totalMatches:999,status:'draft',pairTeams:[]};
  const checked=validateBeforeGenerate(t);assert.equal(checked.totalMatches,n*(n-1)/2*cycles);
  t={...t,status:'running',rules:checked.rules,totalMatches:checked.totalMatches,...buildSinglesSchedule(t.players,courts,{cycles})};
  t.rounds=t.rounds.map(r=>({...r,matches:r.matches.map(m=>({...m,status:'pending'}))}));
  const coordinates=t.rounds.flatMap(r=>r.matches.map(m=>({round:r.roundIndex,match:m.matchIndex})));
  const partialCount=Math.max(1,Math.floor(coordinates.length/2));
  for(let i=0;i<coordinates.length;i++){
    const c=coordinates[i],a=i%2?0:target,b=i%2?target:0;
    assert(cloudScore.isValidFinishedScore({scoreA:a,scoreB:b},t));
    const out=buildSubmitResult(t,c.round,c.match,a,b);writes++;
    t={...t,rounds:out.rounds,rankings:out.rankings,status:out.nextStatus};checkRanking(t);
    assert.equal(out.finished,i===coordinates.length-1);
    if(i+1===partialCount){
      const first=coordinates[0],corrected=buildSubmitResult(t,first.round,first.match,0,target);writes++;
      t={...t,rounds:corrected.rounds,rankings:corrected.rankings,status:corrected.nextStatus};checkRanking(t);
      const finished=buildManualFinish(t);assert.equal(finished.completedMatches,partialCount);assert.equal(finished.canceledMatches,coordinates.length-partialCount);
      assert.deepEqual(finished.rankings,t.rankings);
      assert.equal(finished.rankings.reduce((s,r)=>s+r.played,0),partialCount*2);
      assert(finished.rounds.flatMap(r=>r.matches).filter(m=>m.status==='canceled').every(m=>!m.score));
    }
  }
  assert(t.rankings.every(r=>r.played===(n-1)*cycles));
  assert.equal(t.rankings.reduce((s,r)=>s+r.wins,0),coordinates.length);
  assert.equal(t.rankings.reduce((s,r)=>s+r.pointDiff,0),0);
  const reset=buildResetTournamentPatch(t);assert.equal(reset.status,'draft');assert.deepEqual(reset.rounds,[]);assert(reset.rankings.every(r=>r.played===0&&r.wins===0&&r.losses===0&&r.pointsFor===0));
  summary.push({n,courts,cycles,target,matches:coordinates.length,partialCount,stages:['generate','partial scores','correction','manual-finish branch','all scores','reset']});
}
assert.throws(()=>buildSinglesSchedule(roster(8),2,{cycles:2,deadlineAtMs:Date.now()-1}),{code:'START_TIMEOUT'});
const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',workflowCases:summary.length,scoreWrites:writes,independentRankStates:assertedRankStates,expiredDeadline:'rejected with START_TIMEOUT',cases:summary};
fs.writeFileSync(path.join(__dirname,'singles-lifecycle-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({workflowCases:summary.length,scoreWrites:writes,independentRankStates:assertedRankStates,expiredDeadline:result.expiredDeadline},null,2));
