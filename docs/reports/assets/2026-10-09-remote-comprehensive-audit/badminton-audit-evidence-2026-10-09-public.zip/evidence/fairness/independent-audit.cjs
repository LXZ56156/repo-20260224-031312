'use strict';
// Offline audit only. Loads the pinned checkout; never imports a cloud handler/SDK.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const ROOT = path.resolve(process.env.AUDIT_REPO || path.resolve(__dirname, '../../repo'));
const load = (p) => require(path.join(ROOT, p));
const { buildSinglesSchedule } = load('cloudfunctions/startTournament/singlesRoundRobinV1.js');
const { buildFixedPairSchedule, buildSquadSchedule } = load('cloudfunctions/startTournament/scheduleModes.js');
const scores = [load('miniprogram/core/scoreUtils.js'), load('cloudfunctions/submitScore/lib/score.js')];
const ranks = [load('miniprogram/core/rankingCore.js'), load('cloudfunctions/submitScore/lib/rankingCore.js')];
const idOf = (p) => typeof p === 'string' ? p : String(p.id || p.playerId || p._id || '');
const pairKey = (a, b) => JSON.stringify([a, b].sort());
const bump = (map, key) => map.set(key, (map.get(key) || 0) + 1);
function roster(n, prefix = 'P') {
  return Array.from({ length: n }, (_, i) => ({ id: `${prefix}${String(i + 1).padStart(2, '0')}`, name: `球友${i + 1}` }));
}
function fixedRoster(n) {
  const players = roster(n * 2);
  const pairTeams = Array.from({ length: n }, (_, i) => ({ id: `T${String(i + 1).padStart(2, '0')}`, name: `队${i + 1}`, playerIds: players.slice(i * 2, i * 2 + 2).map(idOf) }));
  return { players, pairTeams };
}
function collect(out, players, teamSize = 2) {
  const ids = players.map(idOf), allowed = new Set(ids);
  const play = Object.fromEntries(ids.map(id => [id, 0]));
  const currentStreak = Object.fromEntries(ids.map(id => [id, 0]));
  const partners = new Map(), opponents = new Map(), exact = new Set(), coordinates = new Set();
  const restMismatches = [];
  let count = 0, maxConsecutivePlay = 0;
  const seenRoundIndexes = new Set();
  for (const round of out.rounds) {
    assert(!seenRoundIndexes.has(round.roundIndex), 'duplicate round index');
    seenRoundIndexes.add(round.roundIndex);
    const active = new Set();
    for (const match of round.matches) {
      const a = match.teamA.map(idOf), b = match.teamB.map(idOf);
      assert.equal(a.length, teamSize); assert.equal(b.length, teamSize);
      assert.equal(new Set(a.concat(b)).size, teamSize * 2, 'duplicate player in match');
      for (const id of a.concat(b)) {
        assert(allowed.has(id), `unknown player ${id}`);
        assert(!active.has(id), `player ${id} booked twice in batch`);
        active.add(id); play[id]++;
      }
      const c = `${round.roundIndex}/${match.matchIndex}`;
      assert(!coordinates.has(c), 'duplicate match coordinate'); coordinates.add(c);
      if (teamSize === 2) { bump(partners, pairKey(...a)); bump(partners, pairKey(...b)); }
      for (const x of a) for (const y of b) bump(opponents, pairKey(x, y));
      exact.add(JSON.stringify([a.slice().sort(), b.slice().sort()].sort((x, y) => JSON.stringify(x).localeCompare(JSON.stringify(y)))));
      count++;
    }
    const actualRest = (round.restPlayers || []).map(idOf).sort();
    const expectedRest = ids.filter(id => !active.has(id)).sort();
    if (JSON.stringify(actualRest) !== JSON.stringify(expectedRest)) restMismatches.push({ roundIndex: round.roundIndex, actualRest, expectedRest });
    for (const id of ids) {
      currentStreak[id] = active.has(id) ? currentStreak[id] + 1 : 0;
      maxConsecutivePlay = Math.max(maxConsecutivePlay, currentStreak[id]);
    }
  }
  const repeat = map => [...map.values()].reduce((s, c) => s + Math.max(0, c - 1), 0);
  const matrix = map => Object.fromEntries(ids.map(a => [a, Object.fromEntries(ids.filter(b => b !== a).map(b => [b, map.get(pairKey(a,b)) || 0]))]));
  return { count, batches: out.rounds.length, play, playSpread: Math.max(...Object.values(play)) - Math.min(...Object.values(play)), maxConsecutivePlay,
    partnerPairs: partners.size, opponentPairs: opponents.size, partnerRepeats: repeat(partners), opponentRepeats: repeat(opponents), exactMatches: exact.size,
    partners: Object.fromEntries(partners), opponents: Object.fromEntries(opponents), partnerMatrix: matrix(partners), opponentMatrix: matrix(opponents), restMismatches };
}
function testSingles() {
  const cases = [];
  for (let n = 2; n <= 8; n++) for (const courts of [1, 2]) for (const cycles of [1, 2]) {
    for (const order of ['normal', 'reverse', 'rotate']) {
      const base = roster(n);
      const players = order === 'reverse' ? base.slice().reverse() : order === 'rotate' ? base.slice(1).concat(base[0]) : base;
      const before = JSON.stringify(players);
      const out = buildSinglesSchedule(players, courts, { cycles });
      const metrics = collect(out, players, 1);
      assert.equal(metrics.count, n * (n - 1) / 2 * cycles);
      assert.equal(metrics.batches, (n % 2 ? n : n - 1) * Math.ceil(Math.floor(n / 2) / courts) * cycles);
      assert.deepEqual(metrics.restMismatches, []);
      assert(Object.values(metrics.play).every(c => c === (n - 1) * cycles));
      assert(Object.values(metrics.opponents).every(c => c === cycles));
      const logical = new Map(), byes = new Map(), perCycle = new Map();
      let previousCycle = 1;
      for (const r of out.rounds) {
        assert(r.cycleIndex >= previousCycle); previousCycle = r.cycleIndex;
        assert(r.matches.length >= 1 && r.matches.length <= courts);
        const key = `${r.cycleIndex}/${r.logicalRound}`;
        if (!logical.has(key)) logical.set(key, new Set());
        for (const m of r.matches) {
          const ids = m.teamA.concat(m.teamB);
          for (const id of ids) { assert(!logical.get(key).has(id)); logical.get(key).add(id); }
          bump(perCycle, `${r.cycleIndex}/${pairKey(...ids)}`);
        }
        for (const id of r.byePlayers) { assert.equal(r.batchIndex, 1); bump(byes, id); }
      }
      assert.equal(perCycle.size, n * (n - 1) / 2 * cycles);
      assert([...perCycle.values()].every(c => c === 1));
      for (const p of players) assert.equal(byes.get(p.id) || 0, n % 2 ? cycles : 0);
      assert.equal(JSON.stringify(players), before);
      cases.push({ n, courts, cycles, order, count: metrics.count, batches: metrics.batches, maxConsecutivePlay: metrics.maxConsecutivePlay });
    }
  }
  return { passed: cases.length, cases };
}
function testFixedPairs() {
  const cases = [], restExamples = [];
  for (let n = 2; n <= 12; n++) for (const courts of [1, 2, 3, 10]) {
    const { players, pairTeams } = fixedRoster(n), base = n * (n - 1) / 2;
    const targets = [...new Set([1, Math.max(1,base-1), base, base+1, 2*base, 3*base, 5*base, 10*base-1, 10*base])];
    for (const target of targets) {
      const out = buildFixedPairSchedule(players, courts, pairTeams, { totalMatches: target });
      const metrics = collect(out, players);
      const teams = new Map(pairTeams.map(t => [t.id, t.playerIds.slice().sort()]));
      const coverage = new Map();
      assert.equal(metrics.count, target);
      for (const r of out.rounds) {
        assert(r.matches.length <= courts);
        for (const m of r.matches) {
          assert.deepEqual(m.teamA.slice().sort(), teams.get(m.unitAId));
          assert.deepEqual(m.teamB.slice().sort(), teams.get(m.unitBId));
          bump(coverage, pairKey(m.unitAId, m.unitBId));
        }
      }
      const lo = Math.floor(target/base), hi = Math.ceil(target/base);
      for(let a=0;a<n;a++) for(let b=a+1;b<n;b++) {
        const c=coverage.get(pairKey(pairTeams[a].id,pairTeams[b].id))||0;
        assert(c >= lo && c <= hi);
      }
      if (target % base === 0) assert(Object.values(metrics.play).every(c => c === (n-1)*target/base));
      cases.push({ n, courts, target, batches: metrics.batches, playSpread: metrics.playSpread, restMismatchBatches: metrics.restMismatches.length });
      if (metrics.restMismatches.length && restExamples.length < 3) restExamples.push({ n, courts, target, ...metrics.restMismatches[0] });
    }
  }
  return { passedCoreCases: cases.length, restMismatchCases: cases.filter(c=>c.restMismatchBatches).length, restExamples, cases };
}
// Explore point-by-point reachable states, stopping a game at its first legal terminal.
// This is independent of the production terminal-score case distinctions.
function terminalSet(target) {
  const final = new Set(), queue = [[0,0]], visited = new Set(['0,0']);
  for(let head=0;head<queue.length;head++) {
    const [a,b]=queue[head];
    const won = target===21 ? (Math.max(a,b)>=21 && Math.abs(a-b)>=2)||Math.max(a,b)===30 : Math.max(a,b)===target;
    if (won) { final.add(`${a},${b}`); continue; }
    for(const [x,y] of [[a+1,b],[a,b+1]]) {
      const key=`${x},${y}`;
      if(!visited.has(key)) { visited.add(key); queue.push([x,y]); }
    }
  }
  return final;
}
function testScores() {
  let scorePairs = 0, comparisons = 0;
  const summary = [];
  for(const target of [11,15,21]) {
    const valid=terminalSet(target), t={mode:'singles_round_robin',rules:{pointsPerGame:target}};
    for(let a=-1;a<=35;a++) for(let b=-1;b<=35;b++) {
      const expected=valid.has(`${a},${b}`);
      for(const api of scores) { assert.equal(api.isValidFinishedScore({scoreA:a,scoreB:b},t),expected,`${target}:${a}-${b}`); comparisons++; }
      scorePairs++;
    }
    summary.push({ target, reachableTerminalPairs: valid.size });
  }
  return { scorePairs, comparisons, summary };
}
function referenceRankings(t) {
  const isTeam=t.mode==='squad_doubles'||t.mode==='fixed_pair_rr';
  const rows=(isTeam ? (t.mode==='squad_doubles' ? [{id:'A',name:'A队'},{id:'B',name:'B队'}] : t.pairTeams) : t.players).map(p=>({entityId:p.id, playerId:p.id, entityType:isTeam?'team':'player',name:p.name,wins:0,losses:0,played:0,pointsFor:0,pointsAgainst:0,pointDiff:0}));
  const byId=Object.fromEntries(rows.map(r=>[r.entityId,r]));
  for(const r of t.rounds) for(const m of r.matches) {
    if(m.status!=='finished') continue;
    const a=m.scoreA,b=m.scoreB;
    const aas=isTeam?[m.unitAId]:m.teamA.map(idOf),bbs=isTeam?[m.unitBId]:m.teamB.map(idOf);
    for(const [ids,x,y] of [[aas,a,b],[bbs,b,a]]) for(const id of ids) {
      const row=byId[id]; row.played++; row.pointsFor+=x; row.pointsAgainst+=y; row.pointDiff+=x-y;
      if(x>y)row.wins++;else row.losses++;
    }
  }
  rows.sort((a,b)=>b.wins-a.wins||b.pointDiff-a.pointDiff||b.pointsFor-a.pointsFor||a.name.localeCompare(b.name));
  if(t.mode==='singles_round_robin')for(let i=0;i<rows.length;i++) {
    const first=rows.findIndex(p=>p.wins===rows[i].wins&&p.pointDiff===rows[i].pointDiff&&p.pointsFor===rows[i].pointsFor); rows[i].rank=first+1;
  }
  return rows;
}
function testRankings() {
  let cases=0;
  const p=roster(4), modes=['multi_rotate','squad_doubles','fixed_pair_rr','singles_round_robin'];
  for(const mode of modes) for(let seed=0;seed<50;seed++) {
    const t={mode,players:p,rules:{pointsPerGame:21},pairTeams:mode==='fixed_pair_rr'?[{id:'T1',name:'队1',playerIds:[p[0].id,p[1].id]},{id:'T2',name:'队2',playerIds:[p[2].id,p[3].id]}]:[],rounds:[]};
    for(let i=0;i<12;i++) {
      const a=[p[(i+seed)%4].id],b=[p[(i+seed+1)%4].id];
      if(mode!=='singles_round_robin'){a.splice(0,a.length,p[0].id,p[1].id);b.splice(0,b.length,p[2].id,p[3].id);}
      const flip=(seed+i)%3===0;
      t.rounds.push({roundIndex:i,matches:[{matchIndex:0,teamA:a,teamB:b,unitAId:mode==='squad_doubles'?'A':'T1',unitBId:mode==='squad_doubles'?'B':'T2',scoreA:flip?((seed+i)%20):21,scoreB:flip?21:((seed+i)%20),status:(seed+i)%7===0?'canceled':(seed+i)%5===0?'pending':'finished'}]});
    }
    const expected=referenceRankings(t);
    for(const api of ranks)assert.deepEqual(api.computeRankings(t),expected,`${mode}/${seed}`);
    cases++;
  }
  return { cases, comparisons:cases*ranks.length };
}
function balancedSquadCounterexample() {
  const players=roster(8,'A').map(p=>({...p,squad:'A'})).concat(roster(8,'B').map(p=>({...p,squad:'B'})));
  const actual=buildSquadSchedule(players,16,2,{endCondition:{type:'total_matches',target:16},_seed:1});
  // Partition XOR differences 0..7 into four pairs with distinct differences.
  // Each of K(8,8)'s 64 edges occurs once, in 16 disjoint 2x2 blocks.
  const offsets=[[0,1],[2,4],[3,7],[5,6]],rounds=[];
  for(const [x,y]of offsets) {
    const d=x^y,seen=new Set(),stage=[];
    for(let a=0;a<8;a++) {
      if(seen.has(a))continue;
      seen.add(a);seen.add(a^d);
      stage.push({teamA:[a,a^d].map(i=>`A${String(i+1).padStart(2,'0')}`),teamB:[a^x,a^y].map(i=>`B${String(i+1).padStart(2,'0')}`)});
    }
    for(let batch=0;batch<2;batch++) {
      const matches=stage.slice(batch*2,batch*2+2).map((m,i)=>({...m,matchIndex:i}));
      const active=new Set(matches.flatMap(m=>m.teamA.concat(m.teamB)));
      rounds.push({roundIndex:rounds.length,matches,restPlayers:players.map(idOf).filter(id=>!active.has(id))});
    }
  }
  const reference={rounds}, actualMetrics=collect(actual,players),referenceMetrics=collect(reference,players);
  assert.equal(referenceMetrics.count,16);assert.equal(referenceMetrics.playSpread,0);
  assert.equal(referenceMetrics.opponentRepeats,0);assert.equal(referenceMetrics.partnerRepeats,0);assert.equal(referenceMetrics.maxConsecutivePlay,2);
  return { parameters:{a:8,b:8,courts:2,matches:16},actual:{rounds:actual.rounds,metrics:actualMetrics},reference:{rounds,metrics:referenceMetrics},classification:'Verified fairness tradeoff: no core schedule rule violation; reduces both repetition metrics by allowing a consecutive-play cap of 2 instead of 1.' };
}
if (require.main === module) {
  const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',generatedAt:new Date().toISOString(),singles:testSingles(),fixedPairs:testFixedPairs(),scores:testScores(),rankings:testRankings(),squadCounterexample:balancedSquadCounterexample()};
  fs.writeFileSync(path.join(__dirname,'independent-results.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({singles:result.singles.passed,fixedCore:result.fixedPairs.passedCoreCases,fixedRestMismatchCases:result.fixedPairs.restMismatchCases,scorePairs:result.scores.scorePairs,scoreComparisons:result.scores.comparisons,rankings:result.rankings.cases,squadActual:{partnerRepeats:result.squadCounterexample.actual.metrics.partnerRepeats,opponentRepeats:result.squadCounterexample.actual.metrics.opponentRepeats,maxConsecutivePlay:result.squadCounterexample.actual.metrics.maxConsecutivePlay},squadReference:{partnerRepeats:result.squadCounterexample.reference.metrics.partnerRepeats,opponentRepeats:result.squadCounterexample.reference.metrics.opponentRepeats,maxConsecutivePlay:result.squadCounterexample.reference.metrics.maxConsecutivePlay}},null,2));
}
module.exports={ROOT,load,roster,fixedRoster,collect,idOf,pairKey,referenceRankings};
