'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {load,roster,collect}=require('./independent-audit.cjs');
const templates=load('cloudfunctions/startTournament/rotation.templates.js');
const engine=load('cloudfunctions/startTournament/rotationDoublesEngine.js');
const rows=[],failures=[],metricsMismatches=[];
for(const [key,spec] of Object.entries(templates.cases)) {
  for(let target=1;target<=spec.horizonMatches;target++) {
    const players=roster(spec.players);
    try {
      // Assert template selection before calling: this path must not run beam search.
      assert(engine.findTemplateCase(spec.players,spec.courts,target));
      const out=engine.resolveRuntimeSchedule(players.map(p=>p.id),target,spec.courts,{seed:1});
      assert.equal(out.engine,'template');
      const m=collect(out,players);
      assert.equal(m.count,target);assert.deepEqual(m.restMismatches,[]);
      for(const r of out.rounds)assert(r.matches.length<=spec.courts);
      const expected={playSpread:m.playSpread,maxConsecutivePlay:m.maxConsecutivePlay,partnerRepeats:m.partnerRepeats,opponentRepeats:m.opponentRepeats,uniqueMatchupCount:m.exactMatches};
      for(const [field,value]of Object.entries(expected))if(out.fairness[field]!==value)metricsMismatches.push({key,target,field,reported:out.fairness[field],independent:value});
      rows.push({key,target,players:spec.players,courts:spec.courts,playSpread:m.playSpread,theoreticalPlaySpread:((target*4)%spec.players)?1:0,partnerPairs:m.partnerPairs,opponentPairs:m.opponentPairs,partnerRepeats:m.partnerRepeats,opponentRepeats:m.opponentRepeats,exactMatches:m.exactMatches,maxConsecutivePlay:m.maxConsecutivePlay});
    }catch(e){failures.push({key,target,error:e.stack});}
  }
}
const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',generatedAt:new Date().toISOString(),templateCases:Object.keys(templates.cases).length,prefixes:rows.length,failures,metricsMismatches,rows};
fs.writeFileSync(path.join(__dirname,'template-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({templateCases:result.templateCases,prefixes:rows.length,failures:failures.length,metricsMismatches:metricsMismatches.length,playSpreadAboveArithmeticLowerBound:rows.filter(r=>r.playSpread>r.theoreticalPlaySpread),exactRepeatCases:rows.filter(r=>r.exactMatches<r.target)},null,2));
if(failures.length)process.exitCode=1;
