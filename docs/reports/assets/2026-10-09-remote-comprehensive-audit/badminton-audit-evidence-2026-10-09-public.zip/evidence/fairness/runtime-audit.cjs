'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {load,roster,collect}=require('./independent-audit.cjs');
const {generateSchedule}=load('cloudfunctions/startTournament/rotation.js');
const {buildSquadSchedule}=load('cloudfunctions/startTournament/scheduleModes.js');
const cases=[];
for(const [n,courts,target]of [[6,1,19],[7,1,22],[8,1,17],[8,2,17],[9,1,19],[9,2,19],[10,1,31],[10,2,31],[11,1,13],[12,3,19],[16,4,17],[24,4,17],[40,10,20]]) {
  for(const seed of (n===6||n===8&&courts===2?[1,17]:[1]))cases.push({mode:'multi_rotate',n,courts,target,seed});
}
for(const [a,b,courts,target]of [[2,2,10,3],[2,3,1,6],[3,4,1,9],[5,4,1,12],[6,5,2,12],[6,6,3,18],[7,7,3,18],[8,8,2,17],[9,9,3,18],[10,10,4,21],[12,10,5,24],[20,20,10,30]])cases.push({mode:'squad_doubles',a,b,courts,target,seed:1});
for(const [a,b,courts,target]of [[4,4,1,12],[6,5,2,12],[8,8,2,16],[10,10,4,20]])cases.push({mode:'squad_doubles',a,b,courts,target,seed:1,forceFallback:true});
const results=[],failures=[],rootResult={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',startedAt:new Date().toISOString(),budgetMs:4500,cases:results,failures};
function save(){fs.writeFileSync(path.join(__dirname,'runtime-results.json'),JSON.stringify(rootResult,null,2)+'\n');}
function brief(m){const {partnerMatrix,opponentMatrix,partners,opponents,restMismatches,...value}=m;return {...value,restMismatchBatches:restMismatches.length};}
for(const scenario of cases) {
  const t0=performance.now();
  try {
    let players,out;
    if(scenario.mode==='multi_rotate') {
      players=roster(scenario.n);
      out=generateSchedule(players,scenario.target,scenario.courts,{seed:scenario.seed,runtimeBudgetMs:4500});
    }else {
      players=roster(scenario.a,'A').map(p=>({...p,squad:'A'})).concat(roster(scenario.b,'B').map(p=>({...p,squad:'B'})));
      out=buildSquadSchedule(players,scenario.target,scenario.courts,{endCondition:{type:'total_matches',target:scenario.target},_hardDeadlineMs:4500,_seed:scenario.seed,_debugForceFallback:scenario.forceFallback===true});
    }
    const elapsedMs=performance.now()-t0,m=collect(out,players);
    assert.equal(m.count,scenario.target,'incomplete schedule');assert.deepEqual(m.restMismatches,[]);
    const effectiveCourts=scenario.mode==='multi_rotate'?Math.min(scenario.courts,Math.floor(scenario.n/4)):Math.min(scenario.courts,Math.floor(scenario.a/2),Math.floor(scenario.b/2));
    assert(out.rounds.every(r=>r.matches.length<=effectiveCourts));
    if(scenario.mode==='squad_doubles')for(const r of out.rounds)for(const match of r.matches){assert(match.teamA.every(id=>id.startsWith('A')));assert(match.teamB.every(id=>id.startsWith('B')));}
    const mismatches=[];for(const[field,value]of Object.entries({playSpread:m.playSpread,maxConsecutivePlay:m.maxConsecutivePlay,partnerRepeats:m.partnerRepeats,opponentRepeats:m.opponentRepeats}))if(out.fairness[field]!==value)mismatches.push({field,reported:out.fairness[field],independent:value});
    const countSpread=prefix=>{const v=Object.entries(m.play).filter(([id])=>id.startsWith(prefix)).map(([,c])=>c);return Math.max(...v)-Math.min(...v);};
    const row={scenario,elapsedMs:Math.round(elapsedMs),metadata:out.schedulerMeta,metrics:brief(m),metricMismatches:mismatches,...(scenario.mode==='squad_doubles'?{squadASpread:countSpread('A'),squadBSpread:countSpread('B')}:{}),scheduleHash:crypto.createHash('sha256').update(JSON.stringify(out.rounds)).digest('hex'),rounds:out.rounds};
    results.push(row);console.log(JSON.stringify({case:results.length,scenario,elapsedMs:row.elapsedMs,profile:out.schedulerMeta.executionProfile,playSpread:m.playSpread,partnerRepeats:m.partnerRepeats,opponentRepeats:m.opponentRepeats,metricMismatches:mismatches.length}));
  }catch(e){failures.push({scenario,elapsedMs:Math.round(performance.now()-t0),error:e.stack});console.log(JSON.stringify({scenario,FAILED:e.message}));}
  save();
}
rootResult.finishedAt=new Date().toISOString();save();
console.log(JSON.stringify({completed:results.length,failures:failures.length}));
if(failures.length)process.exitCode=1;
