# 排赛公平性、循环覆盖与比分排名专项审计

基准：`LXZ56156/repo-20260224-031312`，`master`，`a3fe96f25015892ac30ee7148f97a5b441b0cb24`。本专项仅读取远端取得的固定源码，在隔离环境中执行纯逻辑、页面投影及离线模拟云函数入口验证，没有修改业务代码、调用真实云 SDK、访问真实数据或进行部署。完成日期：2026-10-09（上海）。

## 结论

本次检查覆盖四种赛制。已验证的赛程数量、人员合法性、同批互斥、固定组合保持和完整循环逐对覆盖均通过；单打终局规则与客户端/云端排名算术也通过独立验证。**合法赛程不自动等于均衡质量符合当前目标。** 已确认四项需要分别处理的发现：

| 编号 | 发现 | 性质 | 建议优先级 |
|---|---|---|---|
| FA-01 | 8 人单场地从 16 场增到 17 场，跨模板上限后搭档/对手覆盖由 28 种降至 12 种，17 场只有 6 种完整对阵 | 当前均衡目标下的质量断崖；有休息取舍，不是成员/场次非法 | P2，优先调整目标 |
| FA-02 | 12v10、5 场地、24 场的真实超时降级结果，A 队有人 5 场、有人 3 场，存在各方面不更差的人人 4 场排法 | 可严格改善的排赛质量缺陷 | P2，修复降级路径 |
| FA-03 | 8v8、2 场地、16 场模板每人仅遇到对方 4/8 人；允许最多连打 2 批即可搭档与对手均无重复 | 已证实的产品目标取舍 | P2，按本轮偏好调整；不计硬错误 |
| FA-04 | 固定搭档排程把休息名单恒置空，页面漏掉实际轮空球员 | 已复现的信息显示缺陷 | P2 |

前两项和第三项有关，但证据与适用条件不同，不能合并后笼统称为“排赛算法有错”。FA-01 是模板与运行时目标不一致形成的突变；FA-03 是固定模板刻意采用的休息优先取舍；FA-02 在连打与重复指标不恶化的条件下仍然可以改善，因此不是不可避免的取舍。

## 一、独立验证范围与结果

| 范围 | 本次执行 | 结果与证据 |
|---|---|---|
| 单打循环 | 2–8 人 × 1/2 场地 × 1/2 循环 = 28 组，每组正序、倒序、循环移位 3 种名单，共 84 例 | 逐循环每对恰好一次、上场次数、逻辑轮互斥、同批互斥、唯一坐标、奇数每人每循环一次轮空、输入不变均通过；`independent-results.json` |
| 固搭循环 | 2–12 队，1/2/3/10 场地，1/2/3/5/10 完整循环及不整除场数边界，共 384 例 | 场数、固定成员、同批互斥、每队对阵次数 floor/ceil 分布和完整循环上场次数通过；320 例存在应有休息者而名单为空，单独列为 FA-04 |
| 多人转模板 | 60 个模板，全部 941 个支持场数前缀，经实际模板实例化路径 | 全部数量与成员检查通过；没有完全重复对阵；每个前缀的上场次数差达到算术下界 0 或 1；独立统计与生产 fairness 字段无差异；`template-results.json` |
| 单打终局比分 | 独立逐分探索合法可达终局，然后检查每种分制 -1…35 的全部双方比分 | 11/15/21 分共 4,107 个输入对，客户端与云端共 8,214 次断言通过；21 分包含 20 平追分、30 封顶 |
| 四赛制排名 | 4 赛制 × 50 组完赛/未赛/取消组合，共 200 组，独立算术与两端核心对照 | 400 次两端结果对照通过；沿用旧三模式自由比分合同，不误报其保留的小数取整行为 |
| 单打完整逻辑流程 | 2/3/4/6/8 人 × 1/2 场地 × 1/2 循环 × 11/15/21 分，共 60 条流程 | 生成、部分录分、更正、提前收赛分支、继续全赛程、重置通过；1,014 次提交或更正均核对独立排名；过期排赛截止参数拒绝为 START_TIMEOUT |
| 小规模穷举参照 | 4v4、单场地、3 场，穷举 36³ = 46,656 个有序排法，其中 8,100 个达到上场次数差 1 | 当前结果处于帕累托前沿；见下节，不把必要的一次重复当成缺陷 |
| 非模板与降级 | 15 例多人转、12 例普通小队转/自然超时、4 例强制降级，共 31 例 | 所有样例场数完整、人员及批次合法、两队边界正确、休息名单一致、独立指标与生产字段吻合；公平质量问题另列 |
| 关键参数入口可达性 | 仅追加 FA-01 与 FA-02 两条创建→导入→分队（小队转）→设置页选择与保存→开赛流程 | 实际源函数与真实生成器执行，SDK/数据库/页面视觉副作用离线模拟；17 场和 24 场均原值保存并生成，未被模板上限截断；`reachability-results.json` |

以上是不同层次的覆盖数量，不能相加包装成统一的“通过率”。模板 941 例验证的是模板实例化路径；外层 `generateSchedule` 的小场数轮序优化只在相关样例与仓库基线中验证，不把它说成 941 次外层完整运行。真实计时的 27 例自然路径样本耗时约 14–4,503 ms，另 4 例强制降级约 0–1 ms。它们是当前审计机器上的观测，不能当作真实云端 P95、手机时延或线上成功率。

## 二、FA-01：跨模板上限后的均衡质量断崖

### 触发与结果

8 人、1 场地，人数不变，仅把总场数从 16 改为 17。前者使用模板，后者超出 `horizonMatches` 后进入限时搜索。固定种子 1，本次运行时与独立复核均重现：

| 指标 | 当前 16 场模板 | 当前 17 场运行时 | 可行 17 场对照 |
|---|---:|---:|---:|
| 实际场数 | 16 | 17 | 17 |
| 上场次数差 | 0 | 1 | 1 |
| 不同搭档组合 | 28/28 | **12/28** | **28/28** |
| 不同对手组合 | 28/28 | **12/28** | **28/28** |
| 搭档重复次数 | 4 | **22** | 6 |
| 对手重复次数 | 36 | **56** | 40 |
| 不同完整对阵 | 16 | **6** | **17** |
| 最大连续上场批数 | 2 | **1** | **2** |

对照不是搜索器自行给自己评分：审计将当前 16 场模板保留，再独立枚举追加一场，找出仍满足人数/场地/同批互斥、最大连打不超过 2 且不重复完整对阵的排法。完整排程和独立矩阵均保留在 `quality-counterexamples.json`。

### 参数确实可从产品入口到达

这不是只能绕过页面校验调用内部函数的参数。8 人单场地的选项定义同时写明模板长度 16 和 `supportsAdvancedCustom: true`，见 [`multiRotateMatchOptions.js:681–692`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/core/ux/multiRotateMatchOptions.js#L681-L692)。设置页确实提供“高级自定义”数字选择器，见 [`settings/index.wxml:56–79`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/settings/index.wxml#L56-L79)。这里的配置上限是 `3 × C(8,4) = 210`，不是 16。

补充脚本执行真实 `createTournament` 与 `addPlayers` 源入口生成 8 人自定义赛，再调用真实设置页的高级入口、数字选择事件（`017`）与保存方法。保存载荷、离线数据库、重新打开的表单、`validateBeforeGenerate` 均保留 `17/1`；`checkStartReady=true`。实际 `startTournament.main` 向 `generateSchedule` 传入 8 人、17 场、1 场地、4,500 ms 预算，最终 `scheduledMatches=17`，使用 `beam-guarded`。记录见 `reachability-results.json`。

字段传递与限制分别位于 [`settingsActions.js:139–153`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/settings/settingsActions.js#L139-L153) 与 [`281–308`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/settings/settingsActions.js#L281-L308)、[`updateSettings/index.js:94–127`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/updateSettings/index.js#L94-L127)、[`startTournament/logic.js:95–138`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/logic.js#L95-L138) 和 [`startTournament/index.js:143–190`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/index.js#L143-L190)。16 是模板命中边界；超过它会改走运行时路径，不会把需求改成 16。

### 原因与适用边界

[`rotationDoublesEngine.js:885–895`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/rotationDoublesEngine.js#L885-L895) 在超过模板上限时返回无模板。运行时比较器在 [`121–140`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/rotationDoublesEngine.js#L121-L140) 先比较上场差、连打和休息，之后才比较完整对阵、搭档与对手。这样会优先选择“最大连打 1”的方案。

在 8 人单场地、每批 4 人上场且不允许连续上场时，相邻两批必须是互补的两组 4 人，因此两组成员始终不交叉。每组只有 6 种球员两两关系、3 种完整双打对阵，合计上限恰好为 12 种关系、6 种完整对阵。这解释了观察到的结果：仅增加搜索时间不能消除这个限制，必须改变目标优先级或允许最多连打 2 批。

**性质：赛程本体合法，但不符合本轮强调搭档与对手均衡的目标，且存在用户难以预期的参数边界突变。** 没有把“更均衡但连打略增”的对照说成无代价全面优于当前结果。

### 建议与验收

将硬合法性和人数上场均衡作为底线；明确搭档与对手的联合目标，再把连续上场作为约束或次级指标。模板与实时搜索采用相同目标，增加模板上限两侧成对比较。不要只改 `beta/gamma`：现代路径的主比较器是显式的优先级排序。修后至少复核 8 人单场地 14/16/17 场，以及其他模板上限前后一场，报告覆盖、重复、连打三者。

## 三、FA-02：小队转降级产生可避免的上场次数差

### 触发与结果

12 人 A 队、10 人 B 队、5 场地、24 场。该参数通过当前开赛参数验证。本次真实时钟运行预算为 4,500 ms，搜索未完成后自然进入 `greedy-fallback`，赛程完整，但 A01 打 5 场、A12 打 3 场，其余 A 队成员各 4 场。A 队总上场人次 48，12 人各 4 场是可行目标。

补充入口验证从真实 `createTournament` 创建自定义小队转，导入至 22 人，再经真实 `setPlayerSquad` 分为 12/10。页面与开赛云函数都仅要求 A/B 各至少 2 人，没有两队人数必须相等的限制，见 [`draftStartReadiness.js:37–41`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/core/draftStartReadiness.js#L37-L41) 与 [`startTournament/logic.js:119–138`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/logic.js#L119-L138)。设置页可选 1–10 场地、数字总场数；此时当前实现的总场数上限为 `3 × C(22,4) = 21,945`，见 [`settingsViewModel.js:239–317`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/settings/settingsViewModel.js#L239-L317)。

真实设置页事件选择 5 场地、`00024`，保存结束条件为“打满总场数”。保存、重新读取、开赛校验与实际 `buildSquadSchedule` 实收均为 24 场、5 场地。有效场地是 `min(5, floor(12/2), floor(10/2))=5`；“总场数”路径保留 24，不会向上取成 25，也不会截为模板长度，见 [`scheduleModes.js:554–568`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L554-L568)。这次真实源入口的离线完整流程再次自然进入 `greedy-fallback`，最终生成 24 场。补充流程没有注入种子或强制降级标记，质量见证仍以原固定种子证据为准；不据此推断线上触发率。

针对最初保存的固定种子自然超时样本，直接调用同一降级路径，验证输出与原样本赛程逐项相等。审计仅修改对照样本中的一次上场替换和同批队内成员交换，找到 13 份严格改善见证，所选见证为：

| 指标 | 当前降级结果 | 独立对照 |
|---|---:|---:|
| A 队上场次数 | 3–5 | **全部 4** |
| B 队上场次数 | 4–5 | 4–5，原样保留 |
| 全员上场次数差 | 2 | **1** |
| 搭档重复 | 3 | 3 |
| 对手重复 | 11 | **10** |
| 最大连续上场批数 | 5 | 5 |
| 不同完整对阵 | 24 | 24 |
| 总场数/批数 | 24/5 | 24/5 |

因此这里不是“人员数不同导致平均上场数不同”的必然情况，也不需要以更差搭档、对手、连打或场地使用来交换上场均衡。

### 源码原因与修复方向

[`scheduleModes.js:179–244`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L179-L244) 虽然先按上场数选第一人，但第二人通过加权代价选取，次数差只乘以 2，没有保证最终每队的上下界可达。降级主循环位于 [`250–366`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L250-L366)，正常搜索失败后的调用位于 [`692–714`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L692-L714)。

修复宜为降级路径补足同队上场配额约束或有界局部调整，不能用“已生成足够场数”代替均衡验收。回归应分别统计 A、B 队；大小队人数不等时，不要求两队所有人都打相同场数。本项不包含真实云上的超时发生频率结论。

## 四、FA-03：8v8 模板的明确休息取舍

8v8、2 场地、16 场走 [`scheduleModes.js:111–144`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L111-L144) 的固定模板，命中条件为 [`586–597`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L586-L597)。现有 [`squad.fairness.test.js:354–369`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/tests/squad.fairness.test.js#L354-L369) 明确锁定最大连打 1、搭档重复 8、对手重复 32，故它不是本次新增的偶发现象。

每人 4 场，但只和同队 3 名不同搭档合作、只面对对方 4 名不同球员。独立对照把二进制异或差值 0…7 分成四组，构造 16 个互不重复的 2×2 对阵块，使每个 A–B 球员对恰好相遇一次；四轮不同配对也保证搭档不重复。再把每轮分成 2 个场地批次：

| 指标 | 当前模板 | 独立对照 |
|---|---:|---:|
| 每人场数 | 4 | 4 |
| 每人不同搭档 | 3 | **4** |
| 每人不同对手 | 4 | **8** |
| 搭档重复总次数 | 8 | **0** |
| 对手重复总次数 | 32 | **0** |
| 最大连续上场批数 | 1 | **2** |
| 场数/批数 | 16/8 | 16/8 |

与 FA-01 类似，坚持“不连打”会把双方各自固定成两组 4 人，上述覆盖限制随之产生。当前模板在这个限制下并非明显失误；本轮用户强调搭档与对手均衡，应把允许最大连打 2 的方案列为优先候选。**该项单独记录为目标取舍，不计为硬规则错误。** 完整两套排法在 `independent-results.json` 的 `squadCounterexample`。

## 五、FA-04：固搭轮空名单丢失

最小完整例：3 支固定队伍、1 场地、一循环共 3 场。每轮有一支 2 人队伍休息。

[`scheduleModes.js:817–821`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/cloudfunctions/startTournament/scheduleModes.js#L817-L821) 恒写入 `restPlayers: []`。[`schedule/index.js:156`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/schedule/index.js#L156) 与 [`210–214`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/schedule/index.js#L210-L214) 用该数组生成轮空文本；[`index.wxml:124–125`](https://github.com/LXZ56156/repo-20260224-031312/blob/a3fe96f25015892ac30ee7148f97a5b441b0cb24/miniprogram/pages/schedule/index.wxml#L124-L125) 在文本为空时不显示此区。

审计实际调用生成器、标准化函数和页面 `decorateRounds`：三轮预期休息名单依次为 P01/P02、P03/P04、P05/P06，实际存储都为空，页面文本也都为 `''`。这是源码到页面投影的完整复现，不是仅凭字段名猜测；没有宣称已经在微信原生屏幕上看过。

修复时按本批次实际活跃成员的补集计算休息名单，并明确是已组队参赛者还是全部名单参与补集；存在未组队成员时遵守原有产品语义。至少验收奇数队轮空和场地不足导致同轮分批两个场景。详情 `fixed-rest-results.json`。

## 六、不应误报的情况与证据边界

1. 4v4、1 场地、3 场当前“搭档重复 0、对手重复 1、最多连打 2”处于本次穷举得到的帕累托前沿。另有“搭档重复 1、对手重复 0、最多连打 2”；不存在上场均衡相同、两项都为 0 的排法。不能因为出现一次重复就认定错误。
2. 旧三个模式的自由比分、小数取整和按显示顺序分配名次是现有明确保留的合同，本轮没有擅自套用单打终局或并列名次规则。
3. 单打 4 人两场地没有候补时，每批全部上场，连打不可避免；单打规格本就不承诺人人隔批休息。
4. 固搭部分循环对阵次数可以是 floor/ceil，并非必须整循环；本次验证按当前支持任意合法总场数的行为进行。
5. 部分质量测试使用确定性操作时钟，证明的是算法质量路径，不等于真实超时环境。本次另行运行真实时钟路径并保留实际排程，但不能推断云端复现概率。
6. 没有线上活动日志，无法判断这些参数被多少用户使用。不能用本次合成案例推算日均约 90 人中的受影响比例。
7. 原生微信界面、云事务、发布版本、实机桥接时延仍由总报告列为独立验证边界。这里的排名、提前收赛与重置验证是纯逻辑，不替代真实事务与权限验收。

## 七、复现与证据文件

所有脚本通过公共 helper 支持 `AUDIT_REPO`，默认取证据目录的 `../../repo`。需要 Node.js 22+；不需要安装业务依赖，使用 Node 内置模块与仓库纯逻辑。请针对上述固定提交复跑。

最快复核四个发现的命令（本机约 2 秒）：

```bash
AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/fairness/reproduce-findings.cjs
```

此命令重新执行 17 场实际运行时、12v10 的同一降级逻辑、8v8 固定模板、固搭生成器和页面投影，同时独立重算已保存的对照排法。12v10 的自然超时路径及其与强制降级的等同性由 `runtime-results.json` 和 `quality-counterexamples.cjs` 保留；需要重演真实超时过程时再运行 `runtime-audit.cjs`。

仅复核上述两组参数的产品入口可达性（本机约 6.3 秒）：

```bash
AUDIT_REPO=/workspace/scratch/0dae7c352c6b/remote-audit/repo node /workspace/scratch/0dae7c352c6b/remote-audit/evidence/fairness/reachability-audit.cjs
```

此脚本执行实际云函数源入口、实际设置页选择/保存代码和真实生成器，仅替换 SDK、内存数据库、页面视觉与传输副作用。它证明该提交中的正常参数路径可达，不能替代微信实机、真实云数据库或发布版本验收。实际算法参数在不改写的包装器中记录；补充运行未改种子和预算。

| 脚本 | 对应证据 | 用途 |
|---|---|---|
| `independent-audit.cjs` | `independent-results.json` | 单打、固搭、终局比分、独立排名与 8v8 对照 |
| `template-audit.cjs` | `template-results.json` | 全部 60 个模板、941 个前缀 |
| `small-reference-audit.cjs` | `small-reference-results.json` | 小规模完整穷举参照 |
| `fixed-rest-repro.cjs` | `fixed-rest-results.json` | 固搭生成到页面投影复现 |
| `runtime-audit.cjs` | `runtime-results.json`、`runtime-run.log` | 31 个限时搜索/降级样例和完整排程 |
| `quality-counterexamples.cjs` | `quality-counterexamples.json` | 17 场追加排法与 12v10 严格改善见证；先有 runtime 证据 |
| `singles-lifecycle-audit.cjs` | `singles-lifecycle-results.json` | 60 条单打纯逻辑流程、1,014 次独立排名状态核对 |
| `reproduce-findings.cjs` | 标准输出 | 四发现最短复核，不重跑全部审计 |
| `reachability-audit.cjs` | `reachability-results.json` | 仅两组关键参数经真实创建/配置/开赛源入口后保持原值并进入相应算法 |

本专项已完成计划内的源码、独立参照、合法性、均衡和排名验证；未实施上述修复或调整。
