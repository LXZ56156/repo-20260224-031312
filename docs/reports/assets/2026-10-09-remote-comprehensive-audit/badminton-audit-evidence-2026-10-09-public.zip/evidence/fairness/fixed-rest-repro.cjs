'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const Module=require('node:module');
const {ROOT,load,fixedRoster}=require('./independent-audit.cjs');
const {buildFixedPairSchedule}=load('cloudfunctions/startTournament/scheduleModes.js');
const {players,pairTeams}=fixedRoster(3);
const generated=buildFixedPairSchedule(players,1,pairTeams,{totalMatches:3});
const pagePath=path.join(ROOT,'miniprogram/pages/schedule/index.js');
const source=fs.readFileSync(pagePath,'utf8');
// Expose a pure view helper only in memory. Original source stays unchanged.
const compiled=new Module(pagePath,module);
compiled.filename=pagePath;compiled.paths=Module._nodeModulePaths(path.dirname(pagePath));
const savedPage=global.Page;
try {global.Page=()=>{};compiled._compile(source+'\nmodule.exports.__auditDecorateRounds=decorateRounds;\n',pagePath);}finally {global.Page=savedPage;}
const normalize=load('miniprogram/core/normalize.js');
const tournament=normalize.normalizeTournament({mode:'fixed_pair_rr',players,pairTeams,courts:1,rounds:generated.rounds});
const rendered=compiled.exports.__auditDecorateRounds(tournament);
const actual=generated.rounds.map((r,i)=>{
  const active=new Set(r.matches.flatMap(m=>m.teamA.concat(m.teamB)));
  return {roundIndex:r.roundIndex,matches:r.matches,expectedRest:players.filter(p=>!active.has(p.id)).map(p=>p.id),storedRest:r.restPlayers,renderedRestText:rendered[i].restText};
});
assert(actual.every(r=>r.expectedRest.length===2&&r.storedRest.length===0&&r.renderedRestText===''));
const result={commit:'a3fe96f25015892ac30ee7148f97a5b441b0cb24',scenario:'3 fixed pairs / 1 court / 1 full cycle',status:'reproduced',actual,impact:'All three fixed-pair bye lists are omitted in the schedule view despite a different two-player team resting in each round.',source:['cloudfunctions/startTournament/scheduleModes.js:817-821','miniprogram/pages/schedule/index.js:156,210-214','miniprogram/pages/schedule/index.wxml:124-125']};
fs.writeFileSync(path.join(__dirname,'fixed-rest-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
